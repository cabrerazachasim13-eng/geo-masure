import { pgTable, serial, varchar, integer, timestamp } from "drizzle-orm/pg-core";

export const leaderboard = pgTable("leaderboard", {
  id: serial("id").primaryKey(),
  nickname: varchar("nickname", { length: 32 }).notNull().unique(),
  stars: integer("stars").notNull().default(0),
  activities: integer("activities").notNull().default(0),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export type LeaderboardRow = typeof leaderboard.$inferSelect;
