import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import { ProgressProvider } from "@/lib/progress";
import Navbar from "@/components/Navbar";

export const metadata: Metadata = {
  title: "Geo Measure — See It, Hear It, and Solve It!",
  description: "Interactive measurement and geometry learning world for Grade 11 students: definitions, lessons, games, practice tests, and star rewards.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="cloud-bg min-h-screen text-[#49385C] antialiased">
        <ProgressProvider>
          <Navbar />
          <main className="mx-auto w-full max-w-6xl px-3 pb-16 sm:px-4">{children}</main>
          <footer className="border-t-2 border-white/60 bg-white/60 py-5 backdrop-blur">
            <div className="mx-auto max-w-6xl px-4 text-center">
              <p className="font-display text-sm font-extrabold text-[#6d5a86]">
                🌈 GEO MEASURE · See It, Hear It, and Solve It! ✨
              </p>
              <p className="mt-1 text-xs font-semibold text-[#6d5a86]/80">
                An interactive Geometry &amp; Measurement learning world for Grade 11 · Definitions · Lessons · Games · Practices
              </p>
              <p className="mt-2 text-[11px] font-medium tracking-wide text-[#6d5a86]/50">
                Tri-Angels · D G J
              </p>
            </div>
          </footer>
        </ProgressProvider>
      </body>
    </html>
  );
}
