"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { useParams } from "next/navigation";
import { ArrowLeft, ArrowRight, CheckCircle2, Target, Lightbulb, FlaskConical, AlertTriangle, PartyPopper } from "lucide-react";
import { LESSONS, lessonById } from "@/data/lessons";
import { COMPETENCIES } from "@/data/competencies";
import { useProgress } from "@/lib/progress";
import { PageHeader, BackLinks, Formula, FeedbackBanner, Celebrate } from "@/components/ui";
import Diagram from "@/components/Diagram";
import AudioButton from "@/components/AudioButton";
import { LessonTool } from "@/components/lesson-tools";

export default function LessonDetailPage() {
  const params = useParams<{ id: string }>();
  const lesson = lessonById(params.id);
  const { state, completeLesson } = useProgress();
  const [answers, setAnswers] = useState<Record<number, number>>({});
  const [checked, setChecked] = useState(false);
  const [celebrate, setCelebrate] = useState(false);

  const idx = LESSONS.findIndex((l) => l.id === params.id);
  const prev = idx > 0 ? LESSONS[idx - 1] : null;
  const next = idx < LESSONS.length - 1 ? LESSONS[idx + 1] : null;
  const done = lesson ? state.completedLessons.includes(lesson.id) : false;

  const score = useMemo(() => {
    if (!lesson) return 0;
    return lesson.check.filter((c, i) => answers[i] === c.answer).length;
  }, [answers, lesson]);

  if (!lesson) {
    return (
      <div className="pt-6">
        <BackLinks />
        <div className="card-pastel mt-4 p-8 text-center">
          <p className="font-display text-2xl font-extrabold">Lesson not found 😢</p>
          <Link href="/lessons" className="btn-chunky mt-3 inline-block bg-[#49385C] px-6 py-2.5 text-white">Back to Lessons</Link>
        </div>
      </div>
    );
  }

  const c = COMPETENCIES[lesson.competencyId - 1];
  const allCorrect = score === lesson.check.length;

  const finish = () => {
    const newly = completeLesson(lesson.id, lesson.competencyId - 1);
    setCelebrate(true);
    if (!newly) setCelebrate(true);
  };

  return (
    <div className="space-y-5 pt-6">
      <PageHeader
        eyebrow={`Lesson ${lesson.id} · Competency ${lesson.competencyId}`}
        title={`${c.emoji} ${lesson.title}`}
        subtitle={c.objective}
        mascot={c.mascot}
        right={done ? <span className="inline-flex items-center gap-1 rounded-full bg-emerald-100 px-3 py-1.5 text-xs font-extrabold text-emerald-700"><CheckCircle2 size={14} /> Completed +5⭐</span> : <span className="rounded-full bg-[#FFE89A] px-3 py-1.5 text-xs font-extrabold">Finish quiz → earn 5⭐</span>}
      />
      <BackLinks />

      {/* objectives */}
      <section className="card-pastel p-5" aria-label="Learning objectives">
        <h2 className="font-display flex items-center gap-2 text-lg font-extrabold"><Target size={18} /> 🎯 Learning Objectives</h2>
        <ul className="mt-2 space-y-1.5">
          {lesson.objectives.map((o, i) => (
            <li key={i} className="flex items-start gap-2 rounded-2xl bg-white/80 p-2.5 text-sm font-semibold">
              <span className="font-display grid h-6 w-6 shrink-0 place-items-center rounded-full text-xs font-extrabold text-white" style={{ background: c.accent }}>{i + 1}</span>
              {o}
            </li>
          ))}
        </ul>
      </section>

      {/* intro */}
      <section className="card-pastel space-y-2 p-5" aria-label="Introduction">
        <div className="flex items-center justify-between gap-2">
          <h2 className="font-display text-lg font-extrabold">👋 Friendly Introduction</h2>
          <AudioButton text={lesson.introSpeak} label="Listen" size="sm" id={`intro-${lesson.id}`} />
        </div>
        <p className="text-sm font-semibold leading-relaxed sm:text-base">{lesson.intro}</p>
      </section>

      {/* key terms */}
      <section className="card-pastel p-5" aria-label="Key terms">
        <h2 className="font-display text-lg font-extrabold">📖 Key Words</h2>
        <div className="mt-2 grid gap-2 sm:grid-cols-2">
          {lesson.keyTerms.map((t) => (
            <div key={t.term} className="rounded-2xl bg-white/85 p-3">
              <p className="font-display font-extrabold" style={{ color: c.accent }}>{t.term}</p>
              <p className="text-sm font-semibold text-[#6d5a86]">{t.def}</p>
            </div>
          ))}
        </div>
      </section>

      {/* formulas */}
      <section className="card-pastel space-y-2 p-5" aria-label="Formulas">
        <div className="flex items-center justify-between gap-2">
          <h2 className="font-display text-lg font-extrabold">✨ Magic Formulas</h2>
          <AudioButton text={lesson.formulas.map((f) => f.speak).join(". ")} label="Hear formulas" size="sm" id={`form-${lesson.id}`} />
        </div>
        {lesson.formulas.map((f, i) => <Formula key={i} speak={f.speak}>{f.text}</Formula>)}
      </section>

      {/* interactive tool */}
      <section className="space-y-2" aria-label="Interactive exploration">
        <h2 className="font-display flex items-center gap-2 px-1 text-lg font-extrabold"><FlaskConical size={18} /> 🧪 {lesson.toolTitle}</h2>
        <p className="px-1 text-sm font-semibold text-[#6d5a86]">{lesson.toolDesc}</p>
        <LessonTool kind={lesson.tool} />
      </section>

      {/* worked examples */}
      <section className="space-y-4" aria-label="Worked examples">
        <h2 className="font-display flex items-center gap-2 px-1 text-lg font-extrabold"><Lightbulb size={18} /> 📝 Worked Examples — watch how it&apos;s solved!</h2>
        {lesson.workedExamples.map((ex, i) => (
          <article key={i} className="card-pastel space-y-3 p-5">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <h3 className="font-display text-lg font-extrabold">Example {i + 1}: {ex.title}</h3>
              <AudioButton text={ex.audio} label="Hear solution" size="sm" id={`ex-${lesson.id}-${i}`} />
            </div>
            <div className="grid gap-2 text-sm sm:grid-cols-2">
              <div className="rounded-2xl bg-[#B9E3FA]/50 p-3"><p className="text-xs font-extrabold uppercase text-[#2563eb]">📌 Given</p><p className="font-semibold">{ex.given}</p></div>
              <div className="rounded-2xl bg-[#FFE89A]/60 p-3"><p className="text-xs font-extrabold uppercase text-[#b45309]">❓ Asked</p><p className="font-semibold">{ex.asked}</p></div>
            </div>
            <Formula speak={ex.formulaSpeak}>{ex.formula}</Formula>
            <Diagram kind={ex.diagram} data={ex.diagramData} />
            <ol className="space-y-1.5">
              {ex.steps.map((s, j) => (
                <li key={j} className="flex items-start gap-2 rounded-2xl bg-white/85 p-2.5 text-sm font-semibold">
                  <span className="font-display grid h-6 w-6 shrink-0 place-items-center rounded-full bg-[#CDB8F5] text-xs font-extrabold">{j + 1}</span>
                  {s}
                </li>
              ))}
            </ol>
            <div className="rounded-2xl bg-emerald-50 p-3 text-sm font-extrabold text-emerald-800">✅ Final answer: {ex.answer}</div>
            <div className="rounded-2xl bg-[#E9DEFF] p-3 text-sm font-semibold">💡 Why it works: {ex.why}</div>
          </article>
        ))}
      </section>

      {/* applications + mistakes */}
      <div className="grid gap-4 md:grid-cols-2">
        <section className="card-pastel p-5" aria-label="Real world uses">
          <h2 className="font-display text-lg font-extrabold">🌍 Real-World Superpowers</h2>
          <ul className="mt-2 space-y-1.5 text-sm font-semibold">
            {lesson.applications.map((a, i) => <li key={i} className="rounded-2xl bg-[#B8E6D0]/50 p-2.5">⭐ {a}</li>)}
          </ul>
        </section>
        <section className="card-pastel p-5" aria-label="Common mistakes">
          <h2 className="font-display flex items-center gap-2 text-lg font-extrabold"><AlertTriangle size={18} /> 🚧 Oops! Avoid These</h2>
          <ul className="mt-2 space-y-2 text-sm">
            {lesson.mistakes.map((m, i) => (
              <li key={i} className="rounded-2xl bg-white/85 p-3">
                <p className="font-bold text-rose-600">❌ {m.mistake}</p>
                <p className="mt-1 font-semibold text-emerald-700">✅ {m.fix}</p>
              </li>
            ))}
          </ul>
        </section>
      </div>

      {/* knowledge check */}
      <section className="card-pastel space-y-3 p-5" aria-label="Knowledge check">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h2 className="font-display text-lg font-extrabold">🧠 Knowledge Check — show what you learned!</h2>
          <AudioButton text={lesson.check.map((q, i) => `Question ${i + 1}: ${q.question}. Choices: ${q.options.join(", ")}`).join(" ")} label="Hear quiz" size="sm" id={`quiz-${lesson.id}`} />
        </div>
        {lesson.check.map((q, qi) => (
          <div key={qi} className="rounded-3xl bg-white/85 p-4">
            <p className="font-display font-extrabold">Q{qi + 1}. {q.question}</p>
            <div className="mt-2 grid gap-2 sm:grid-cols-2">
              {q.options.map((op, oi) => {
                const picked = answers[qi] === oi;
                const showRight = checked && oi === q.answer;
                const showWrong = checked && picked && oi !== q.answer;
                return (
                  <button
                    key={oi} type="button"
                    onClick={() => !checked && setAnswers({ ...answers, [qi]: oi })}
                    className={`rounded-2xl border-3 p-3 text-left text-sm font-bold transition ${showRight ? "correct-glow border-emerald-400 bg-emerald-50" : showWrong ? "incorrect-shake border-rose-300 bg-rose-50" : picked ? "border-[#8b5cf6] bg-[#E9DEFF]" : "border-slate-200 bg-slate-50 hover:bg-white"}`}
                    style={{ borderWidth: 3 }}
                    aria-pressed={picked}
                  >
                    {showRight ? "✅ " : showWrong ? "❌ " : ""}
                    {op}
                  </button>
                );
              })}
            </div>
            {checked && (
              <p className={`mt-2 rounded-2xl p-2.5 text-sm font-semibold ${answers[qi] === q.answer ? "bg-emerald-50 text-emerald-800" : "bg-amber-50 text-amber-800"}`}>
                💡 {q.explanation}
              </p>
            )}
          </div>
        ))}
        {!checked ? (
          <button
            type="button" onClick={() => setChecked(true)}
            disabled={Object.keys(answers).length < lesson.check.length}
            className="btn-chunky w-full bg-[#8b5cf6] py-3 text-lg text-white shadow-lg sm:w-auto sm:px-10"
          >
            Check My Answers ✨ ({Object.keys(answers).length}/{lesson.check.length})
          </button>
        ) : (
          <div className="space-y-3">
            <FeedbackBanner
              kind={allCorrect ? "correct" : "info"}
              title={allCorrect ? `Perfect! ${score}/${lesson.check.length} correct!` : `You got ${score}/${lesson.check.length}. Read the tips above, then try again!`}
            />
            {allCorrect && !celebrate && (
              <button type="button" onClick={finish} className="btn-chunky flex w-full items-center justify-center gap-2 bg-gradient-to-r from-amber-400 to-pink-400 py-3 text-lg text-white shadow-lg sm:w-auto sm:px-10">
                <PartyPopper size={20} /> Claim 5 Stars & Finish Lesson!
              </button>
            )}
            {!allCorrect && (
              <button type="button" onClick={() => { setChecked(false); setAnswers({}); }} className="btn-chunky bg-white px-8 py-2.5 text-[#49385C] shadow">
                🔁 Try Again
              </button>
            )}
          </div>
        )}
        {celebrate && (
          <Celebrate stars={done ? 0 : 5} message={done ? "You already earned stars for this lesson — reviewing makes you stronger! 💪" : "Lesson complete! +5 stars added to your collection!"} />
        )}
      </section>

      {/* prev / next */}
      <nav className="flex flex-wrap items-center justify-between gap-2" aria-label="Lesson navigation">
        {prev ? (
          <Link href={`/lessons/${prev.id}`} className="btn-chunky inline-flex items-center gap-2 bg-white px-5 py-2.5 text-sm text-[#49385C] shadow">
            <ArrowLeft size={16} /> Lesson {prev.id}: {prev.title}
          </Link>
        ) : <span />}
        {next ? (
          <Link href={`/lessons/${next.id}`} className="btn-chunky inline-flex items-center gap-2 bg-[#49385C] px-5 py-2.5 text-sm text-white shadow">
            Lesson {next.id}: {next.title} <ArrowRight size={16} />
          </Link>
        ) : (
          <Link href="/games" className="btn-chunky inline-flex items-center gap-2 bg-gradient-to-r from-amber-400 to-pink-400 px-5 py-2.5 text-sm text-white shadow">
            You finished all lessons! Play Games 🎮 <ArrowRight size={16} />
          </Link>
        )}
      </nav>
    </div>
  );
}
