"use client";

import Link from "next/link";
import { CheckCircle2, PlayCircle } from "lucide-react";
import { LESSONS } from "@/data/lessons";
import { COMPETENCIES } from "@/data/competencies";
import { useProgress } from "@/lib/progress";
import { PageHeader, BackLinks, Mascot, ProgressBar } from "@/components/ui";
import AudioButton from "@/components/AudioButton";

export default function LessonsPage() {
  const { state } = useProgress();

  return (
    <div className="space-y-5 pt-6">
      <PageHeader
        eyebrow="Step-by-step"
        title="Let's Learn: Step-by-Step Mathematics!"
        subtitle="10 friendly modules with objectives, visuals, audio, worked examples, and quizzes."
        mascot="minty"
        right={<AudioButton text="Welcome to Lessons! Pick any of the ten modules. Each lesson has goals, pictures, audio, worked examples, and a quiz. Finish a lesson to earn five stars!" label="Hear guide" size="sm" />}
      />
      <BackLinks />

      <div className="card-pastel p-4">
        <div className="flex items-center justify-between text-sm font-extrabold">
          <span>📚 {state.completedLessons.length} of 10 lessons completed</span>
          <span>{Math.round((state.completedLessons.length / 10) * 100)}%</span>
        </div>
        <div className="mt-2"><ProgressBar value={(state.completedLessons.length / 10) * 100} /></div>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        {LESSONS.map((l) => {
          const c = COMPETENCIES[l.competencyId - 1];
          const done = state.completedLessons.includes(l.id);
          return (
            <Link
              key={l.id}
              href={`/lessons/${l.id}`}
              className="card-pastel group overflow-hidden p-0 transition hover:scale-[1.01]"
            >
              <div className="flex items-center gap-3 p-4" style={{ background: `linear-gradient(135deg, ${c.color}66, #ffffff)` }}>
                <span className="font-display grid h-12 w-12 shrink-0 place-items-center rounded-2xl text-2xl shadow" style={{ background: c.color }} aria-hidden>
                  {c.emoji}
                </span>
                <div className="flex-1">
                  <p className="text-[11px] font-extrabold uppercase tracking-widest text-[#6d5a86]">Lesson {l.id} · Competency {l.competencyId}</p>
                  <h2 className="font-display text-lg font-extrabold leading-tight">{l.title}</h2>
                </div>
                {done ? (
                  <span className="inline-flex shrink-0 items-center gap-1 rounded-full bg-emerald-100 px-3 py-1.5 text-xs font-extrabold text-emerald-700">
                    <CheckCircle2 size={14} /> Done +5⭐
                  </span>
                ) : (
                  <span className="inline-flex shrink-0 items-center gap-1 rounded-full bg-[#49385C] px-3 py-1.5 text-xs font-extrabold text-white">
                    <PlayCircle size={14} /> Start
                  </span>
                )}
              </div>
              <div className="p-4 pt-2">
                <p className="text-sm font-semibold text-[#6d5a86]">{l.intro.slice(0, 130)}…</p>
                <div className="mt-2 flex flex-wrap gap-1.5">
                  <span className="rounded-full bg-[#E9DEFF] px-2.5 py-1 text-[11px] font-extrabold">🎯 {l.objectives.length} goals</span>
                  <span className="rounded-full bg-[#FFE89A]/70 px-2.5 py-1 text-[11px] font-extrabold">📝 {l.workedExamples.length} examples</span>
                  <span className="rounded-full bg-[#B8E6D0]/70 px-2.5 py-1 text-[11px] font-extrabold">🧪 {l.toolTitle}</span>
                  <span className="rounded-full bg-[#FFC5DD]/50 px-2.5 py-1 text-[11px] font-extrabold">🔊 Audio</span>
                </div>
              </div>
            </Link>
          );
        })}
      </div>

      <div className="card-pastel flex flex-col items-center gap-2 p-5 text-center">
        <Mascot name="minty" size={80} />
        <p className="font-display text-lg font-extrabold">Tip from Minty 📏</p>
        <p className="max-w-xl text-sm font-semibold text-[#6d5a86]">Lessons unlock in any order — but numbers 1→10 follow the friendliest path. Finish each quiz to earn your 5 stars!</p>
      </div>
    </div>
  );
}
