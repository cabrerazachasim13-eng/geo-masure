"use client";

import Link from "next/link";
import { BookOpen, GraduationCap, Gamepad2, ClipboardCheck, Trophy, Sparkles } from "lucide-react";
import { useProgress } from "@/lib/progress";
import { COMPETENCIES } from "@/data/competencies";
import { PageHeader, ProgressBar, StarsPill, Mascot } from "@/components/ui";
import AudioButton from "@/components/AudioButton";

const CARDS = [
  { href: "/definitions", title: "DEFINITIONS", desc: "Discover important words, units, formulas, and mathematical concepts.", btn: "Explore Definitions", icon: BookOpen, bg: "from-[#B8E6D0] to-[#B9E3FA]", mascot: "berry" as const },
  { href: "/lessons", title: "LESSONS", desc: "Learn step by step through visual explanations, audio lessons, worked examples, and formulas.", btn: "Start Learning", icon: GraduationCap, bg: "from-[#CDB8F5] to-[#FFC5DD]", mascot: "minty" as const },
  { href: "/games", title: "GAMES", desc: "Challenge yourself with interactive mathematics games and collect stars!", btn: "Play Games", icon: Gamepad2, bg: "from-[#FFC5DD] to-[#FFE89A]", mascot: "sunny" as const },
  { href: "/practice", title: "PRACTICES", desc: "Test your understanding with interactive questions and personalized feedback.", btn: "Start Practice", icon: ClipboardCheck, bg: "from-[#B9E3FA] to-[#B8E6D0]", mascot: "plummy" as const },
];

export default function DashboardPage() {
  const { state, overallProgress, totalActivities } = useProgress();
  const recent = [...state.activities].reverse().slice(0, 4);

  return (
    <div className="space-y-6 pt-6">
      <PageHeader
        eyebrow="Learning Dashboard"
        title="Welcome to Your Learning World!"
        subtitle="Choose your adventure and let the learning begin!"
        mascot="sunny"
        right={<StarsPill stars={state.stars} />}
      />
      <div className="flex flex-wrap items-center gap-2">
        <AudioButton text="Welcome to your learning world! Choose definitions, lessons, games, or practices. Collect stars and become a Geometry Superstar!" label="Hear intro" size="sm" />
        <Link href="/progress" className="btn-chunky inline-flex items-center gap-2 bg-[#49385C] px-4 py-2 text-sm text-white shadow">
          <Trophy size={15} /> Achievements & Rankings
        </Link>
      </div>

      {/* stats */}
      <div className="card-pastel p-4 sm:p-5">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <p className="font-display text-lg font-extrabold">
            {state.nickname ? `Hello, ${state.nickname}! 💖` : "Hello, Superstar! 💖"}
          </p>
          <span className="inline-flex items-center gap-1 rounded-full bg-[#E9DEFF] px-3 py-1 text-xs font-extrabold">
            <Sparkles size={13} /> Overall progress: {overallProgress}%
          </span>
        </div>
        <div className="mt-2"><ProgressBar value={overallProgress} /></div>
        <div className="mt-3 grid grid-cols-2 gap-2 text-center sm:grid-cols-4">
          {[
            { label: "Stars", value: `⭐ ${state.stars}` },
            { label: "Lessons done", value: `📚 ${state.completedLessons.length}/10` },
            { label: "Games played", value: `🎮 ${Object.values(state.gameBest).reduce((a, g) => a + g.plays, 0)}` },
            { label: "Practice sessions", value: `✏️ ${state.practiceSessions}` },
          ].map((s) => (
            <div key={s.label} className="rounded-2xl bg-white/80 p-2.5 shadow-sm">
              <p className="font-display text-lg font-extrabold">{s.value}</p>
              <p className="text-xs font-bold text-[#6d5a86]">{s.label}</p>
            </div>
          ))}
        </div>
        {totalActivities > 0 && recent.length > 0 && (
          <div className="mt-3 rounded-2xl bg-white/70 p-3">
            <p className="text-xs font-extrabold uppercase tracking-wider text-[#6d5a86]">Recently completed</p>
            <ul className="mt-1 space-y-1">
              {recent.map((a) => (
                <li key={a.id} className="flex items-center justify-between gap-2 text-sm font-semibold">
                  <span className="truncate">🌟 {a.label}</span>
                  <span className="shrink-0 rounded-full bg-[#FFE89A] px-2 py-0.5 text-xs font-extrabold">+{a.stars}⭐</span>
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>

      {/* 4 cards */}
      <div className="grid gap-4 md:grid-cols-2">
        {CARDS.map((c) => (
          <Link key={c.href} href={c.href} className={`group relative overflow-hidden rounded-[2rem] bg-gradient-to-br p-6 shadow-xl transition hover:scale-[1.02] ${c.bg}`}>
            <div className="flex items-start gap-4">
              <div className="float-slow shrink-0 rounded-full bg-white/85 p-1 shadow-lg">
                <Mascot name={c.mascot} size={76} />
              </div>
              <div className="flex-1">
                <p className="flex items-center gap-2 font-display text-2xl font-extrabold text-[#49385C]">
                  <c.icon size={24} /> {c.title}
                </p>
                <p className="mt-1 text-sm font-semibold text-[#49385C]/85">{c.desc}</p>
                <span className="btn-chunky mt-3 inline-block bg-[#49385C] px-6 py-2.5 text-sm text-white shadow-lg">
                  {c.btn} →
                </span>
              </div>
            </div>
          </Link>
        ))}
      </div>

      {/* competency progress */}
      <div className="card-pastel p-4 sm:p-5">
        <p className="font-display text-lg font-extrabold">🗺️ Your journey across 10 competencies</p>
        <div className="mt-3 grid gap-2.5 sm:grid-cols-2">
          {COMPETENCIES.map((c, i) => (
            <Link key={c.id} href={`/lessons/${c.id}`} className="rounded-2xl bg-white/80 p-3 shadow-sm transition hover:bg-white">
              <span className="flex items-center justify-between text-sm font-extrabold">
                <span>{c.emoji} {c.short}</span>
                <span className="text-xs text-[#6d5a86]">{Math.round(state.competencyProgress[i])}% · ⭐{state.competencyStars[i]}</span>
              </span>
              <div className="mt-1.5"><ProgressBar value={state.competencyProgress[i]} color={i % 4 === 0 ? "mint" : i % 4 === 1 ? "sky" : i % 4 === 2 ? "pink" : "grape"} height="h-2.5" /></div>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}
