"use client";

import { useMemo, useRef, useState } from "react";
import Link from "next/link";
import { RotateCcw, ArrowRight, Flag, GraduationCap } from "lucide-react";
import { COMPETENCIES } from "@/data/competencies";
import { QUESTIONS, type Difficulty, type Question } from "@/data/questions";
import { checkNumeric, pickN, shuffle } from "@/lib/math";
import { useProgress } from "@/lib/progress";
import { PageHeader, BackLinks, ProgressBar, FeedbackBanner, Celebrate, DifficultyBadge } from "@/components/ui";
import Diagram from "@/components/Diagram";
import AudioButton from "@/components/AudioButton";

type Setup = { comp: number | null; diff: Difficulty | null; count: number };

interface AnswerLog { qid: string; comp: number; attempt: number; correct: boolean }

export default function PracticePage() {
  const { recordPractice } = useProgress();
  const [setup, setSetup] = useState<Setup>({ comp: null, diff: null, count: 10 });
  const [started, setStarted] = useState(false);
  const [order, setOrder] = useState<Question[]>([]);
  const [scheduled, setScheduled] = useState(0);
  const [idx, setIdx] = useState(0);
  const [picked, setPicked] = useState<number | null>(null);
  const [input, setInput] = useState("");
  const [answered, setAnswered] = useState(false);
  const [ok, setOk] = useState(false);
  const [attempts, setAttempts] = useState<Record<string, number>>({});
  const [log, setLog] = useState<AnswerLog[]>([]);
  const [finished, setFinished] = useState(false);
  const [stars, setStars] = useState(0);
  const awarded = useRef(false);

  const q = order[idx];

  const startSession = () => {
    let pool = QUESTIONS.filter((x) => (setup.comp === null || x.competencyId === setup.comp) && (setup.diff === null || x.difficulty === setup.diff));
    if (pool.length === 0) pool = QUESTIONS;
    const chosen = pickN(pool, setup.count);
    setOrder(shuffle(chosen));
    setScheduled(chosen.length);
    setIdx(0);
    setPicked(null);
    setInput("");
    setAnswered(false);
    setAttempts({});
    setLog([]);
    setFinished(false);
    awarded.current = false;
    setStarted(true);
  };

  const stats = useMemo(() => {
    const firstTries = log.filter((l) => l.attempt === 1);
    const correctFirst = firstTries.filter((l) => l.correct).length;
    const perComp: Record<number, { total: number; first: number }> = {};
    firstTries.forEach((l) => {
      perComp[l.comp] = perComp[l.comp] ?? { total: 0, first: 0 };
      perComp[l.comp].total += 1;
      if (l.correct) perComp[l.comp].first += 1;
    });
    const retried = new Set(log.filter((l) => l.attempt > 1).map((l) => l.qid)).size;
    const mastered = new Set(log.filter((l) => l.correct).map((l) => l.qid)).size;
    return {
      correctFirst,
      totalAttempts: log.length,
      retried,
      mastered,
      accuracy: scheduled > 0 ? (correctFirst / scheduled) * 100 : 0,
      mastery: scheduled > 0 ? (mastered / scheduled) * 100 : 0,
      perComp,
    };
  }, [log, scheduled]);

  const finishSession = (finalLog: AnswerLog[]) => {
    if (awarded.current) { setFinished(true); return; }
    awarded.current = true;
    const firstTries = finalLog.filter((l) => l.attempt === 1);
    const correctFirst = firstTries.filter((l) => l.correct).length;
    const comps = Array.from(new Set(order.slice(0, scheduled).map((o) => o.competencyId - 1)));
    const s = recordPractice(correctFirst, scheduled, comps.length ? comps : [0]);
    setStars(s);
    setFinished(true);
  };

  const recordAnswer = (correct: boolean) => {
    if (!q || answered) return;
    const att = (attempts[q.id] ?? 0) + 1;
    setAttempts({ ...attempts, [q.id]: att });
    const entry: AnswerLog = { qid: q.id, comp: q.competencyId, attempt: att, correct };
    const newLog = [...log, entry];
    setLog(newLog);
    setOk(correct);
    setAnswered(true);
    if (!correct) {
      // retry queue: same question returns at the END of the session
      setOrder((o) => [...o, q]);
    }
    return newLog;
  };

  const submitMC = (oi: number) => {
    if (answered || !q) return;
    setPicked(oi);
    recordAnswer(oi === q.correctIndex);
  };

  const submitNumeric = () => {
    if (answered || !q || input.trim() === "") return;
    const res = checkNumeric(input, q.correctNumeric ?? 0, { tolerance: q.tolerance ?? 0.05 });
    recordAnswer(res.ok);
  };

  const nextQ = () => {
    if (idx + 1 >= order.length) {
      finishSession(log);
      return;
    }
    setIdx(idx + 1);
    setPicked(null);
    setInput("");
    setAnswered(false);
    setOk(false);
  };

  const endEarly = () => finishSession(log);

  /* ---------- SETUP SCREEN ---------- */
  if (!started) {
    return (
      <div className="space-y-5 pt-6">
        <PageHeader
          eyebrow="Assessment"
          title="Practice Paradise: Try, Learn, and Improve!"
          subtitle="Real Grade 11 questions with instant feedback. Missed questions return at the end until you master them!"
          mascot="plummy"
          right={<AudioButton text="Welcome to Practice Paradise! Choose a competency, a difficulty, and how many questions. If you miss a question, it comes back at the end until you get it right. Your stars and report are waiting!" label="Hear guide" size="sm" />}
        />
        <BackLinks />
        <div className="card-pastel space-y-4 p-5 sm:p-6">
          <div>
            <p className="font-display font-extrabold">1️⃣ Choose a competency</p>
            <div className="mt-2 grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-4">
              <button type="button" onClick={() => setSetup({ ...setup, comp: null })}
                className={`btn-chunky px-3 py-2.5 text-xs shadow ${setup.comp === null ? "bg-[#49385C] text-white" : "bg-white text-[#49385C]"}`}>
                🌈 Mixed (all 10)
              </button>
              {COMPETENCIES.map((c) => (
                <button key={c.id} type="button" onClick={() => setSetup({ ...setup, comp: c.id })}
                  className={`btn-chunky px-3 py-2.5 text-xs shadow ${setup.comp === c.id ? "bg-[#49385C] text-white" : "bg-white text-[#49385C]"}`}
                  title={c.title}>
                  {c.emoji} C{c.id} {c.short}
                </button>
              ))}
            </div>
          </div>
          <div>
            <p className="font-display font-extrabold">2️⃣ Choose difficulty</p>
            <div className="mt-2 grid grid-cols-2 gap-2 sm:grid-cols-4">
              {[{ v: null, l: "🌈 Mixed" }, { v: "Easy", l: "🌱 Easy" }, { v: "Intermediate", l: "🌟 Intermediate" }, { v: "Challenge", l: "🔥 Challenge" }].map((d) => (
                <button key={d.l} type="button" onClick={() => setSetup({ ...setup, diff: d.v as Difficulty | null })}
                  className={`btn-chunky px-3 py-2.5 text-xs shadow ${setup.diff === d.v ? "bg-[#49385C] text-white" : "bg-white text-[#49385C]"}`}>
                  {d.l}
                </button>
              ))}
            </div>
          </div>
          <div>
            <p className="font-display font-extrabold">3️⃣ How many questions?</p>
            <div className="mt-2 flex gap-2">
              {[5, 10, 15].map((n) => (
                <button key={n} type="button" onClick={() => setSetup({ ...setup, count: n })}
                  className={`btn-chunky flex-1 py-2.5 text-sm shadow ${setup.count === n ? "bg-[#8b5cf6] text-white" : "bg-white text-[#49385C]"}`}>
                  {n} questions
                </button>
              ))}
            </div>
          </div>
          <div className="rounded-2xl bg-[#E9DEFF]/60 p-3 text-xs font-semibold text-[#6d5a86]">
            🔁 <strong>Retry magic:</strong> missed questions return at the END until you answer them correctly.
            Your report shows first-try accuracy AND final mastery separately. ⭐ Earn stars for first-try correct answers!
          </div>
          <button type="button" onClick={startSession} className="btn-chunky w-full bg-gradient-to-r from-[#8b5cf6] to-[#ec4899] py-3.5 text-lg text-white shadow-xl">
            Start Practice ✨
          </button>
        </div>
      </div>
    );
  }

  /* ---------- RESULTS SCREEN ---------- */
  if (finished) {
    const weak = Object.entries(stats.perComp)
      .filter(([, v]) => v.total > 0 && v.first / v.total < 0.7)
      .map(([k]) => Number(k));
    return (
      <div className="space-y-4 pt-6">
        <PageHeader eyebrow="Results" title="Practice Report Card 📊" subtitle="Real results from your actual answers — first tries and retries counted separately." mascot="plummy" />
        <div className="card-pastel grid gap-3 p-5 text-center sm:grid-cols-3">
          <div className="rounded-2xl bg-[#B8E6D0]/60 p-4">
            <p className="font-display text-3xl font-extrabold">{stats.accuracy.toFixed(0)}%</p>
            <p className="text-xs font-extrabold">🎯 First-try accuracy</p>
            <p className="text-xs font-semibold">{stats.correctFirst}/{scheduled} correct on attempt #1</p>
          </div>
          <div className="rounded-2xl bg-[#CDB8F5]/50 p-4">
            <p className="font-display text-3xl font-extrabold">{stats.mastery.toFixed(0)}%</p>
            <p className="text-xs font-extrabold">🏆 Eventual mastery</p>
            <p className="text-xs font-semibold">{stats.mastered}/{scheduled} mastered after retries</p>
          </div>
          <div className="rounded-2xl bg-[#FFE89A]/60 p-4">
            <p className="font-display text-3xl font-extrabold">{stats.totalAttempts}</p>
            <p className="text-xs font-extrabold">📝 Total attempts</p>
            <p className="text-xs font-semibold">{stats.retried} question(s) needed retries</p>
          </div>
        </div>
        <div className="card-pastel p-5">
          <p className="font-display font-extrabold">📚 Competency breakdown</p>
          <div className="mt-2 space-y-2">
            {Object.entries(stats.perComp).map(([compId, v]) => {
              const c = COMPETENCIES[Number(compId) - 1];
              const pct = v.total ? (v.first / v.total) * 100 : 0;
              return (
                <div key={compId} className="rounded-2xl bg-white/80 p-3">
                  <div className="flex items-center justify-between text-sm font-extrabold">
                    <span>{c.emoji} {c.title}</span>
                    <span className="text-xs">{v.first}/{v.total} first-try · {pct.toFixed(0)}%</span>
                  </div>
                  <div className="mt-1.5"><ProgressBar value={pct} color={pct >= 70 ? "mint" : pct >= 40 ? "rainbow" : "pink"} height="h-2.5" /></div>
                </div>
              );
            })}
          </div>
          {weak.length > 0 ? (
            <div className="mt-3 rounded-2xl bg-amber-50 p-3">
              <p className="text-sm font-extrabold text-amber-800">💡 Recommended review:</p>
              <div className="mt-2 flex flex-wrap gap-2">
                {weak.map((id) => (
                  <Link key={id} href={`/lessons/${id}`} className="btn-chunky inline-flex items-center gap-1 bg-white px-4 py-2 text-xs text-[#49385C] shadow">
                    <GraduationCap size={14} /> Lesson {id}: {COMPETENCIES[id - 1].short}
                  </Link>
                ))}
              </div>
            </div>
          ) : (
            <p className="mt-3 rounded-2xl bg-emerald-50 p-3 text-sm font-extrabold text-emerald-700">🌟 Outstanding! Every competency is at 70%+ — you shine!</p>
          )}
        </div>
        <Celebrate stars={stars} message="Practice stars added to your collection!" />
        <div className="flex flex-wrap justify-center gap-2">
          <button type="button" onClick={() => { setStarted(false); setFinished(false); }} className="btn-chunky inline-flex items-center gap-2 bg-[#8b5cf6] px-6 py-2.5 text-white">
            <RotateCcw size={16} /> Practice Again
          </button>
          <Link href="/dashboard" className="btn-chunky inline-flex items-center gap-2 bg-white px-6 py-2.5 text-[#49385C] shadow">Dashboard</Link>
        </div>
      </div>
    );
  }

  /* ---------- SESSION SCREEN ---------- */
  if (!q) return null;
  const att = (attempts[q.id] ?? 0) + 1;
  const isRetry = att > 1;
  const progressPct = Math.min(100, (idx / Math.max(1, order.length)) * 100);

  return (
    <div className="space-y-4 pt-6">
      <div className="card-pastel flex flex-wrap items-center gap-3 p-4">
        <span className="font-display text-sm font-extrabold">Q{idx + 1} of ~{order.length}</span>
        <div className="min-w-[120px] flex-1"><ProgressBar value={progressPct} /></div>
        <span className="rounded-full bg-[#FFE89A] px-3 py-1 text-xs font-extrabold">🎯 First-try: {stats.correctFirst}</span>
        {isRetry && !answered && <span className="animate-pulse rounded-full bg-amber-400 px-3 py-1 text-xs font-extrabold text-white">🔁 Retry — you&apos;ve got this!</span>}
        <button type="button" onClick={endEarly} className="btn-chunky inline-flex items-center gap-1 bg-white px-3 py-1.5 text-xs text-[#49385C] shadow">
          <Flag size={13} /> Finish
        </button>
      </div>

      <article className="card-pastel space-y-3 p-5">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <span className="flex items-center gap-2">
            <DifficultyBadge level={q.difficulty} />
            <span className="rounded-full px-2.5 py-1 text-[11px] font-extrabold" style={{ background: COMPETENCIES[q.competencyId - 1].color }}>
              {COMPETENCIES[q.competencyId - 1].emoji} C{q.competencyId} · {q.topic}
            </span>
          </span>
          <AudioButton text={`${q.speak}. ${q.type === "mc" && q.options ? "Choices: " + q.options.join(", ") : ""}`} label="Hear question" size="sm" id={`pq-${q.id}-${idx}`} />
        </div>
        <h3 className="font-display text-lg font-extrabold sm:text-xl">{q.prompt}</h3>
        {q.formula && <p className="formula-box rounded-2xl p-2 text-center font-extrabold">{q.formula}</p>}
        <div className="mx-auto max-w-md"><Diagram kind={q.diagram} data={q.diagramData} /></div>

        {q.type === "mc" && q.options ? (
          <div className="grid gap-2 sm:grid-cols-2">
            {q.options.map((op, oi) => {
              const isPicked = picked === oi;
              const showRight = answered && oi === q.correctIndex;
              const showWrong = answered && isPicked && oi !== q.correctIndex;
              return (
                <button
                  key={oi} type="button" onClick={() => submitMC(oi)} disabled={answered}
                  className={`rounded-2xl p-3 text-left text-sm font-bold transition ${showRight ? "correct-glow bg-emerald-50" : showWrong ? "incorrect-shake bg-rose-50" : isPicked ? "bg-[#E9DEFF]" : "bg-slate-50 hover:bg-white"}`}
                  style={{ borderWidth: 3, borderColor: showRight ? "#34d399" : showWrong ? "#fb7185" : isPicked ? "#8b5cf6" : "#e2e8f0" }}
                >
                  {showRight ? "✅ " : showWrong ? "❌ " : ""}{op}
                </button>
              );
            })}
          </div>
        ) : (
          <div className="flex flex-col gap-2 sm:flex-row">
            <input
              value={input} onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && submitNumeric()}
              disabled={answered} inputMode="decimal" placeholder="Type your answer…"
              className="flex-1 rounded-2xl border-4 border-[#CDB8F5] px-4 py-3 font-display text-lg font-extrabold outline-none focus:border-[#8b5cf6]"
              aria-label="Your answer"
            />
            {!answered && (
              <button type="button" onClick={submitNumeric} className="btn-chunky bg-[#8b5cf6] px-8 py-3 text-white">Answer ✨</button>
            )}
          </div>
        )}

        {answered && (
          <div className="pop-in space-y-2">
            <FeedbackBanner
              kind={ok ? "correct" : "incorrect"}
              title={ok ? (isRetry ? "Correct — mastered! Removed from retry queue! 🎉" : "Correct! Brilliant! 🎉") : "Not quite — this question will return at the end! 🔁"}
              message={ok ? q.explanation : `${q.type === "mc" ? `Answer: "${q.options?.[q.correctIndex ?? 0]}". ` : `Answer: ${q.correctNumeric}${q.unit ? " " + q.unit : ""}. `}${q.explanation}`}
            />
            <div className="flex justify-end">
              <AudioButton text={`${ok ? "Correct! " : "Study this: "}${q.explanation}`} label="Hear why" size="sm" id={`pqe-${q.id}-${idx}`} />
            </div>
            <button type="button" onClick={nextQ} className="btn-chunky inline-flex w-full items-center justify-center gap-2 bg-[#49385C] py-3 text-white sm:w-auto sm:px-10">
              {idx + 1 >= order.length ? "See Results 🏁" : "Next ➜"} <ArrowRight size={16} />
            </button>
          </div>
        )}
      </article>
      {!answered && <p className="text-center text-xs font-bold text-[#6d5a86]">Attempt #{att} · Scheduled: {scheduled} · Queue: {order.length} (retries join the end!)</p>}
    </div>
  );
}
