"use client";

import Link from "next/link";
import { Trophy } from "lucide-react";
import { GAMES } from "@/data/games";
import { COMPETENCIES } from "@/data/competencies";
import { useProgress } from "@/lib/progress";
import { PageHeader, BackLinks, Mascot } from "@/components/ui";
import AudioButton from "@/components/AudioButton";

export default function GamesPage() {
  const { state } = useProgress();

  return (
    <div className="space-y-5 pt-6">
      <PageHeader
        eyebrow="Mini-game world"
        title="Starland Games: Play, Learn, and Shine!"
        subtitle="10 playable games across every competency. Earn stars for finishing, for correct answers, and for perfect scores!"
        mascot="sunny"
        right={<AudioButton text="Welcome to Starland Games! Pick any game, choose your level, and collect stars. You earn two stars for finishing, one star per correct answer, and three bonus stars for a perfect score!" label="Hear rules" size="sm" />}
      />
      <BackLinks />

      <div className="card-pastel flex flex-col items-center gap-2 p-4 text-center sm:flex-row sm:text-left">
        <Mascot name="sunny" size={70} mood="party" />
        <p className="flex-1 text-sm font-bold text-[#6d5a86]">
          ⭐ <strong>Star rules:</strong> +2 completion · +1 per correct · +3 perfect bonus.
          Replays count — keep beating your best! Your best scores are saved below.
        </p>
        <Link href="/progress" className="btn-chunky inline-flex items-center gap-1 bg-[#49385C] px-4 py-2 text-xs text-white">
          <Trophy size={14} /> My Stars
        </Link>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {GAMES.map((g, i) => {
          const plays = Object.entries(state.gameBest).filter(([k]) => k.startsWith(g.id));
          const totalPlays = plays.reduce((a, [, v]) => a + v.plays, 0);
          const best = plays.reduce((a, [, v]) => Math.max(a, v.best), 0);
          const hasPerfect = plays.some(([, v]) => v.perfects > 0);
          const mascots = ["minty", "plummy", "skye", "sunny", "sunny", "berry", "berry", "rainbow", "skye", "rainbow"] as const;
          return (
            <Link
              key={g.id}
              href={`/games/${g.id}`}
              className="card-pastel group relative overflow-hidden p-5 transition hover:scale-[1.02]"
            >
              <div className="absolute -right-6 -top-6 h-24 w-24 rounded-full opacity-60" style={{ background: g.color }} aria-hidden />
              <div className="relative flex items-start gap-3">
                <span className="grid h-16 w-16 shrink-0 place-items-center rounded-3xl text-4xl shadow" style={{ background: g.color }} aria-hidden>
                  {g.emoji}
                </span>
                <div>
                  <p className="text-[11px] font-extrabold uppercase tracking-widest text-[#6d5a86]">Game {i + 1}</p>
                  <h2 className="font-display text-lg font-extrabold leading-tight">{g.title}</h2>
                  <p className="text-xs font-bold text-[#6d5a86]">{g.tagline}</p>
                </div>
              </div>
              <div className="relative mt-2 flex flex-wrap gap-1">
                {g.competencyIds.map((id) => (
                  <span key={id} className="rounded-full px-2 py-0.5 text-[10px] font-extrabold" style={{ background: `${COMPETENCIES[id - 1].color}88` }}>
                    {COMPETENCIES[id - 1].emoji} C{id}
                  </span>
                ))}
                {g.kind === "race" && <span className="rounded-full bg-[#49385C] px-2 py-0.5 text-[10px] font-extrabold text-white">⏱️ Timed</span>}
                {g.kind === "match" && <span className="rounded-full bg-[#0d9488] px-2 py-0.5 text-[10px] font-extrabold text-white">🧩 Matching</span>}
              </div>
              <div className="relative mt-3 flex items-center justify-between">
                <span className="text-xs font-extrabold text-[#6d5a86]">
                  {totalPlays > 0 ? <>🎮 {totalPlays} plays · Best {best} {hasPerfect && "🏆"}</> : "✨ Not played yet"}
                </span>
                <span className="btn-chunky bg-[#49385C] px-5 py-2 text-xs text-white">Play ➜</span>
              </div>
            </Link>
          );
        })}
      </div>
    </div>
  );
}
