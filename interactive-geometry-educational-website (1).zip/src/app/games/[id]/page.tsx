"use client";

import Link from "next/link";
import { useParams } from "next/navigation";
import { gameById } from "@/data/games";
import { PageHeader, BackLinks } from "@/components/ui";
import GameRunner from "@/components/GameRunner";

export default function GameDetailPage() {
  const params = useParams<{ id: string }>();
  const game = gameById(params.id);

  if (!game) {
    return (
      <div className="pt-6">
        <BackLinks />
        <div className="card-pastel mt-4 p-8 text-center">
          <p className="font-display text-2xl font-extrabold">Game not found 😢</p>
          <Link href="/games" className="btn-chunky mt-3 inline-block bg-[#49385C] px-6 py-2.5 text-white">Back to Starland</Link>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-5 pt-6">
      <PageHeader
        eyebrow={`Starland Game · ${game.kind === "race" ? "⏱️ Timed Race" : game.kind === "match" ? "🧩 Matching" : "❓ Quiz Challenge"}`}
        title={`${game.emoji} ${game.title}`}
        subtitle={game.instructions}
        mascot="sunny"
      />
      <BackLinks />
      <GameRunner game={game} />
    </div>
  );
}
