"use client";

import { useMemo, useState } from "react";
import { Search, BookOpen } from "lucide-react";
import { COMPETENCIES } from "@/data/competencies";
import { DEFINITIONS } from "@/data/definitions";
import { PageHeader, BackLinks, Mascot, Formula, DifficultyBadge } from "@/components/ui";
import Diagram from "@/components/Diagram";
import AudioButton from "@/components/AudioButton";

export default function DefinitionsPage() {
  const [query, setQuery] = useState("");
  const [comp, setComp] = useState<number | null>(null);
  const [openId, setOpenId] = useState<string | null>(null);

  const results = useMemo(() => {
    const q = query.trim().toLowerCase();
    return DEFINITIONS.filter((d) => {
      if (comp !== null && d.competencyId !== comp) return false;
      if (!q) return true;
      return (d.term + " " + d.definition + " " + d.example).toLowerCase().includes(q);
    });
  }, [query, comp]);

  const opened = DEFINITIONS.find((d) => d.id === openId) ?? null;

  return (
    <div className="space-y-5 pt-6">
      <PageHeader
        eyebrow="Glossary"
        title="Definitions: Learn the Language of Mathematics!"
        subtitle="Search, browse, and listen to friendly explanations of every important word."
        mascot="berry"
        right={<AudioButton text="Welcome to Definitions! Search for a word, pick a competency, and tap any card to see its picture, formula, and real world example. Press the speaker to hear it read aloud." label="Hear guide" size="sm" />}
      />
      <BackLinks />

      {/* search + filters */}
      <div className="card-pastel p-4">
        <label className="flex items-center gap-2 rounded-2xl bg-white px-4 py-3 shadow-inner">
          <Search size={18} className="shrink-0 text-[#6d5a86]" />
          <input
            value={query} onChange={(e) => setQuery(e.target.value)}
            placeholder="Search words like 'pyramid', 'scale', 'sine'..."
            className="w-full bg-transparent text-sm font-bold outline-none placeholder:text-[#6d5a86]/60"
            aria-label="Search definitions"
          />
        </label>
        <div className="scrollbar-cute mt-3 flex gap-2 overflow-x-auto pb-1">
          <button type="button" onClick={() => setComp(null)} className={`btn-chunky shrink-0 px-4 py-2 text-xs shadow ${comp === null ? "bg-[#49385C] text-white" : "bg-white text-[#49385C]"}`}>
            All ({DEFINITIONS.length})
          </button>
          {COMPETENCIES.map((c) => (
            <button
              key={c.id} type="button" onClick={() => setComp(comp === c.id ? null : c.id)}
              className={`btn-chunky shrink-0 px-4 py-2 text-xs shadow ${comp === c.id ? "bg-[#49385C] text-white" : "bg-white text-[#49385C]"}`}
              title={c.title}
            >
              {c.emoji} {c.short}
            </button>
          ))}
        </div>
      </div>

      <p className="text-sm font-bold text-[#6d5a86]" role="status">
        Showing {results.length} word{results.length === 1 ? "" : "s"}{comp ? ` in ${COMPETENCIES[comp - 1].title}` : ""} 📖
      </p>

      <div className="grid gap-4 lg:grid-cols-2">
        <div className="space-y-3">
          {results.map((d) => {
            const c = COMPETENCIES[d.competencyId - 1];
            const active = openId === d.id;
            return (
              <button
                key={d.id} type="button" onClick={() => setOpenId(d.id)}
                className={`w-full rounded-3xl border-4 p-4 text-left shadow transition ${active ? "border-[#8b5cf6] bg-white" : "border-white bg-white/85 hover:bg-white"}`}
                aria-expanded={active}
              >
                <span className="flex items-start justify-between gap-2">
                  <span>
                    <span className="font-display text-lg font-extrabold text-[#49385C]">{d.term}</span>
                    <span className="mt-1 block text-sm font-semibold text-[#6d5a86]">{d.definition.slice(0, 110)}…</span>
                  </span>
                  <span className="shrink-0 rounded-full px-2.5 py-1 text-[11px] font-extrabold text-[#49385C]" style={{ background: c.color }}>
                    {c.emoji} C{d.competencyId}
                  </span>
                </span>
              </button>
            );
          })}
          {results.length === 0 && (
            <div className="card-pastel p-6 text-center">
              <Mascot name="berry" size={90} mood="thinking" />
              <p className="font-display mt-2 text-lg font-extrabold">Hmm, no words found!</p>
              <p className="text-sm font-semibold text-[#6d5a86]">Try another spelling or pick a different competency. 💖</p>
            </div>
          )}
        </div>

        {/* detail panel */}
        <div className="lg:sticky lg:top-24 lg:self-start">
          {opened ? (
            <article className="pop-in card-pastel space-y-3 p-5" aria-live="polite">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <span className="inline-flex items-center gap-1.5 rounded-full bg-[#E9DEFF] px-3 py-1 text-xs font-extrabold">
                  <BookOpen size={13} /> {COMPETENCIES[opened.competencyId - 1].emoji} {COMPETENCIES[opened.competencyId - 1].title}
                </span>
                <AudioButton text={`${opened.term}. ${opened.speakable} ${opened.formulaSpeak ?? ""} Example: ${opened.example}`} label="Listen" size="sm" id={`def-${opened.id}`} />
              </div>
              <h2 className="font-display text-2xl font-extrabold">{opened.term}</h2>
              <p className="rounded-2xl bg-white p-3 text-sm font-semibold leading-relaxed">{opened.definition}</p>
              {opened.formula && <Formula speak={opened.formulaSpeak}>{opened.formula}</Formula>}
              <Diagram kind={opened.diagram} data={opened.diagramData} />
              <div className="rounded-2xl bg-[#B8E6D0]/50 p-3">
                <p className="text-xs font-extrabold uppercase tracking-wider text-[#0d9488]">🌍 Real-world example</p>
                <p className="mt-1 text-sm font-semibold">{opened.example}</p>
              </div>
              {opened.extra && (
                <div className="rounded-2xl bg-[#FFE89A]/60 p-3">
                  <p className="text-xs font-extrabold uppercase tracking-wider text-[#b45309]">✨ Extra sparkle</p>
                  <p className="mt-1 text-sm font-semibold">{opened.extra}</p>
                </div>
              )}
            </article>
          ) : (
            <div className="card-pastel flex h-full min-h-[300px] flex-col items-center justify-center p-6 text-center">
              <Mascot name="berry" size={110} />
              <p className="font-display mt-2 text-xl font-extrabold">Pick a word to explore! 📖</p>
              <p className="max-w-xs text-sm font-semibold text-[#6d5a86]">Every card has a picture, a formula, a real-life example, and a listen button.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
