import { NextResponse } from "next/server";
import { db } from "@/db";
import { leaderboard } from "@/db/schema";
import { desc, sql } from "drizzle-orm";

export async function GET() {
  try {
    const rows = await db.select().from(leaderboard).orderBy(desc(leaderboard.stars)).limit(20);
    return NextResponse.json({ shared: true, rows });
  } catch (e) {
    console.error("leaderboard GET failed", e);
    return NextResponse.json({ shared: false, rows: [] });
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json().catch(() => ({}));
    const nickname = String(body.nickname ?? "").trim().slice(0, 24);
    const stars = Math.max(0, Math.min(100000, Math.floor(Number(body.stars) || 0)));
    const activities = Math.max(0, Math.min(100000, Math.floor(Number(body.activities) || 0)));
    if (!nickname) return NextResponse.json({ ok: false, error: "nickname required" }, { status: 400 });
    if (!/^[A-Za-z0-9 _.\-★⭐🐻🌈✨]+$/.test(nickname)) {
      return NextResponse.json({ ok: false, error: "invalid nickname" }, { status: 400 });
    }
    await db
      .insert(leaderboard)
      .values({ nickname, stars, activities, updatedAt: new Date() })
      .onConflictDoUpdate({
        target: leaderboard.nickname,
        set: {
          stars: sql`GREATEST(${leaderboard.stars}, ${stars})`,
          activities: sql`GREATEST(${leaderboard.activities}, ${activities})`,
          updatedAt: new Date(),
        },
      });
    return NextResponse.json({ ok: true });
  } catch (e) {
    console.error("leaderboard POST failed", e);
    return NextResponse.json({ ok: false }, { status: 500 });
  }
}
