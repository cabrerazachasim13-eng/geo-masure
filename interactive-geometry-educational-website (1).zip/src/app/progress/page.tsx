"use client";

import { useEffect, useState } from "react";
import { Pencil, Trash2, Globe, MonitorSmartphone, Medal } from "lucide-react";
import { COMPETENCIES } from "@/data/competencies";
import { useProgress, BADGE_DEFS } from "@/lib/progress";
import { GAMES } from "@/data/games";
import { PageHeader, BackLinks, ProgressBar, StarsPill, Mascot } from "@/components/ui";
import AudioButton from "@/components/AudioButton";

interface BoardRow { nickname: string; stars: number; activities: number }

const RANK_TITLES: [number, string][] = [
  [300, "👑 Rainbow Royalty"],
  [150, "💫 Geometry Superstar"],
  [80, "🌟 Shining Star"],
  [30, "✨ Rising Star"],
  [10, "🌱 Sparkle Sprout"],
  [0, "🐾 Curious Cub"],
];

function rankFor(stars: number) {
  return RANK_TITLES.find(([t]) => stars >= t)?.[1] ?? "🐾 Curious Cub";
}

export default function ProgressPage() {
  const { state, setNickname, resetAll, overallProgress } = useProgress();
  const [editing, setEditing] = useState(false);
  const [name, setName] = useState(state.nickname);
  const [board, setBoard] = useState<BoardRow[]>([]);
  const [shared, setShared] = useState<boolean | null>(null);

  useEffect(() => { setName(state.nickname); }, [state.nickname]);

  useEffect(() => {
    fetch("/api/leaderboard")
      .then((r) => r.json())
      .then((j) => {
        setShared(j.shared === true && Array.isArray(j.rows) && j.rows.length > 0 ? true : j.shared);
        setBoard(Array.isArray(j.rows) ? j.rows : []);
      })
      .catch(() => setShared(false));
  }, [state.stars]);

  const saveName = () => {
    setNickname(name.trim() || "Starry Cub");
    setEditing(false);
  };

  const accuracy = state.practiceAnswered > 0 ? (state.practiceCorrectFirst / state.practiceAnswered) * 100 : null;
  const recent = [...state.activities].reverse().slice(0, 8);

  return (
    <div className="space-y-5 pt-6">
      <PageHeader
        eyebrow="Achievements"
        title="My Stars, Badges & Rankings! 🏆"
        subtitle="Your progress is saved in this browser and synced to the class leaderboard."
        mascot="rainbow"
        right={<StarsPill stars={state.stars} />}
      />
      <BackLinks />

      {/* identity + rank */}
      <div className="card-pastel flex flex-col items-center gap-4 p-5 sm:flex-row">
        <Mascot name="rainbow" size={100} mood="party" />
        <div className="flex-1 text-center sm:text-left">
          {editing ? (
            <span className="flex flex-col gap-2 sm:flex-row">
              <input
                value={name} onChange={(e) => setName(e.target.value)} maxLength={24}
                placeholder="Nickname or student code"
                className="rounded-2xl border-4 border-[#CDB8F5] px-4 py-2 font-display text-lg font-extrabold outline-none"
                aria-label="Nickname"
              />
              <button type="button" onClick={saveName} className="btn-chunky bg-[#8b5cf6] px-6 py-2 text-white">Save 💾</button>
            </span>
          ) : (
            <span className="flex flex-wrap items-center justify-center gap-2 sm:justify-start">
              <span className="font-display text-2xl font-extrabold">{state.nickname || "Starry Cub"}</span>
              <button type="button" onClick={() => setEditing(true)} className="btn-chunky inline-flex items-center gap-1 bg-white px-3 py-1.5 text-xs text-[#49385C] shadow" aria-label="Edit nickname">
                <Pencil size={13} /> {state.nickname ? "Edit" : "Set nickname"}
              </button>
            </span>
          )}
          <p className="font-display mt-1 text-lg font-extrabold text-[#7c3aed]">{rankFor(state.stars)}</p>
          <p className="text-xs font-semibold text-[#6d5a86]">Use a nickname or anonymous student code — never share private info! 🔒</p>
          <div className="mt-2 flex justify-center sm:justify-start">
            <AudioButton text={`Hello ${state.nickname || "Superstar"}! You have ${state.stars} stars and the rank ${rankFor(state.stars)}. Keep learning to climb higher!`} label="Hear my report" size="sm" />
          </div>
        </div>
        <div className="grid w-full grid-cols-2 gap-2 text-center sm:w-56">
          <div className="rounded-2xl bg-[#FFE89A]/70 p-3"><p className="font-display text-2xl font-extrabold">⭐{state.stars}</p><p className="text-[11px] font-extrabold">Total stars</p></div>
          <div className="rounded-2xl bg-[#B8E6D0]/70 p-3"><p className="font-display text-2xl font-extrabold">{overallProgress}%</p><p className="text-[11px] font-extrabold">Overall</p></div>
          <div className="rounded-2xl bg-[#E9DEFF] p-3"><p className="font-display text-2xl font-extrabold">{state.completedLessons.length}/10</p><p className="text-[11px] font-extrabold">Lessons</p></div>
          <div className="rounded-2xl bg-[#FFC5DD]/60 p-3"><p className="font-display text-2xl font-extrabold">{accuracy === null ? "—" : `${accuracy.toFixed(0)}%`}</p><p className="text-[11px] font-extrabold">Practice accuracy</p></div>
        </div>
      </div>

      {/* badges */}
      <section className="card-pastel p-5" aria-label="Achievement badges">
        <p className="font-display text-lg font-extrabold">🎖️ Achievement Badges ({state.badges.length}/{BADGE_DEFS.length})</p>
        <div className="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-5">
          {BADGE_DEFS.map((b) => {
            const earned = state.badges.includes(b.id);
            return (
              <div key={b.id} className={`rounded-3xl border-4 p-3 text-center ${earned ? "border-amber-300 bg-gradient-to-b from-amber-50 to-white" : "border-slate-100 bg-slate-50 opacity-60"}`} title={b.desc}>
                <p className="text-3xl">{earned ? b.emoji : "🔒"}</p>
                <p className="font-display text-sm font-extrabold">{b.name}</p>
                <p className="text-[11px] font-semibold text-[#6d5a86]">{b.desc}</p>
              </div>
            );
          })}
        </div>
      </section>

      {/* competency progress */}
      <section className="card-pastel p-5" aria-label="Competency progress">
        <p className="font-display text-lg font-extrabold">🗺️ Progress across all 10 competencies</p>
        <div className="mt-3 grid gap-2.5 sm:grid-cols-2">
          {COMPETENCIES.map((c, i) => (
            <div key={c.id} className="rounded-2xl bg-white/85 p-3 shadow-sm">
              <div className="flex items-center justify-between text-sm font-extrabold">
                <span>{c.emoji} C{c.id}: {c.short}</span>
                <span className="text-xs text-[#6d5a86]">{Math.round(state.competencyProgress[i])}% · ⭐{state.competencyStars[i]}</span>
              </div>
              <div className="mt-1.5"><ProgressBar value={state.competencyProgress[i]} color={i % 4 === 0 ? "mint" : i % 4 === 1 ? "sky" : i % 4 === 2 ? "pink" : "grape"} height="h-2.5" /></div>
            </div>
          ))}
        </div>
      </section>

      {/* game bests */}
      <section className="card-pastel p-5" aria-label="Game records">
        <p className="font-display text-lg font-extrabold">🎮 Game Records</p>
        <div className="mt-3 grid gap-2 sm:grid-cols-2">
          {GAMES.map((g) => {
            const plays = Object.entries(state.gameBest).filter(([k]) => k.startsWith(g.id));
            const totalPlays = plays.reduce((a, [, v]) => a + v.plays, 0);
            const best = plays.reduce((a, [, v]) => Math.max(a, v.best), 0);
            return (
              <div key={g.id} className="flex items-center gap-3 rounded-2xl bg-white/85 p-2.5">
                <span className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl text-2xl" style={{ background: g.color }}>{g.emoji}</span>
                <div className="flex-1 text-sm">
                  <p className="font-extrabold">{g.title}</p>
                  <p className="text-xs font-bold text-[#6d5a86]">{totalPlays > 0 ? `${totalPlays} plays · best ${best}` : "Not played yet ✨"}</p>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* leaderboard */}
      <section className="card-pastel p-5" aria-label="Leaderboard">
        <p className="font-display flex items-center gap-2 text-lg font-extrabold"><Medal size={20} /> 🏅 Star Rankings</p>
        {shared === true && board.length > 0 ? (
          <p className="mt-1 inline-flex items-center gap-1 rounded-full bg-emerald-100 px-3 py-1 text-xs font-extrabold text-emerald-700">
            <Globe size={13} /> Shared class leaderboard (all devices)
          </p>
        ) : (
          <p className="mt-1 inline-flex items-center gap-1 rounded-full bg-slate-100 px-3 py-1 text-xs font-extrabold text-slate-600">
            <MonitorSmartphone size={13} /> Local ranking — this browser/device only. Set a nickname to join the shared board!
          </p>
        )}
        <ol className="mt-3 space-y-2">
          {(shared === true && board.length > 0
            ? board
            : [{ nickname: state.nickname || "You (this device)", stars: state.stars, activities: state.activities.length }]
          ).map((r, i) => (
            <li key={i} className={`flex items-center gap-3 rounded-2xl p-3 ${r.nickname === state.nickname && state.nickname ? "bg-[#FFE89A]/70" : "bg-white/85"}`}>
              <span className="font-display w-8 text-center text-xl font-extrabold">
                {i === 0 ? "🥇" : i === 1 ? "🥈" : i === 2 ? "🥉" : `#${i + 1}`}
              </span>
              <span className="flex-1 truncate font-extrabold">{r.nickname}</span>
              <span className="text-xs font-bold text-[#6d5a86]">{r.activities} activities</span>
              <span className="rounded-full bg-gradient-to-r from-[#FFE89A] to-[#FFC5DD] px-3 py-1 text-xs font-extrabold">⭐ {r.stars}</span>
            </li>
          ))}
        </ol>
        {shared === null && <p className="mt-2 text-xs font-bold text-[#6d5a86]">Loading leaderboard…</p>}
      </section>

      {/* history */}
      <section className="card-pastel p-5" aria-label="Activity history">
        <p className="font-display text-lg font-extrabold">📜 Recent Adventures</p>
        {recent.length === 0 ? (
          <p className="mt-2 text-sm font-semibold text-[#6d5a86]">No adventures yet — finish a lesson, game, or practice to start your story! ✨</p>
        ) : (
          <ul className="mt-2 space-y-1.5">
            {recent.map((a) => (
              <li key={a.id} className="flex items-center justify-between gap-2 rounded-2xl bg-white/80 p-2.5 text-sm font-semibold">
                <span className="truncate">🌟 {a.label} <span className="text-xs text-[#6d5a86]">· C{a.competency + 1}</span></span>
                <span className="shrink-0 rounded-full bg-[#FFE89A] px-2 py-0.5 text-xs font-extrabold">+{a.stars}⭐</span>
              </li>
            ))}
          </ul>
        )}
      </section>

      <div className="flex justify-center">
        <button
          type="button"
          onClick={() => { if (confirm("Reset ALL stars and progress on this device? This cannot be undone.")) resetAll(); }}
          className="btn-chunky inline-flex items-center gap-2 bg-white px-5 py-2.5 text-sm text-rose-500 shadow"
        >
          <Trash2 size={15} /> Reset my progress on this device
        </button>
      </div>
    </div>
  );
}
