"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Sparkles, BookOpen, GraduationCap, Gamepad2, ClipboardCheck, Star } from "lucide-react";
import { Mascot, StarField, Cloud, Rainbow } from "@/components/ui";
import AudioButton from "@/components/AudioButton";

const FLOATERS = ["🧊", "📦", "🔺", "⭕", "📏", "📐", "⭐", "🌟", "💖", "🎲", "⏰", "🌡️"];

export default function LandingPage() {
  const router = useRouter();
  const [popping, setPopping] = useState(false);

  const explore = () => {
    setPopping(true);
    setTimeout(() => router.push("/dashboard"), 450);
  };

  return (
    <div className="relative -mx-3 overflow-hidden sm:-mx-4">
      {/* Hero */}
      <div className="relative bg-gradient-to-b from-[#CDB8F5] via-[#FFC5DD]/60 to-[#FFF9F2] px-4 pb-10 pt-10 sm:px-8 sm:pt-14">
        <StarField count={22} />
        <Cloud className="float-slower absolute left-[4%] top-8 w-36 opacity-80 sm:w-52" />
        <Cloud className="float-slow absolute right-[5%] top-24 w-28 opacity-70 sm:w-44" />
        <Cloud className="float-slow absolute bottom-6 left-[12%] w-24 opacity-60" />

        {/* floating shapes */}
        <div className="pointer-events-none absolute inset-0" aria-hidden>
          {FLOATERS.map((e, i) => (
            <span
              key={i}
              className={i % 3 === 0 ? "float-slow absolute" : i % 3 === 1 ? "float-slower absolute" : "float-fast absolute"}
              style={{
                left: `${(i * 83) % 100}%`,
                top: `${8 + ((i * 37) % 70)}%`,
                fontSize: `${20 + ((i * 13) % 22)}px`,
                animationDelay: `${(i % 5) * 0.5}s`,
                opacity: 0.85,
              }}
            >
              {e}
            </span>
          ))}
        </div>

        <div className="relative mx-auto max-w-4xl text-center">
          <div className="pop-in mb-3 inline-flex items-center gap-2 rounded-full bg-white/85 px-4 py-1.5 text-xs font-extrabold text-[#49385C] shadow sm:text-sm">
            <Sparkles size={15} /> A Grade 11 Geometry &amp; Measurement Adventure
          </div>
          <h1
            className="font-display text-6xl font-extrabold leading-none tracking-tight sm:text-8xl"
            style={{
              background: "linear-gradient(92deg,#7c3aed 5%,#db2777 30%,#b45309 50%,#0d9488 70%,#2563eb 95%)",
              WebkitBackgroundClip: "text",
              backgroundClip: "text",
              color: "transparent",
              filter: "drop-shadow(0 3px 0 rgba(255,255,255,.9))",
            }}
          >
            GEO MEASURE
          </h1>
          <p className="font-display mt-2 text-xl font-extrabold text-[#49385C] sm:text-3xl">
            “See It, Hear It, and Solve It!” 🌈
          </p>
          <p className="mx-auto mt-4 max-w-2xl rounded-3xl bg-white/75 p-4 text-sm font-semibold text-[#49385C] shadow sm:text-base">
            Welcome to Geo Measure, your colorful learning adventure! Discover the wonderful world of
            geometry and measurement through fun definitions, visual lessons, interactive games, and
            exciting practice challenges.
          </p>
          <p className="font-display mx-auto mt-3 max-w-xl text-base font-extrabold text-[#6d28d9] sm:text-lg">
            Learn at your own pace, collect stars, and become a Geometry and Measurement Superstar! ⭐
          </p>
          <div className="mt-2 flex justify-center">
            <AudioButton
              text="Welcome to Geo Measure, your colorful learning adventure! Discover geometry and measurement through fun definitions, visual lessons, interactive games, and exciting practice challenges. Learn at your own pace, collect stars, and become a Geometry and Measurement Superstar!"
              label="Hear Welcome"
              size="sm"
            />
          </div>

          <button
            type="button"
            onClick={explore}
            className={`btn-chunky mt-5 bg-gradient-to-r from-[#8b5cf6] via-[#ec4899] to-[#f59e0b] px-12 py-4 text-2xl text-white shadow-2xl sm:px-16 sm:text-3xl ${popping ? "scale-125" : "bounce-soft"}`}
            aria-label="Explore Geo Measure dashboard"
          >
            {popping ? "✨ Yay! ✨" : "EXPLORE 🚀"}
          </button>

          {/* mascots */}
          <div className="mt-8 flex flex-wrap items-end justify-center gap-1 sm:gap-3" aria-label="Geo Measure bear mascots">
            {(["minty", "berry", "sunny", "skye", "plummy", "rainbow"] as const).map((m, i) => (
              <div key={m} className="pop-in flex flex-col items-center" style={{ animationDelay: `${i * 0.1}s` }}>
                <span className={i % 2 ? "float-slow" : "float-slower"}>
                  <Mascot name={m} size={i === 2 ? 110 : 84} mood={i === 2 ? "party" : "happy"} />
                </span>
              </div>
            ))}
          </div>
          <div className="mt-2 flex justify-center"><Rainbow className="w-56 sm:w-72" /></div>
        </div>
      </div>

      {/* Feature strip */}
      <div className="mx-auto max-w-6xl px-4 py-10 sm:px-8">
        <h2 className="font-display text-center text-2xl font-extrabold text-[#49385C] sm:text-3xl">
          Your Learning World Awaits! 🎈
        </h2>
        <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {[
            { icon: BookOpen, title: "Definitions", desc: "Friendly words, formulas & audio.", color: "#B8E6D0" },
            { icon: GraduationCap, title: "Lessons", desc: "Step-by-step visual adventures.", color: "#CDB8F5" },
            { icon: Gamepad2, title: "Games", desc: "10 mini-games. Win stars!", color: "#FFC5DD" },
            { icon: ClipboardCheck, title: "Practices", desc: "100+ questions with feedback.", color: "#B9E3FA" },
          ].map((f) => (
            <div key={f.title} className="card-pastel wiggle-hover p-5 text-center">
              <span className="mx-auto grid h-14 w-14 place-items-center rounded-2xl shadow" style={{ background: f.color }} aria-hidden>
                <f.icon size={28} className="text-[#49385C]" />
              </span>
              <p className="font-display mt-2 text-lg font-extrabold">{f.title}</p>
              <p className="text-sm font-semibold text-[#6d5a86]">{f.desc}</p>
            </div>
          ))}
        </div>

        <div className="card-pastel mt-6 flex flex-col items-center gap-3 p-6 text-center sm:flex-row sm:text-left">
          <Mascot name="rainbow" size={90} mood="party" />
          <div className="flex-1">
            <p className="font-display text-xl font-extrabold">Collect stars in all 10 competencies! <Star className="inline fill-amber-400 text-amber-400" size={20} /></p>
            <p className="text-sm font-semibold text-[#6d5a86]">
              Metric units · Conversions · Surface area · Volume · Maps · Money · Time · Temperature · Plane geometry · Trigonometry
            </p>
          </div>
          <button type="button" onClick={explore} className="btn-chunky bg-[#49385C] px-8 py-3 text-lg text-white shadow-xl">
            Start Learning 💫
          </button>
        </div>
      </div>
    </div>
  );
}
