import type { DiagramKind } from "./definitions";

export interface WorkedExample {
  title: string;
  given: string;
  asked: string;
  formula: string;
  formulaSpeak: string;
  steps: string[];
  answer: string;
  why: string;
  diagram: DiagramKind;
  diagramData?: Record<string, number | string>;
  audio: string;
}

export interface LessonCheck {
  question: string;
  options: string[];
  answer: number;
  explanation: string;
}

export type LessonTool =
  | "unit-compare" | "converter" | "prism-lab" | "volume-lab" | "map-lab"
  | "currency-lab" | "time-lab" | "temp-lab" | "triangle-lab" | "trig-lab";

export interface Lesson {
  id: string;
  competencyId: number;
  title: string;
  objectives: string[];
  intro: string;
  introSpeak: string;
  keyTerms: { term: string; def: string }[];
  formulas: { text: string; speak: string }[];
  workedExamples: WorkedExample[];
  applications: string[];
  mistakes: { mistake: string; fix: string }[];
  check: LessonCheck[];
  tool: LessonTool;
  toolTitle: string;
  toolDesc: string;
}

export const LESSONS: Lesson[] = [
  {
    id: "1", competencyId: 1, title: "Metric Units & Measurements",
    objectives: [
      "Choose the right metric unit for length, mass, and capacity.",
      "Compare very small and very large quantities.",
      "Use metric prefixes (milli-, centi-, kilo-) with confidence.",
    ],
    intro: "Welcome, little measurer! Every ruler, scale, and beaker in science speaks the same language: the metric system. Today Minty will help you pick the perfect unit for every job — from the thickness of a coin to the distance between cities.",
    introSpeak: "Welcome, little measurer! Every ruler, scale, and beaker in science speaks the same language: the metric system. Today we will help you pick the perfect unit for every job, from the thickness of a coin to the distance between cities.",
    keyTerms: [
      { term: "Length", def: "How long or far something is: mm, cm, m, km." },
      { term: "Mass", def: "How much matter an object has: mg, g, kg, tonne." },
      { term: "Capacity", def: "How much a container holds: mL, L." },
      { term: "Prefix", def: "A word part like kilo- or milli- that scales a unit by a power of 10." },
    ],
    formulas: [
      { text: "1 km = 1,000 m = 100,000 cm", speak: "One kilometer equals one thousand meters, equals one hundred thousand centimeters." },
      { text: "1 kg = 1,000 g · 1 g = 1,000 mg", speak: "One kilogram equals one thousand grams. One gram equals one thousand milligrams." },
      { text: "1 L = 1,000 mL · 1 mL = 1 cm³", speak: "One liter equals one thousand milliliters. One milliliter equals one cubic centimeter." },
    ],
    workedExamples: [
      {
        title: "Picking a length unit", given: "You must report: (a) pencil length, (b) distance Manila → Baguio.", asked: "Which unit fits each measurement?",
        formula: "tiny → mm · everyday → cm/m · far → km", formulaSpeak: "Tiny things use millimeters. Everyday things use centimeters or meters. Far distances use kilometers.",
        steps: ["A pencil is about as long as your hand → centimeters fit perfectly.", "Cities are hundreds of thousands of meters apart → kilometers keep the number small.", "So: pencil ≈ 15 cm; Manila → Baguio ≈ 250 km."],
        answer: "(a) centimeters (b) kilometers", why: "Good units keep numbers friendly — not too tiny, not too huge.",
        diagram: "ruler", audio: "A pencil is about fifteen centimeters long. The distance from Manila to Baguio is about two hundred fifty kilometers. Centimeters fit hands; kilometers fit journeys.",
      },
      {
        title: "Picking mass and capacity units", given: "A tablet of medicine, a student, a spoon of syrup, a water drum.", asked: "Assign mg/g/kg and mL/L correctly.",
        formula: "mg → g → kg → t · mL → L", formulaSpeak: "Milligrams to grams to kilograms to tonnes. Milliliters to liters.",
        steps: ["Medicine tablet: a fraction of a gram → milligrams (e.g., 500 mg).", "Student: tens of thousands of grams → kilograms (e.g., 48 kg).", "Spoon of syrup → milliliters (5 mL); water drum → liters (200 L)."],
        answer: "tablet: mg · student: kg · spoon: mL · drum: L", why: "Match the unit size to the object size so values stay easy to read.",
        diagram: "beaker", audio: "Medicine uses milligrams. People use kilograms. Spoons use milliliters. Drums use liters. Match the unit size to the object size.",
      },
    ],
    applications: ["Scientists report lab masses in grams and milligrams so experiments repeat exactly.", "Engineers design roads in kilometers but bolts in millimeters.", "Pharmacists must never confuse mg with g — a 1,000× mistake could be dangerous!"],
    mistakes: [
      { mistake: "Writing 250 km as 250 m for a city distance.", fix: "Picture the size first: meters fit rooms, kilometers fit journeys." },
      { mistake: "Mixing mass (kg) with capacity (L).", fix: "Ask: am I weighing it (kg) or filling it (L)? 1 L of water ≈ 1 kg only for water!" },
    ],
    check: [
      { question: "Which unit best measures the length of a pencil?", options: ["15 millimeters", "15 centimeters", "15 meters", "15 kilometers"], answer: 1, explanation: "A pencil is about a hand long — 15 cm is perfect. 15 mm is a thumbnail; 15 m is a bus!" },
      { question: "Which unit best measures the mass of a student?", options: ["48 milligrams", "48 grams", "48 kilograms", "48 tonnes"], answer: 2, explanation: "People weigh tens of kilograms. 48 g is an egg; 48 tonnes is a truck!" },
      { question: "How many milliliters are in 1 liter?", options: ["10", "100", "1,000", "10,000"], answer: 2, explanation: "The prefix milli- means one-thousandth, so 1 L = 1,000 mL." },
    ],
    tool: "unit-compare", toolTitle: "Unit Comparison Lab", toolDesc: "Slide through sizes and watch which unit fits best!",
  },
  {
    id: "2", competencyId: 2, title: "Conversion of Measurements",
    objectives: [
      "Convert metric-to-metric using the prefix ladder.",
      "Convert between metric and customary systems with conversion factors.",
      "Convert area and volume units with squared and cubed factors.",
    ],
    intro: "Converting units is like exchanging game tokens: the amount stays the same, only the wrapper changes! Skye will show you how conversion factors — fractions equal to 1 — let old units cancel and new units shine.",
    introSpeak: "Converting units is like exchanging game tokens. The amount stays the same, only the wrapper changes. Conversion factors let old units cancel and new units shine.",
    keyTerms: [
      { term: "Conversion factor", def: "A fraction equal to 1 (e.g., 100 cm / 1 m) used to change units." },
      { term: "Cancel units", def: "Crossing out the same unit on top and bottom, like simplifying a fraction." },
      { term: "Exact vs approximate", def: "1 in = 2.54 cm is exact; 1 mi ≈ 1.609 km is rounded (approximate)." },
    ],
    formulas: [
      { text: "new value = old value × (new unit ÷ old unit)", speak: "New value equals old value times the new unit divided by the old unit." },
      { text: "1 in = 2.54 cm · 1 ft = 30.48 cm · 1 mi ≈ 1.609 km", speak: "One inch equals two point five four centimeters. One foot equals thirty point four eight centimeters. One mile is about one point six zero nine kilometers." },
      { text: "1 m² = 10,000 cm² · 1 m³ = 1,000,000 cm³", speak: "One square meter equals ten thousand square centimeters. One cubic meter equals one million cubic centimeters." },
    ],
    workedExamples: [
      {
        title: "Metric ladder: km → cm", given: "A fun-run route is 3.2 km long.", asked: "How many centimeters is that?",
        formula: "km → m (×1,000) → cm (×100)", formulaSpeak: "Kilometers to meters, times one thousand. Meters to centimeters, times one hundred.",
        steps: ["3.2 km × 1,000 = 3,200 m.", "3,200 m × 100 = 320,000 cm.", "Check: smaller unit → bigger number. ✓"],
        answer: "320,000 cm", why: "Each ladder step multiplies by 10; two jumps (k→base→c) mean ×1,000 then ×100.",
        diagram: "ladder", audio: "Three point two kilometers times one thousand is three thousand two hundred meters. Times one hundred more is three hundred twenty thousand centimeters.",
      },
      {
        title: "Customary bridge: feet → cm", given: "A student is 5 ft 6 in tall.", asked: "Height in centimeters?",
        formula: "total inches × 2.54 cm/in", formulaSpeak: "Total inches times two point five four centimeters per inch.",
        steps: ["5 ft = 5 × 12 = 60 in; plus 6 in = 66 in.", "66 × 2.54 = 167.64 cm.", "Round sensibly: ≈ 168 cm."],
        answer: "≈ 168 cm", why: "1 in = 2.54 cm is exact, so the only rounding is at the end.",
        diagram: "scale-factor", diagramData: { from: "66 in", to: "167.64 cm" }, audio: "Five feet six inches is sixty six inches. Sixty six times two point five four equals about one hundred sixty eight centimeters.",
      },
      {
        title: "Squared units: m² → cm²", given: "A rug covers 2 m².", asked: "Area in square centimeters?",
        formula: "1 m² = (100 cm)² = 10,000 cm²", formulaSpeak: "One square meter equals one hundred centimeters squared, which is ten thousand square centimeters.",
        steps: ["Length factor: 1 m = 100 cm.", "Area factor: square it → 100² = 10,000.", "2 × 10,000 = 20,000 cm²."],
        answer: "20,000 cm²", why: "Area is 2D — the conversion factor gets squared, never used plain!",
        diagram: "cube-fill", audio: "One square meter equals ten thousand square centimeters. Two square meters equal twenty thousand square centimeters.",
      },
    ],
    applications: ["Track coaches convert 100-yard dashes to meters for record books.", "Carpenters convert blueprint inches to centimeters before cutting wood.", "Doctors convert pounds to kilograms for correct medicine doses."],
    mistakes: [
      { mistake: "Using ×100 for m² → cm² (forgetting to square).", fix: "Ask: is it length, area, or volume? Square the factor for area, cube it for volume." },
      { mistake: "Flipping the factor so units don't cancel.", fix: "Write units as a fraction and check: the old unit must appear top AND bottom." },
    ],
    check: [
      { question: "2.5 m = ? cm", options: ["25 cm", "250 cm", "2,500 cm", "0.025 cm"], answer: 1, explanation: "Meters → centimeters multiplies by 100: 2.5 × 100 = 250." },
      { question: "1 m² = ? cm²", options: ["100", "1,000", "10,000", "100,000"], answer: 2, explanation: "Square the length factor: 100² = 10,000." },
      { question: "A 10-inch tablet is about ? cm wide (diagonal).", options: ["4 cm", "25.4 cm", "100 cm", "254 cm"], answer: 1, explanation: "10 × 2.54 = 25.4 cm." },
    ],
    tool: "converter", toolTitle: "Magic Conversion Machine", toolDesc: "Pick a unit, type a value, choose a target — watch the magic!",
  },
  {
    id: "3", competencyId: 3, title: "Surface Area of 3D Objects",
    objectives: [
      "Find the surface area of prisms, pyramids, cylinders, cones, and spheres.",
      "Tell slant height apart from vertical height.",
      "Handle composite solids by counting only exposed faces.",
    ],
    intro: "Imagine gift-wrapping every shape in Shape Land! Surface area tells you exactly how much wrapping paper you need. Plummy will unfold 3D friends into flat nets so you can see every face before you calculate.",
    introSpeak: "Imagine gift wrapping every shape in Shape Land! Surface area tells you exactly how much wrapping paper you need. We will unfold shapes into flat nets so you can see every face.",
    keyTerms: [
      { term: "Surface area", def: "Total area of all outside faces, in square units." },
      { term: "Lateral area", def: "Area of the sides only, excluding base(s)." },
      { term: "Slant height (ℓ)", def: "Diagonal height along a cone/pyramid face — used for surface area." },
      { term: "Net", def: "A flat pattern that folds into a 3D shape." },
    ],
    formulas: [
      { text: "Prism: SA = 2(lw + lh + wh) · Cube: SA = 6s²", speak: "Prism: surface area equals two times length width plus length height plus width height. Cube: six times side squared." },
      { text: "Cylinder: SA = 2πr² + 2πrh", speak: "Cylinder surface area equals two pi r squared plus two pi r h." },
      { text: "Cone: SA = πr² + πrℓ · Sphere: SA = 4πr² · Pyramid: SA = s² + 2sℓ", speak: "Cone: pi r squared plus pi r l. Sphere: four pi r squared. Pyramid: s squared plus two s l." },
    ],
    workedExamples: [
      {
        title: "Rectangular prism gift box", given: "Box: l = 4 cm, w = 3 cm, h = 2 cm.", asked: "How much wrapping paper (surface area)?",
        formula: "SA = 2(lw + lh + wh)", formulaSpeak: "Surface area equals two times the sum of length times width, length times height, and width times height.",
        steps: ["lw = 4×3 = 12; lh = 4×2 = 8; wh = 3×2 = 6.", "Sum: 12 + 8 + 6 = 26.", "Double it: 2 × 26 = 52 cm²."],
        answer: "52 cm²", why: "Each pair of opposite faces matches, so we add one of each pair and double.",
        diagram: "prism-net", audio: "Length times width is twelve. Length times height is eight. Width times height is six. Sum is twenty six. Double it: fifty two square centimeters.",
      },
      {
        title: "Cylinder can", given: "Can: r = 3 cm, h = 10 cm.", asked: "Total surface area?",
        formula: "SA = 2πr² + 2πrh", formulaSpeak: "Surface area equals two pi r squared plus two pi r h.",
        steps: ["Bases: 2π(3²) = 18π ≈ 56.55.", "Curved side unrolls to 2πrh = 2π(3)(10) = 60π ≈ 188.50.", "Total: 78π ≈ 245.04 cm²."],
        answer: "≈ 245.04 cm²", why: "The curved wall becomes a rectangle with width = circumference 2πr.",
        diagram: "cylinder", diagramData: { r: 3, h: 10 }, audio: "Two circular bases give eighteen pi. The curved side unrolls to sixty pi. Total seventy eight pi, about two hundred forty five square centimeters.",
      },
      {
        title: "Cone party hat (slant height!)", given: "Cone: r = 6 cm, vertical h = 8 cm.", asked: "Surface area?",
        formula: "First ℓ = √(r² + h²), then SA = πr² + πrℓ", formulaSpeak: "First find slant height with Pythagoras, then surface area equals pi r squared plus pi r l.",
        steps: ["ℓ = √(36 + 64) = √100 = 10 cm.", "Base: π(36) = 36π ≈ 113.10.", "Side: π(6)(10) = 60π ≈ 188.50.", "Total: 96π ≈ 301.59 cm²."],
        answer: "≈ 301.59 cm²", why: "Surface area needs the diagonal slant height, not the vertical drop.",
        diagram: "cone", audio: "Slant height is the square root of thirty six plus sixty four, which is ten. Base thirty six pi plus side sixty pi equals ninety six pi, about three hundred two square centimeters.",
      },
    ],
    applications: ["Painters estimate wall + ceiling area before buying paint.", "Engineers compute satellite skin area to plan heat shields.", "Bakers compare tray surface areas so cookies bake evenly."],
    mistakes: [
      { mistake: "Using vertical height in cone/pyramid SA formulas.", fix: "Spot the slant: it lies ON the face. Use Pythagoras to find it when missing." },
      { mistake: "Counting glued faces in composite solids.", fix: "Cover the joined spot with your finger — if you can't touch it, don't count it!" },
    ],
    check: [
      { question: "Cube with side 5 cm: SA = ?", options: ["25 cm²", "125 cm²", "150 cm²", "30 cm²"], answer: 2, explanation: "6 × 5² = 6 × 25 = 150 cm²." },
      { question: "Cone SA needs which height?", options: ["Vertical height", "Slant height", "Diameter", "Radius only"], answer: 1, explanation: "The lateral face is measured along the slant ℓ." },
      { question: "Sphere r = 5 cm: SA = ?", options: ["100π cm²", "25π cm²", "50π cm²", "500π cm²"], answer: 0, explanation: "4π(5²) = 100π ≈ 314 cm²." },
    ],
    tool: "prism-lab", toolTitle: "Prism Playground", toolDesc: "Stretch the box and watch every face's area update live!",
  },
  {
    id: "4", competencyId: 4, title: "Volume of 3D Objects",
    objectives: [
      "Compute volumes of prisms, pyramids, cylinders, cones, and spheres.",
      "Explain base area, perpendicular height, and cubic units.",
      "Split composite solids into simple parts and combine volumes.",
    ],
    intro: "If surface area is wrapping paper, volume is the chocolate inside! Plummy will fill every shape with tiny unit cubes so you can SEE why V = Bh, why pyramids take one-third, and why spheres use r³.",
    introSpeak: "If surface area is wrapping paper, volume is the chocolate inside! We will fill every shape with tiny cubes so you can see why each formula works.",
    keyTerms: [
      { term: "Volume", def: "Space inside a 3D object, in cubic units." },
      { term: "Base area (B)", def: "Area of the shape's bottom (or top) face." },
      { term: "Perpendicular height", def: "Straight-down height from base to top — used for volume." },
      { term: "Cubic units", def: "Units like cm³ showing 3 dimensions were multiplied." },
    ],
    formulas: [
      { text: "Prism: V = Bh · Box: V = lwh · Cube: V = s³", speak: "Prism volume equals base area times height. Box: length times width times height. Cube: side cubed." },
      { text: "Pyramid: V = ⅓Bh · Cone: V = ⅓πr²h", speak: "Pyramid: one third base area times height. Cone: one third pi r squared h." },
      { text: "Cylinder: V = πr²h · Sphere: V = ⁴⁄₃πr³", speak: "Cylinder: pi r squared h. Sphere: four thirds pi r cubed." },
    ],
    workedExamples: [
      {
        title: "Fish tank (rectangular prism)", given: "Tank: 50 cm × 30 cm × 40 cm.", asked: "Volume in cm³ and liters?",
        formula: "V = lwh; 1,000 cm³ = 1 L", formulaSpeak: "Volume equals length times width times height. One thousand cubic centimeters equals one liter.",
        steps: ["V = 50 × 30 × 40 = 60,000 cm³.", "Convert: 60,000 ÷ 1,000 = 60 L.", "So the tank holds 60 liters!"],
        answer: "60,000 cm³ = 60 L", why: "Multiplying 3 lengths stacks unit cubes into the full box.",
        diagram: "cube-fill", audio: "Fifty times thirty times forty is sixty thousand cubic centimeters, which is sixty liters of water.",
      },
      {
        title: "Ice-cream cone", given: "Cone: r = 2 cm, h = 9 cm.", asked: "How much ice cream fits?",
        formula: "V = ⅓πr²h", formulaSpeak: "Volume equals one third pi r squared h.",
        steps: ["r² = 4; πr²h = π × 4 × 9 = 36π.", "One-third: 36π ÷ 3 = 12π.", "12π ≈ 37.70 cm³."],
        answer: "≈ 37.70 cm³", why: "Three cones of ice cream exactly fill the matching cylinder!",
        diagram: "cone", audio: "Pi times four times nine is thirty six pi. One third of that is twelve pi, about thirty seven point seven cubic centimeters.",
      },
      {
        title: "Basketball (sphere)", given: "Ball: r = 12 cm.", asked: "Volume of air inside?",
        formula: "V = ⁴⁄₃πr³", formulaSpeak: "Volume equals four thirds pi r cubed.",
        steps: ["r³ = 12³ = 1,728.", "V = ⁴⁄₃π × 1,728 = 2,304π.", "≈ 7,238.23 cm³ ≈ 7.24 L."],
        answer: "≈ 7,238 cm³", why: "Radius cubed shows volume explodes fast — double r, get 8× the volume!",
        diagram: "sphere", diagramData: { r: 12 }, audio: "Twelve cubed is one thousand seven hundred twenty eight. Four thirds pi times that is about seven thousand two hundred thirty eight cubic centimeters.",
      },
    ],
    applications: ["Swimming pools are filled and chlorinated by volume in liters.", "Grain silos (cylinder + cone) are sized by total storage volume.", "Medicine syringes measure tiny volumes in mL = cm³."],
    mistakes: [
      { mistake: "Forgetting the ⅓ for pyramids and cones.", fix: "Chant: 'pointy takes a third!' — anything ending in a point gets × ⅓." },
      { mistake: "Using diameter as radius.", fix: "Halve it first! r = d ÷ 2. Squaring the diameter gives 4× too much." },
    ],
    check: [
      { question: "Cube side 4 cm: V = ?", options: ["16 cm³", "48 cm³", "64 cm³", "12 cm³"], answer: 2, explanation: "4³ = 64 cm³." },
      { question: "Cylinder r = 2, h = 9: V = ?", options: ["18π", "36π", "12π", "72π"], answer: 1, explanation: "π(2²)(9) = 36π ≈ 113 cm³." },
      { question: "Why × ⅓ for a cone?", options: ["Cones are lighter", "3 cones fill its cylinder", "Cones have no base", "It is a guess"], answer: 1, explanation: "Experimentally (and provably), exactly 3 cones fill the matching cylinder." },
    ],
    tool: "volume-lab", toolTitle: "Volume Filling Station", toolDesc: "Grow cylinders, cones, and spheres and compare their volumes!",
  },
  {
    id: "5", competencyId: 5, title: "Scale, Maps & Blueprints",
    objectives: [
      "Read scales and representative fractions.",
      "Convert between drawing distance and actual distance.",
      "Solve for unknown scales or distances.",
    ],
    intro: "Sunny shrank the whole town onto one sheet of paper — that's the magic of scale! Learn to measure tiny map centimeters and unwrap them into real kilometers, and even design your own blueprints.",
    introSpeak: "Scales shrink the whole town onto one sheet of paper! Measure tiny map centimeters and unwrap them into real kilometers.",
    keyTerms: [
      { term: "Scale", def: "A comparison like 1 cm : 5 km linking drawing to reality." },
      { term: "Representative fraction", def: "Scale with matching units, e.g., 1:500,000." },
      { term: "Drawing distance", def: "What you measure on the paper with a ruler." },
      { term: "Actual distance", def: "The real-world distance the drawing represents." },
    ],
    formulas: [
      { text: "actual = drawing × scale factor", speak: "Actual distance equals drawing distance times the scale factor." },
      { text: "drawing = actual ÷ scale factor", speak: "Drawing distance equals actual distance divided by the scale factor." },
      { text: "scale = drawing : actual (same units!)", speak: "Scale equals drawing to actual, using the same units." },
    ],
    workedExamples: [
      {
        title: "Map distance", given: "Scale: 1 cm = 5 km. Map distance: 4 cm.", asked: "Actual distance?",
        formula: "actual = drawing × scale", formulaSpeak: "Actual equals drawing times scale.",
        steps: ["Each centimeter hides 5 km.", "4 cm × 5 km/cm = 20 km.", "Units cancel: cm ÷ cm leaves km. ✓"],
        answer: "20 km", why: "The scale factor converts each paper-unit into real-units.",
        diagram: "map", diagramData: { dist: "4 cm", scale: "1 cm = 5 km", actual: "20 km" }, audio: "Four centimeters times five kilometers per centimeter equals twenty kilometers.",
      },
      {
        title: "Blueprint wall", given: "Plan scale 1:100. Wall on paper: 6 cm.", asked: "Real wall length?",
        formula: "actual = 6 cm × 100", formulaSpeak: "Actual equals six centimeters times one hundred.",
        steps: ["1:100 means 1 cm stands for 100 cm.", "6 × 100 = 600 cm.", "600 cm = 6 m."],
        answer: "6 m", why: "Representative fractions use the same unit both sides, then convert.",
        diagram: "map", diagramData: { title: "Blueprint", a: "Wall start", b: "Wall end", dist: "6 cm", scale: "1:100", actual: "6 m" }, audio: "One to one hundred means each centimeter stands for one hundred centimeters. Six times one hundred is six hundred centimeters, or six meters.",
      },
      {
        title: "Finding the scale", given: "Real park: 3 km. Drawing: 6 cm.", asked: "What is the scale?",
        formula: "scale = actual ÷ drawing", formulaSpeak: "Scale equals actual divided by drawing.",
        steps: ["3 km = 300,000 cm.", "300,000 ÷ 6 = 50,000.", "Scale = 1:50,000, or 1 cm = 0.5 km."],
        answer: "1:50,000", why: "Dividing real by drawn tells how much each paper-unit represents.",
        diagram: "map", diagramData: { title: "Park Plan", dist: "6 cm", scale: "1:50,000", actual: "3 km" }, audio: "Three kilometers is three hundred thousand centimeters. Divide by six: fifty thousand. The scale is one to fifty thousand.",
      },
    ],
    applications: ["Architects draw houses at 1:50 before building.", "Hikers convert trail-map centimeters into kilometers of walking.", "Model builders scale real cars down to 1:64 toy size."],
    mistakes: [
      { mistake: "Multiplying without matching units (cm scale with mm measurement).", fix: "Convert the measurement to the scale's unit FIRST." },
      { mistake: "Reading 1:100 as '1 cm = 100 m'.", fix: "Same units both sides: 1:100 means 1 cm = 100 cm = 1 m." },
    ],
    check: [
      { question: "Scale 1 cm = 5 km, map shows 4 cm. Actual?", options: ["9 km", "20 km", "4 km", "1.25 km"], answer: 1, explanation: "4 × 5 = 20 km." },
      { question: "Scale 1:100, drawing 6 cm. Real length?", options: ["6 m", "600 m", "60 cm", "0.6 m"], answer: 0, explanation: "6 × 100 = 600 cm = 6 m." },
      { question: "Real 3 km drawn as 6 cm. Scale?", options: ["1:50", "1:500", "1:50,000", "1:500,000"], answer: 2, explanation: "300,000 cm ÷ 6 cm = 50,000." },
    ],
    tool: "map-lab", toolTitle: "Map Explorer Lab", toolDesc: "Change the scale and distances to plan Sunnyville trips!",
  },
  {
    id: "6", competencyId: 6, title: "Currency Conversions",
    objectives: [
      "Convert pesos ↔ foreign currency with sample exchange rates.",
      "Compare prices across currencies fairly.",
      "Explain why rates change and why samples are labeled.",
    ],
    intro: "Pack your bags, traveler! Sunny is swapping pesos for dollars, yen, and euros. Money Math teaches you to multiply one way, divide on the way back — and always label sample rates honestly, because real rates wiggle every day!",
    introSpeak: "Pack your bags! We are swapping pesos for dollars, yen, and euros. Multiply one way, divide on the way back, and always label sample rates.",
    keyTerms: [
      { term: "Exchange rate", def: "How much one currency buys in another (e.g., 1 USD = ₱58.50 sample)." },
      { term: "Sample rate", def: "A classroom rate for practice — NOT today's real bank rate." },
      { term: "Convert", def: "Multiply foreign→pesos; divide pesos→foreign." },
    ],
    formulas: [
      { text: "pesos = foreign × rate", speak: "Pesos equals foreign money times the rate." },
      { text: "foreign = pesos ÷ rate", speak: "Foreign money equals pesos divided by the rate." },
      { text: "Sample rates: USD 58.50 · JPY 0.39 · EUR 63.20 · GBP 74.10", speak: "Sample rates: one dollar is fifty eight point five pesos. One yen is zero point three nine pesos. One euro is sixty three point two pesos." },
    ],
    workedExamples: [
      {
        title: "Dollars → pesos", given: "Sample rate: 1 USD = ₱58.50. Tourist changes $40.", asked: "Pesos received?",
        formula: "pesos = 40 × 58.50", formulaSpeak: "Pesos equals forty times fifty eight point five.",
        steps: ["40 × 58.50 = 2,340.", "Round to centavos: ₱2,340.00.", "Check: pesos number is bigger than dollars. ✓"],
        answer: "₱2,340.00", why: "One dollar buys many pesos, so multiply.",
        diagram: "coins", diagramData: { usd: "40 USD", php: "₱2,340" }, audio: "Forty times fifty eight point five equals two thousand three hundred forty pesos.",
      },
      {
        title: "Pesos → dollars", given: "Same sample rate. Souvenir costs ₱2,925.", asked: "Price in USD?",
        formula: "USD = 2,925 ÷ 58.50", formulaSpeak: "Dollars equals two thousand nine hundred twenty five divided by fifty eight point five.",
        steps: ["2,925 ÷ 58.50 = 50.", "Answer: $50.00.", "Check: dividing shrinks pesos back to dollars. ✓"],
        answer: "$50.00", why: "Going back divides by the same rate — inverse operations!",
        diagram: "coins", diagramData: { usd: "50 USD", php: "₱2,925" }, audio: "Two thousand nine hundred twenty five divided by fifty eight point five equals fifty dollars.",
      },
      {
        title: "Which souvenir is cheaper?", given: "Bag A: ₱1,170. Bag B: $22 (sample 58.50).", asked: "Which costs less?",
        formula: "Convert B: 22 × 58.50", formulaSpeak: "Convert B: twenty two times fifty eight point five.",
        steps: ["B in pesos: 22 × 58.50 = ₱1,287.", "Compare: ₱1,170 < ₱1,287.", "Bag A wins by ₱117!"],
        answer: "Bag A (₱1,170)", why: "Never compare numbers in different currencies — convert first!",
        diagram: "coins", diagramData: { usd: "22 USD", php: "₱1,287" }, audio: "Twenty two dollars is one thousand two hundred eighty seven pesos. Bag A at one thousand one hundred seventy pesos is cheaper.",
      },
    ],
    applications: ["Travelers budget tours priced in dollars using peso equivalents.", "Online shoppers compare US vs local prices fairly.", "Exporters quote calamansi juice per dollar, then compute peso revenue."],
    mistakes: [
      { mistake: "Multiplying when you should divide (pesos → foreign).", fix: "Ask: should my answer be BIGGER (×) or SMALLER (÷)? Pesos are the big numbers!" },
      { mistake: "Presenting sample rates as today's real rate.", fix: "Always say 'sample rate' — real rates change daily at banks." },
    ],
    check: [
      { question: "Sample 1 USD = ₱58.50. $10 = ? pesos", options: ["₱585", "₱5.85", "₱58.50", "₱5,850"], answer: 0, explanation: "10 × 58.50 = 585." },
      { question: "₱2,925 at sample 58.50 = ? USD", options: ["$500", "$50", "$5", "$5,000"], answer: 1, explanation: "2,925 ÷ 58.50 = 50." },
      { question: "₱1,170 vs $20 (58.50): which is cheaper?", options: ["₱1,170", "$20", "Exactly equal", "Cannot compare"], answer: 2, explanation: "20 × 58.50 = 1,170 — a perfect tie!" },
    ],
    tool: "currency-lab", toolTitle: "Money Math Calculator", toolDesc: "Swap currencies with sample rates and compare shop prices!",
  },
  {
    id: "7", competencyId: 7, title: "Time Conversions & Applications",
    objectives: [
      "Convert seconds, minutes, hours, days, weeks.",
      "Compute elapsed time, even across midnight.",
      "Read schedules and plan trips and projects.",
    ],
    intro: "Tick-tock, Time Traveler! Berry lost her bus schedule and needs YOUR help. Master the 60s (seconds, minutes) and the 24s (hours, days), and you'll plan projects, trips, and snacks like a pro.",
    introSpeak: "Tick tock, Time Traveler! Master the sixties and twenty fours, and you will plan projects and trips like a pro.",
    keyTerms: [
      { term: "Elapsed time", def: "End time minus start time." },
      { term: "a.m./p.m.", def: "a.m. = midnight→noon; p.m. = noon→midnight." },
      { term: "Timetable", def: "Grid of departures and arrivals to read like a map." },
    ],
    formulas: [
      { text: "1 h = 60 min · 1 min = 60 s · 1 day = 24 h · 1 week = 7 days", speak: "One hour equals sixty minutes. One minute equals sixty seconds. One day equals twenty four hours. One week equals seven days." },
      { text: "elapsed = end − start", speak: "Elapsed time equals end minus start." },
      { text: "total minutes = hours × 60 + minutes", speak: "Total minutes equals hours times sixty plus minutes." },
    ],
    workedExamples: [
      {
        title: "Project duration", given: "Project lasts 3 h 45 min.", asked: "Total minutes?",
        formula: "3 × 60 + 45", formulaSpeak: "Three times sixty plus forty five.",
        steps: ["3 × 60 = 180 min.", "180 + 45 = 225 min.", "Check: between 180 (3h) and 240 (4h). ✓"],
        answer: "225 minutes", why: "Hours convert at ×60 because time is base-60, not base-10!",
        diagram: "clock", diagramData: { start: "0:00", end: "3:45", elapsed: "225 min", label: "Project time" }, audio: "Three times sixty is one hundred eighty. Plus forty five is two hundred twenty five minutes.",
      },
      {
        title: "Across midnight", given: "Movie: 10:45 PM → 1:15 AM.", asked: "How long?",
        formula: "split at midnight: →12:00 + 12:00→", formulaSpeak: "Split at midnight: time to twelve, plus time after twelve.",
        steps: ["10:45 PM → 12:00 = 1 h 15 min = 75 min.", "12:00 → 1:15 AM = 75 min.", "Total: 150 min = 2 h 30 min."],
        answer: "2 h 30 min", why: "Midnight resets the clock, so split the journey in two.",
        diagram: "clock", diagramData: { start: "Start 10:45 PM", end: "End 1:15 AM", elapsed: "2 h 30 min", label: "Movie night" }, audio: "Ten forty five PM to midnight is one hour fifteen minutes. Midnight to one fifteen AM is another hour fifteen. Total two hours thirty minutes.",
      },
      {
        title: "Catching the bus", given: "Bus leaves 7:20 AM; ride takes 55 min.", asked: "Arrival time?",
        formula: "arrival = departure + duration", formulaSpeak: "Arrival equals departure plus duration.",
        steps: ["7:20 + 55 min: 7:20 → 8:00 is 40 min.", "15 min left: 8:00 + 15 = 8:15 AM.", "Arrive 8:15 AM sharp!"],
        answer: "8:15 AM", why: "Hop to the next hour first — it keeps mental math clean.",
        diagram: "clock", diagramData: { start: "Leaves 7:20", end: "Rides 55 min", elapsed: "Arrives 8:15", label: "Bus schedule" }, audio: "Seven twenty plus fifty five minutes is eight fifteen AM.",
      },
    ],
    applications: ["Project managers convert 40-hour tasks into work-weeks.", "Nurses compute medicine intervals across night shifts.", "Store owners tally weekly hours into payroll days."],
    mistakes: [
      { mistake: "Writing 1.5 hours as 1 h 50 min.", fix: "0.5 h = 30 min! Decimals of an hour are ×60, not ×100." },
      { mistake: "Forgetting a.m./p.m. when crossing noon.", fix: "Say the period out loud: '7:20 AM plus 55 minutes stays AM'." },
    ],
    check: [
      { question: "3 h 45 min = ? minutes", options: ["345", "225", "195", "3450"], answer: 1, explanation: "3×60+45 = 225." },
      { question: "10:45 PM → 1:15 AM = ?", options: ["2 h 30 min", "3 h 30 min", "1 h 30 min", "14 h 30 min"], answer: 0, explanation: "75 + 75 = 150 min = 2 h 30 min." },
      { question: "Leave 7:20 AM, ride 55 min. Arrive?", options: ["8:15 AM", "7:75 AM", "8:05 AM", "8:15 PM"], answer: 0, explanation: "7:20 + 40 = 8:00, +15 = 8:15 AM." },
    ],
    tool: "time-lab", toolTitle: "Time Machine", toolDesc: "Spin start and end times and crack elapsed-time puzzles!",
  },
  {
    id: "8", competencyId: 8, title: "Temperature Conversions",
    objectives: [
      "Convert Celsius ↔ Fahrenheit ↔ Kelvin.",
      "Interpret weather, recipes, and lab temperatures.",
      "Write Kelvin correctly (no degree symbol!).",
    ],
    intro: "Brrr or sizzle? Berry's thermometer speaks three languages: Celsius, Fahrenheit, and Kelvin. Learn the two magic formulas, meet absolute zero, and never burn the cookies (or the science lab) again!",
    introSpeak: "Thermometers speak three languages: Celsius, Fahrenheit, and Kelvin. Learn the two magic formulas and meet absolute zero!",
    keyTerms: [
      { term: "Celsius (°C)", def: "Metric scale: water freezes 0°C, boils 100°C." },
      { term: "Fahrenheit (°F)", def: "Customary scale: water freezes 32°F, boils 212°F." },
      { term: "Kelvin (K)", def: "Science scale from absolute zero: 0 K = −273.15°C. No ° symbol!" },
    ],
    formulas: [
      { text: "°F = (°C × 9/5) + 32", speak: "Degrees Fahrenheit equals degrees Celsius times nine fifths, plus thirty two." },
      { text: "°C = (°F − 32) × 5/9", speak: "Degrees Celsius equals Fahrenheit minus thirty two, times five ninths." },
      { text: "K = °C + 273.15 · °C = K − 273.15", speak: "Kelvin equals Celsius plus two hundred seventy three point one five." },
    ],
    workedExamples: [
      {
        title: "Warm afternoon", given: "Forecast: 25°C.", asked: "Temperature in °F?",
        formula: "°F = (25 × 9/5) + 32", formulaSpeak: "Fahrenheit equals twenty five times nine fifths, plus thirty two.",
        steps: ["25 × 9/5 = 25 × 1.8 = 45.", "45 + 32 = 77.", "Answer: 77°F — pleasant!"],
        answer: "77°F", why: "Celsius degrees are bigger, so the Fahrenheit number climbs higher.",
        diagram: "thermometer", diagramData: { c: 25 }, audio: "Twenty five times nine fifths is forty five. Plus thirty two is seventy seven degrees Fahrenheit.",
      },
      {
        title: "Fever check", given: "Thermometer reads 101.3°F.", asked: "Temperature in °C?",
        formula: "°C = (101.3 − 32) × 5/9", formulaSpeak: "Celsius equals one hundred one point three minus thirty two, times five ninths.",
        steps: ["101.3 − 32 = 69.3.", "69.3 × 5/9 = 69.3 × 0.555… ≈ 38.5.", "38.5°C — a fever (normal ≈ 37°C)."],
        answer: "38.5°C", why: "Subtract the 32° offset first, THEN scale by 5/9.",
        diagram: "thermometer", diagramData: { c: 38.5 }, audio: "One hundred one point three minus thirty two is sixty nine point three. Times five ninths is about thirty eight point five degrees Celsius. That is a fever.",
      },
      {
        title: "Science lab", given: "Experiment runs at 20°C.", asked: "Temperature in kelvin?",
        formula: "K = 20 + 273.15", formulaSpeak: "Kelvin equals twenty plus two hundred seventy three point one five.",
        steps: ["20 + 273.15 = 293.15.", "Write: 293.15 K (no degree symbol!)."],
        answer: "293.15 K", why: "Kelvin shifts the zero to absolute zero but keeps Celsius-sized degrees.",
        diagram: "thermometer", diagramData: { c: 20 }, audio: "Twenty plus two hundred seventy three point one five equals two hundred ninety three point one five kelvin.",
      },
    ],
    applications: ["Chefs convert 180°C oven settings to 350°F recipes.", "Nurses read 37°C as the healthy human baseline.", "Engineers store vaccines at 2–8°C (35.6–46.4°F)."],
    mistakes: [
      { mistake: "Adding 32 before multiplying (or multiplying before subtracting).", fix: "C→F: scale THEN shift. F→C: shift (minus 32) THEN scale." },
      { mistake: "Writing '293°K' with a degree symbol.", fix: "Kelvin stands alone: 293.15 K. The degree left the party!" },
    ],
    check: [
      { question: "25°C = ? °F", options: ["57°F", "77°F", "13°F", "25°F"], answer: 1, explanation: "(25 × 1.8) + 32 = 77." },
      { question: "20°C = ? K", options: ["293.15 K", "253.15 K", "68 K", "20 K"], answer: 0, explanation: "20 + 273.15 = 293.15 K." },
      { question: "Correct Kelvin writing?", options: ["293°K", "293.15 K", "293° K", "K 293.15°"], answer: 1, explanation: "Kelvin never takes a degree symbol." },
    ],
    tool: "temp-lab", toolTitle: "Thermometer Lab", toolDesc: "Slide the temperature and speak all three scales at once!",
  },
  {
    id: "9", competencyId: 9, title: "Plane Geometry & Triangles",
    objectives: [
      "Name plane figures and their parts (points, lines, angles).",
      "Compute perimeter/circumference and area of plane figures.",
      "Find triangle area via ½bh AND Heron's formula.",
    ],
    intro: "Flatland is full of shapes waiting to be measured! Skye hands you two superpowers: PERIMETER (the fence around a shape) and AREA (the carpet inside it). Then you'll unlock the legendary Heron's formula for triangles with three known sides!",
    introSpeak: "Flatland is full of shapes! Perimeter is the fence around a shape. Area is the carpet inside it. Then you will unlock Heron's formula for triangles.",
    keyTerms: [
      { term: "Perimeter", def: "Distance around a boundary (linear units: cm, m)." },
      { term: "Area", def: "Surface covered (square units: cm², m²)." },
      { term: "Semiperimeter (s)", def: "Half the perimeter: s = (a+b+c)/2." },
      { term: "Triangle inequality", def: "Any two sides must sum past the third, or no triangle exists!" },
    ],
    formulas: [
      { text: "P△ = a+b+c · P▭ = 2(l+w) · C = 2πr", speak: "Triangle perimeter equals a plus b plus c. Rectangle: two times length plus width. Circumference: two pi r." },
      { text: "▭ A = lw · △ A = ½bh · ○ A = πr² · ⏢ A = ½(a+b)h", speak: "Rectangle: length times width. Triangle: one half base times height. Circle: pi r squared. Trapezoid: one half the bases sum times height." },
      { text: "s = (a+b+c)/2 · A = √[s(s−a)(s−b)(s−c)]", speak: "s equals a plus b plus c over two. Area equals the square root of s times s minus a, times s minus b, times s minus c." },
    ],
    workedExamples: [
      {
        title: "Fencing the garden", given: "Garden: 5 m × 8 m rectangle.", asked: "Meters of fencing? (perimeter)",
        formula: "P = 2(l + w)", formulaSpeak: "Perimeter equals two times length plus width.",
        steps: ["l + w = 8 + 5 = 13.", "Double: 2 × 13 = 26.", "Answer: 26 m of fencing."],
        answer: "26 m", why: "Opposite sides match, so add one pair and double.",
        diagram: "rectangle", diagramData: { l: 8, w: 5 }, audio: "Eight plus five is thirteen. Double it: twenty six meters of fencing.",
      },
      {
        title: "Triangle sail", given: "Sail: base 10 m, perpendicular height 6 m.", asked: "Area of fabric?",
        formula: "A = ½bh", formulaSpeak: "Area equals one half base times height.",
        steps: ["Check: height is perpendicular to base. ✓", "A = ½ × 10 × 6 = 30.", "Answer: 30 m²."],
        answer: "30 m²", why: "Every triangle is half a parallelogram — that's where the ½ comes from!",
        diagram: "triangle", diagramData: { b: 10, h: 6 }, audio: "One half times ten times six equals thirty square meters of sail fabric.",
      },
      {
        title: "Heron to the rescue", given: "Triangle sides: 13, 14, 15 (no height given!).", asked: "Area?",
        formula: "s = (a+b+c)/2; A = √[s(s−a)(s−b)(s−c)]", formulaSpeak: "First the semiperimeter, then the square root of s times s minus a, times s minus b, times s minus c.",
        steps: ["Triangle check: 13+14 > 15 ✓ (and both other pairs).", "s = (13+14+15)/2 = 42/2 = 21.", "A = √[21(8)(7)(6)] = √7056 = 84.", "Answer: 84 square units."],
        answer: "84 square units", why: "Heron trades the missing height for the three side lengths.",
        diagram: "heron", diagramData: { a: 13, b: 14, c: 15 }, audio: "Semiperimeter is twenty one. Area is the square root of twenty one times eight times seven times six, which is eighty four.",
      },
    ],
    applications: ["Farmers fence fields by perimeter, then seed by area.", "Sailmakers cut triangular sails using base-height area.", "Surveyors map odd triangular lots with Heron's formula."],
    mistakes: [
      { mistake: "Using a slanted side as the 'height' in ½bh.", fix: "Height must be perpendicular (⊥) to the base — look for the square corner mark!" },
      { mistake: "Skipping the triangle-inequality check for Heron.", fix: "Test all 3 pairs: if any sum ≤ third side, compute NOTHING — it's not a triangle." },
    ],
    check: [
      { question: "Rectangle 5 × 8: perimeter?", options: ["13 m", "26 m", "40 m", "40 m²"], answer: 1, explanation: "2(5+8) = 26 m." },
      { question: "Triangle b = 10, h = 6: area?", options: ["60", "30", "16", "32"], answer: 1, explanation: "½ × 10 × 6 = 30 (square units)." },
      { question: "Sides 13, 14, 15: semiperimeter?", options: ["42", "21", "84", "14"], answer: 1, explanation: "(13+14+15)/2 = 21." },
    ],
    tool: "triangle-lab", toolTitle: "Triangle Workshop", toolDesc: "Stretch sides, heights, and watch perimeter + Heron area live!",
  },
  {
    id: "10", competencyId: 10, title: "Trigonometry & Solving Triangles",
    objectives: [
      "Use Pythagoras for right triangles.",
      "Apply SOH-CAH-TOA to find sides and angles.",
      "Choose Law of Sines vs Law of Cosines for non-right triangles.",
    ],
    intro: "Final quest, Superstar! Rainbee reveals how angles whisper secrets about sides. You'll master the 3-4-5 magic (Pythagoras), the SOH-CAH-TOA spell, and the twin laws that tame ANY triangle — right or not!",
    introSpeak: "Final quest! You will master Pythagoras, the Soh Cah Toa spell, and the twin laws that tame any triangle.",
    keyTerms: [
      { term: "Hypotenuse", def: "Longest side, opposite the right angle." },
      { term: "SOH-CAH-TOA", def: "Sin = O/H, Cos = A/H, Tan = O/A." },
      { term: "Law of Sines", def: "a/sin A = b/sin B = c/sin C — needs an opposite pair." },
      { term: "Law of Cosines", def: "a² = b²+c²−2bc·cos A — for SAS and SSS cases." },
    ],
    formulas: [
      { text: "a² + b² = c²", speak: "a squared plus b squared equals c squared." },
      { text: "sin θ = O/H · cos θ = A/H · tan θ = O/A", speak: "Sine of theta equals opposite over hypotenuse. Cosine equals adjacent over hypotenuse. Tangent equals opposite over adjacent." },
      { text: "a/sin A = b/sin B = c/sin C · a² = b² + c² − 2bc·cos A", speak: "a over sine A equals b over sine B equals c over sine C. a squared equals b squared plus c squared minus two b c cosine A." },
    ],
    workedExamples: [
      {
        title: "Ladder rescue (Pythagoras)", given: "Right triangle legs: 6 m and 8 m.", asked: "Hypotenuse (ladder length)?",
        formula: "c = √(a² + b²)", formulaSpeak: "c equals the square root of a squared plus b squared.",
        steps: ["a² + b² = 36 + 64 = 100.", "c = √100 = 10.", "Answer: 10 m ladder."],
        answer: "10 m", why: "The hypotenuse's square always equals the sum of the legs' squares.",
        diagram: "pythag-squares", audio: "Thirty six plus sixty four is one hundred. The square root is ten meters.",
      },
      {
        title: "Kite height (tangent)", given: "Angle 40°, adjacent ground distance 30 m.", asked: "Kite height (opposite)?",
        formula: "tan θ = O/A → O = A·tan θ", formulaSpeak: "Tangent of theta equals opposite over adjacent. So opposite equals adjacent times tangent.",
        steps: ["O = 30 × tan 40°.", "tan 40° ≈ 0.8391.", "O ≈ 25.17 m."],
        answer: "≈ 25.17 m", why: "Tangent links the two legs — perfect when the hypotenuse hides.",
        diagram: "trig-ratio", diagramData: { angle: "40°" }, audio: "Thirty times tangent of forty degrees is about twenty five point one seven meters high.",
      },
      {
        title: "Island survey (Law of Cosines, SAS)", given: "b = 7, c = 10, included A = 60°.", asked: "Side a?",
        formula: "a² = b² + c² − 2bc·cos A", formulaSpeak: "a squared equals b squared plus c squared minus two b c cosine A.",
        steps: ["b² + c² = 49 + 100 = 149.", "2bc·cos60° = 140 × 0.5 = 70.", "a² = 149 − 70 = 79 → a ≈ 8.89."],
        answer: "≈ 8.89", why: "SAS has no opposite pair, so the Law of Sines can't start — Cosines can!",
        diagram: "law-cosines", audio: "Forty nine plus one hundred is one hundred forty nine. Minus seventy is seventy nine. The square root is about eight point eight nine.",
      },
      {
        title: "Rescue boat (Law of Sines)", given: "A = 40°, B = 60°, side a = 10.", asked: "Side b?",
        formula: "b = a·sin B / sin A", formulaSpeak: "b equals a times sine B, divided by sine A.",
        steps: ["Opposite pair (a, A) is known — Sines qualifies! ✓", "b = 10 × sin60° / sin40°.", "b = 10 × 0.8660 / 0.6428 ≈ 13.47."],
        answer: "≈ 13.47", why: "One full opposite pair unlocks every other side and angle.",
        diagram: "law-sines", audio: "Ten times sine sixty, divided by sine forty, is about thirteen point four seven.",
      },
    ],
    applications: ["Builders square foundations with 3-4-5 triangles.", "Pilots compute crosswind drift with sine and cosine.", "Surveyors map islands with the Law of Cosines (SAS plots)."],
    mistakes: [
      { mistake: "Using Pythagoras on non-right triangles.", fix: "No square corner? No Pythagoras! Pick Sines or Cosines instead." },
      { mistake: "Forgetting degree mode on the calculator.", fix: "Check 'DEG' at the top — radian mode gives nonsense for class problems." },
      { mistake: "Law of Sines with SAS/SSS given.", fix: "No opposite pair known? Start with the Law of Cosines." },
    ],
    check: [
      { question: "Legs 6 and 8: hypotenuse?", options: ["10", "14", "100", "48"], answer: 0, explanation: "√(36+64) = √100 = 10." },
      { question: "Opposite 3, hypotenuse 5: sin θ = ?", options: ["3/5", "4/5", "3/4", "5/3"], answer: 0, explanation: "SOH: sin = O/H = 3/5." },
      { question: "Given SAS (two sides + included angle): use?", options: ["Pythagoras", "Law of Sines first", "Law of Cosines", "Heron's formula"], answer: 2, explanation: "No opposite pair exists yet, so the Law of Cosines finds the third side." },
    ],
    tool: "trig-lab", toolTitle: "Trig Triangle Lab", toolDesc: "Slide angles and sides — watch sine, cosine, tangent dance!",
  },
];

export function lessonById(id: string): Lesson | undefined {
  return LESSONS.find((l) => l.id === id);
}
