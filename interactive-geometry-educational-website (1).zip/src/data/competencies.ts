export interface Competency {
  id: number; // 1..10
  slug: string;
  title: string;
  short: string;
  color: string; // bg
  accent: string;
  emoji: string;
  objective: string;
  mascot: "sunny" | "berry" | "minty" | "skye" | "plummy" | "rainbow";
}

export const COMPETENCIES: Competency[] = [
  { id: 1, slug: "metric-units", title: "Metric Units & Measurements", short: "Metric Units", color: "#B8E6D0", accent: "#0d9488", emoji: "📏", objective: "Determine and apply appropriate metric units for length, mass, and capacity in everyday and scientific contexts.", mascot: "minty" },
  { id: 2, slug: "conversions", title: "Conversion of Measurements", short: "Conversions", color: "#B9E3FA", accent: "#2563eb", emoji: "🔄", objective: "Convert measurements within the metric system and between metric and customary systems using conversion factors.", mascot: "skye" },
  { id: 3, slug: "surface-area", title: "Surface Area of 3D Objects", short: "Surface Area", color: "#FFC5DD", accent: "#db2777", emoji: "📦", objective: "Determine the surface area of prisms, pyramids, cylinders, cones, spheres, and composite solids.", mascot: "plummy" },
  { id: 4, slug: "volume", title: "Volume of 3D Objects", short: "Volume", color: "#CDB8F5", accent: "#7c3aed", emoji: "🧊", objective: "Calculate the volume of prisms, pyramids, cylinders, cones, spheres, and composite solids.", mascot: "plummy" },
  { id: 5, slug: "scale-maps", title: "Scale, Maps & Blueprints", short: "Scale & Maps", color: "#FFE89A", accent: "#b45309", emoji: "🗺️", objective: "Use scales to interpret and compare distances on maps, blueprints, and sketches.", mascot: "sunny" },
  { id: 6, slug: "currency", title: "Currency Conversions", short: "Currency", color: "#B8E6D0", accent: "#15803d", emoji: "💱", objective: "Solve problems involving conversion of Philippine pesos and foreign currencies using exchange rates.", mascot: "sunny" },
  { id: 7, slug: "time", title: "Time Conversions & Applications", short: "Time", color: "#B9E3FA", accent: "#0e7490", emoji: "⏰", objective: "Apply time conversions to travel, planning, schedules, routines, and transactions.", mascot: "berry" },
  { id: 8, slug: "temperature", title: "Temperature Conversions", short: "Temperature", color: "#FFC5DD", accent: "#be123c", emoji: "🌡️", objective: "Apply temperature conversions among Celsius, Fahrenheit, and Kelvin in real-world scenarios.", mascot: "berry" },
  { id: 9, slug: "plane-geometry", title: "Plane Geometry & Triangles", short: "Plane Geometry", color: "#CDB8F5", accent: "#6d28d9", emoji: "🔺", objective: "Understand plane figures; calculate perimeter and area, including triangle area with base-height and Heron's formula.", mascot: "skye" },
  { id: 10, slug: "trigonometry", title: "Trigonometry & Solving Triangles", short: "Trigonometry", color: "#FFE89A", accent: "#9a3412", emoji: "📐", objective: "Use the Pythagorean theorem, trigonometric ratios, Law of Sines, and Law of Cosines to solve triangles.", mascot: "rainbow" },
];

export function competencyById(id: number): Competency {
  return COMPETENCIES[Math.max(0, Math.min(9, id - 1))];
}
