import type { DiagramKind } from "./definitions";
import { QUESTIONS, type Question, type Difficulty } from "./questions";
import { pickN } from "@/lib/math";

export interface GameMeta {
  id: string;
  title: string;
  tagline: string;
  emoji: string;
  color: string;
  competencyIds: number[];
  primaryCompetency: number; // 0-indexed for stars
  instructions: string;
  kind: "quiz" | "match" | "race";
}

export const GAMES: GameMeta[] = [
  { id: "measurement-match", title: "Measurement Match-Up", tagline: "Match quantities with their twins!", emoji: "🧩", color: "#B8E6D0", competencyIds: [1, 2], primaryCompetency: 0, instructions: "Tap a card on the left, then its matching partner on the right. Match every pair to win!", kind: "match" },
  { id: "formula-quest", title: "Formula Quest", tagline: "Pick the magic formula!", emoji: "🪄", color: "#CDB8F5", competencyIds: [3, 4, 9], primaryCompetency: 2, instructions: "Look at each figure and choose the correct formula. Heroes never guess blindly — read the shape!", kind: "quiz" },
  { id: "shape-detective", title: "Shape Detective", tagline: "Solve shape mysteries!", emoji: "🔍", color: "#B9E3FA", competencyIds: [3, 4, 9], primaryCompetency: 8, instructions: "Study each diagram clue and answer the detective's questions about shapes and their measurements.", kind: "quiz" },
  { id: "conversion-race", title: "Conversion Race", tagline: "Beat the clock!", emoji: "🏎️", color: "#FFE89A", competencyIds: [2], primaryCompetency: 1, instructions: "Answer as many conversions as you can before the timer runs out. Fast AND correct wins!", kind: "race" },
  { id: "map-explorer", title: "Map Explorer", tagline: "Chart Sunnyville!", emoji: "🗺️", color: "#B8E6D0", competencyIds: [5], primaryCompetency: 4, instructions: "Read each map scale, measure the drawing distance, and compute the real distance.", kind: "quiz" },
  { id: "money-math", title: "Money Math", tagline: "Shop the world!", emoji: "💱", color: "#FFE89A", competencyIds: [6], primaryCompetency: 5, instructions: "Convert currencies with the sample rates shown. Multiply one way, divide on the way back!", kind: "quiz" },
  { id: "time-traveler", title: "Time Traveler", tagline: "Race through time!", emoji: "⏰", color: "#B9E3FA", competencyIds: [7], primaryCompetency: 6, instructions: "Solve elapsed-time and time-conversion puzzles across clocks, trips, and midnight!", kind: "quiz" },
  { id: "temperature-challenge", title: "Temperature Challenge", tagline: "Hot or cold?", emoji: "🌡️", color: "#FFC5DD", competencyIds: [8], primaryCompetency: 7, instructions: "Convert Celsius, Fahrenheit, and Kelvin. Remember: shift THEN scale for F to C!", kind: "quiz" },
  { id: "triangle-treasure", title: "Triangle Treasure", tagline: "Hunt triangle gold!", emoji: "🔺", color: "#CDB8F5", competencyIds: [9], primaryCompetency: 8, instructions: "Identify triangles, find perimeters and areas, and unlock chests with Heron's formula!", kind: "quiz" },
  { id: "trigonometry-quest", title: "Trigonometry Quest", tagline: "Tame every triangle!", emoji: "📐", color: "#FFC5DD", competencyIds: [10], primaryCompetency: 9, instructions: "Use Pythagoras, SOH-CAH-TOA, and the Laws of Sines and Cosines to solve each quest!", kind: "quiz" },
];

export function gameById(id: string): GameMeta | undefined {
  return GAMES.find((g) => g.id === id);
}

/* ---------- Formula Quest custom questions ---------- */
interface FormulaQ {
  figure: string;
  diagram: DiagramKind;
  diagramData?: Record<string, number | string>;
  correct: string;
  distractors: string[];
  explain: string;
  speak: string;
}

const FORMULA_QS: FormulaQ[] = [
  { figure: "Rectangular prism (box)", diagram: "prism-net", correct: "SA = 2(lw + lh + wh)", distractors: ["SA = 6s²", "SA = lwh", "SA = 2πr² + 2πrh"], explain: "A box has 3 different face pairs: lw, lh, wh — add and double!", speak: "Rectangular prism. Surface area equals two times length width plus length height plus width height." },
  { figure: "Cube", diagram: "prism-net", correct: "SA = 6s²", distractors: ["SA = s³", "SA = 4s²", "SA = 2s²"], explain: "6 identical square faces → 6 × s².", speak: "Cube. Surface area equals six times side squared." },
  { figure: "Cylinder", diagram: "cylinder", diagramData: { r: 3, h: 6 }, correct: "SA = 2πr² + 2πrh", distractors: ["SA = πr² + πrℓ", "SA = 4πr²", "SA = 2πrh only"], explain: "Two circle bases (2πr²) plus the unrolled wall (2πrh).", speak: "Cylinder. Surface area equals two pi r squared plus two pi r h." },
  { figure: "Sphere", diagram: "sphere", diagramData: { r: 5 }, correct: "SA = 4πr²", distractors: ["SA = 2πr²", "SA = ⁴⁄₃πr³", "SA = πr²"], explain: "A sphere equals 4 great circles: 4πr².", speak: "Sphere. Surface area equals four pi r squared." },
  { figure: "Cone (total SA)", diagram: "cone", correct: "SA = πr² + πrℓ", distractors: ["SA = ⅓πr²h", "SA = 2πr² + 2πrh", "SA = πrℓ only"], explain: "Circle base πr² plus lateral sector πrℓ (slant height!).", speak: "Cone. Surface area equals pi r squared plus pi r l." },
  { figure: "Square pyramid (total SA)", diagram: "pyramid", correct: "SA = s² + 2sℓ", distractors: ["SA = ⅓Bh", "SA = 6s²", "SA = s² + 4sℓ"], explain: "Square base s² plus 4 triangles: 4 × ½sℓ = 2sℓ.", speak: "Square pyramid. Surface area equals s squared plus two s l." },
  { figure: "Any prism (volume)", diagram: "cube-fill", correct: "V = Bh", distractors: ["V = ⅓Bh", "V = 2Bh", "V = B + h"], explain: "Stack the base area B up through height h — no third!", speak: "Any prism. Volume equals base area times height." },
  { figure: "Cone (volume)", diagram: "cone", correct: "V = ⅓πr²h", distractors: ["V = πr²h", "V = πr² + πrℓ", "V = ⁴⁄₃πr³"], explain: "Pointy shapes take one-third: ⅓ of the cylinder.", speak: "Cone volume equals one third pi r squared h." },
  { figure: "Sphere (volume)", diagram: "sphere", diagramData: { r: 3 }, correct: "V = ⁴⁄₃πr³", distractors: ["V = 4πr²", "V = ⅓πr²h", "V = 2πr³"], explain: "Four-thirds pi r cubed — radius is cubed!", speak: "Sphere volume equals four thirds pi r cubed." },
  { figure: "Triangle (area)", diagram: "triangle", diagramData: { b: 10, h: 6 }, correct: "A = ½bh", distractors: ["A = bh", "A = a + b + c", "A = 2bh"], explain: "Half a parallelogram: one-half base times perpendicular height.", speak: "Triangle area equals one half base times height." },
  { figure: "Circle (area)", diagram: "circle", diagramData: { r: 7 }, correct: "A = πr²", distractors: ["A = 2πr", "A = πd", "A = 2πr²"], explain: "Pi r squared covers the disk; 2πr is just the rim!", speak: "Circle area equals pi r squared." },
  { figure: "Circle (circumference)", diagram: "circle", diagramData: { r: 7 }, correct: "C = 2πr", distractors: ["C = πr²", "C = 2r", "C = πr"], explain: "Walk around the rim: 2 pi r (or pi d).", speak: "Circumference equals two pi r." },
  { figure: "Trapezoid (area)", diagram: "trapezoid", diagramData: { a: 6, b: 10, h: 4 }, correct: "A = ½(a+b)h", distractors: ["A = (a+b)h", "A = abh", "A = ½abh"], explain: "Average the two bases, times height: ½(a+b)h.", speak: "Trapezoid area equals one half times a plus b, times height." },
  { figure: "Triangle with 3 sides (area)", diagram: "heron", diagramData: { a: 13, b: 14, c: 15 }, correct: "A = √[s(s−a)(s−b)(s−c)]", distractors: ["A = ½bh", "A = a + b + c", "A = abc"], explain: "No height? Heron's formula uses s = (a+b+c)/2 instead!", speak: "Heron's formula: area equals the square root of s times s minus a, times s minus b, times s minus c." },
  { figure: "Right triangle (missing side)", diagram: "right-triangle", diagramData: { a: 6, b: 8 }, correct: "a² + b² = c²", distractors: ["a + b = c", "a² − b² = c²", "sin θ = O/H"], explain: "Pythagoras: legs squared add to hypotenuse squared.", speak: "a squared plus b squared equals c squared." },
];

export function formulaQuestQuestions(diff: Difficulty, count: number): Question[] {
  const pool = pickN(FORMULA_QS, Math.max(count, 8));
  return pool.slice(0, count).map((f, i) => {
    const options = [f.correct, ...f.distractors].sort(() => Math.random() - 0.5);
    return {
      id: `fq-${diff}-${i}-${Date.now() % 100000}`,
      competencyId: 3,
      topic: "Formula pick",
      difficulty: diff,
      type: "mc" as const,
      prompt: `Which formula belongs to: ${f.figure}?`,
      speak: `Which formula belongs to: ${f.speak}`,
      options,
      correctIndex: options.indexOf(f.correct),
      explanation: f.explain,
      diagram: f.diagram,
      diagramData: f.diagramData,
    };
  });
}

/* ---------- Shape Detective custom questions ---------- */
interface DetectiveQ {
  prompt: string; speak: string;
  options: string[]; correctIndex: number;
  explain: string; diagram: DiagramKind;
  diagramData?: Record<string, number | string>;
  competencyId: number;
}

const DETECTIVE_QS: DetectiveQ[] = [
  { prompt: "The net shows 6 rectangular faces in 3 pairs. What solid is it?", speak: "The net shows 6 rectangular faces in 3 pairs. What solid is it?", options: ["Rectangular prism", "Cylinder", "Cone", "Sphere"], correctIndex: 0, explain: "3 matching face pairs = rectangular prism!", diagram: "prism-net", competencyId: 3 },
  { prompt: "This solid has 2 circular bases and 1 curved wall. What is it?", speak: "Two circular bases and one curved wall. What is it?", options: ["Cone", "Cylinder", "Sphere", "Pyramid"], correctIndex: 1, explain: "Two circles + curved rectangle wall = cylinder.", diagram: "cylinder", diagramData: { r: 3, h: 6 }, competencyId: 3 },
  { prompt: "A solid has 1 circular base and 1 vertex (apex). What is it?", speak: "One circular base and one apex. What is it?", options: ["Cylinder", "Prism", "Cone", "Cube"], correctIndex: 2, explain: "Circle base shrinking to a point = cone.", diagram: "cone", competencyId: 3 },
  { prompt: "Every point on this surface is equally far from the center. What is it?", speak: "Every point equally far from the center. What is it?", options: ["Cylinder", "Sphere", "Pyramid", "Prism"], correctIndex: 1, explain: "Perfectly round in 3D = sphere!", diagram: "sphere", diagramData: { r: 5 }, competencyId: 3 },
  { prompt: "A square base plus 4 triangular faces makes...?", speak: "A square base plus four triangular faces makes?", options: ["Triangular prism", "Square pyramid", "Cone", "Cube"], correctIndex: 1, explain: "Square + 4 triangles meeting at an apex = square pyramid.", diagram: "pyramid", competencyId: 3 },
  { prompt: "How many faces does a rectangular prism have?", speak: "How many faces does a rectangular prism have?", options: ["4", "5", "6", "8"], correctIndex: 2, explain: "Top, bottom, front, back, left, right = 6!", diagram: "prism-net", competencyId: 3 },
  { prompt: "The shaded region uses A = ½bh. Which figure is shaded?", speak: "The shaded region uses area one half b h. Which figure?", options: ["Triangle", "Rectangle", "Circle", "Trapezoid"], correctIndex: 0, explain: "½bh is the triangle signature!", diagram: "triangle", diagramData: { b: 10, h: 6 }, competencyId: 9 },
  { prompt: "A triangle has sides 5, 5, 8. What type is it?", speak: "A triangle has sides 5, 5, 8. What type is it?", options: ["Equilateral", "Isosceles", "Scalene", "Right"], correctIndex: 1, explain: "Two equal sides → isosceles! (5+5 > 8 so it exists.)", diagram: "heron", diagramData: { a: 5, b: 5, c: 8 }, competencyId: 9 },
  { prompt: "A triangle has sides 3, 4, 5. What type is it?", speak: "Sides 3, 4, 5. What type?", options: ["Right triangle", "Obtuse", "Equilateral", "Impossible"], correctIndex: 0, explain: "9 + 16 = 25 → satisfies Pythagoras → right triangle!", diagram: "right-triangle", diagramData: { a: 3, b: 4 }, competencyId: 10 },
  { prompt: "Which measurement needs CUBIC units?", speak: "Which measurement needs cubic units?", options: ["Fence length", "Paint coverage", "Water in a tank", "Ribbon border"], correctIndex: 2, explain: "Water fills 3D space → volume → cubic units!", diagram: "cube-fill", competencyId: 4 },
  { prompt: "Which needs SQUARE units?", speak: "Which needs square units?", options: ["Rope length", "Floor carpet", "Juice volume", "Travel time"], correctIndex: 1, explain: "Carpet covers a surface → area → square units!", diagram: "rectangle", diagramData: { l: 8, w: 5 }, competencyId: 9 },
  { prompt: "Squares built on each side of a right triangle show...", speak: "Squares on each side of a right triangle show?", options: ["a² + b² = c²", "SOH-CAH-TOA", "Heron's formula", "C = 2πr"], correctIndex: 0, explain: "The two small squares exactly fill the big one: Pythagoras!", diagram: "pythag-squares", competencyId: 10 },
];

export function detectiveQuestions(diff: Difficulty, count: number): Question[] {
  return pickN(DETECTIVE_QS, count).map((d, i) => ({
    id: `dt-${diff}-${i}-${Date.now() % 100000}`,
    competencyId: d.competencyId,
    topic: "Shape mystery",
    difficulty: diff,
    type: "mc" as const,
    prompt: d.prompt,
    speak: d.speak,
    options: d.options,
    correctIndex: d.correctIndex,
    explanation: d.explain,
    diagram: d.diagram,
    diagramData: d.diagramData,
  }));
}

/* ---------- Match pairs ---------- */
export const MATCH_PAIRS: [string, string][] = [
  ["1 km", "1,000 m"],
  ["1 m", "100 cm"],
  ["1 cm", "10 mm"],
  ["1 kg", "1,000 g"],
  ["1 g", "1,000 mg"],
  ["1 L", "1,000 mL"],
  ["1 m²", "10,000 cm²"],
  ["1 h", "60 min"],
  ["1 min", "60 s"],
  ["1 day", "24 h"],
  ["1 week", "7 days"],
  ["0°C", "32°F"],
  ["100°C", "212°F"],
  ["20°C", "293.15 K"],
];

export const DIFF_COUNT: Record<Difficulty, number> = { Easy: 5, Intermediate: 7, Challenge: 8 };
export const RACE_TIME: Record<Difficulty, number> = { Easy: 90, Intermediate: 75, Challenge: 60 };
export const MATCH_COUNT: Record<Difficulty, number> = { Easy: 4, Intermediate: 6, Challenge: 8 };

/* ---------- quiz pool by game ---------- */
export function quizQuestionsFor(gameId: string, diff: Difficulty): Question[] {
  const count = DIFF_COUNT[diff];
  const game = gameById(gameId);
  if (!game) return pickN(QUESTIONS, count);
  if (gameId === "formula-quest") return formulaQuestQuestions(diff, count);
  if (gameId === "shape-detective") return detectiveQuestions(diff, count);
  const pool = QUESTIONS.filter((q) => game.competencyIds.includes(q.competencyId));
  // prefer matching difficulty but fill from others
  const exact = pool.filter((q) => q.difficulty === diff);
  const rest = pool.filter((q) => q.difficulty !== diff);
  const picked = [...pickN(exact, count)];
  if (picked.length < count) picked.push(...pickN(rest, count - picked.length));
  if (picked.length < count) picked.push(...pickN(QUESTIONS.filter((q) => !picked.includes(q)), count - picked.length));
  return picked.slice(0, count);
}

export function raceQuestions(diff: Difficulty): Question[] {
  const pool = QUESTIONS.filter((q) => q.competencyId === 2);
  const out: Question[] = [];
  while (out.length < 20) out.push(...pickN(pool, pool.length));
  return out.slice(0, 20);
}
