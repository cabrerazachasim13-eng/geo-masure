"use client";

import { useMemo, useState } from "react";
import { fmt, heronArea, triangleValid, rad } from "@/lib/math";
import Diagram from "./Diagram";
import AudioButton from "./AudioButton";

/* Shared slider row */
function Slider({ label, value, min, max, step, onChange, unit = "", color = "#8b5cf6" }: {
  label: string; value: number; min: number; max: number; step: number;
  onChange: (v: number) => void; unit?: string; color?: string;
}) {
  return (
    <label className="block rounded-2xl bg-white/80 p-3 shadow-sm">
      <span className="flex items-center justify-between text-sm font-extrabold text-[#49385C]">
        {label}
        <span className="rounded-full px-2.5 py-0.5 text-sm font-extrabold text-white" style={{ background: color }}>
          {value}{unit}
        </span>
      </span>
      <input
        type="range" min={min} max={max} step={step} value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="mt-2 w-full accent-[#8b5cf6]" aria-label={label}
      />
    </label>
  );
}

function ToolShell({ children, audio }: { children: React.ReactNode; audio: string }) {
  return (
    <div className="rounded-3xl border-4 border-white bg-gradient-to-br from-[#E9DEFF] to-[#FFF9F2] p-4 shadow-lg sm:p-5">
      <div className="mb-3 flex justify-end"><AudioButton text={audio} label="Explain" size="sm" /></div>
      {children}
    </div>
  );
}

/* 1 — unit compare */
export function UnitCompareTool() {
  const [meters, setMeters] = useState(2.5);
  const best = meters >= 1000 ? "kilometers" : meters >= 1 ? "meters" : meters >= 0.01 ? "centimeters" : "millimeters";
  return (
    <ToolShell audio={`The object is ${meters} meters long. The best unit is ${best}. Kilometers for journeys, meters for rooms, centimeters for hands, millimeters for tiny things.`}>
      <Slider label="Object length (meters)" value={meters} min={0.001} max={5000} step={0.001} onChange={setMeters} unit=" m" color="#0d9488" />
      <div className="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-4">
        {[
          { u: "km", v: meters / 1000 },
          { u: "m", v: meters },
          { u: "cm", v: meters * 100 },
          { u: "mm", v: meters * 1000 },
        ].map((r) => (
          <div key={r.u} className={`rounded-2xl p-3 text-center shadow ${r.u === (best === "kilometers" ? "km" : best === "meters" ? "m" : best === "centimeters" ? "cm" : "mm") ? "bg-[#B8E6D0]" : "bg-white"}`}>
            <p className="font-display text-lg font-extrabold text-[#49385C]">{r.v >= 10000 ? r.v.toExponential(2) : fmt(r.v, 3)} {r.u}</p>
          </div>
        ))}
      </div>
      <p className="mt-3 rounded-2xl bg-white p-3 text-center text-sm font-extrabold text-[#49385C]">🌟 Best unit: <span className="text-[#0d9488]">{best}</span> — numbers stay friendly!</p>
    </ToolShell>
  );
}

/* 2 — converter */
const CONV: { unit: string; toM: number; label: string }[] = [
  { unit: "km", toM: 1000, label: "Kilometers" },
  { unit: "m", toM: 1, label: "Meters" },
  { unit: "cm", toM: 0.01, label: "Centimeters" },
  { unit: "mm", toM: 0.001, label: "Millimeters" },
  { unit: "in", toM: 0.0254, label: "Inches" },
  { unit: "ft", toM: 0.3048, label: "Feet" },
  { unit: "mi", toM: 1609.344, label: "Miles" },
];
export function ConverterTool() {
  const [value, setValue] = useState("2.5");
  const [from, setFrom] = useState("m");
  const [to, setTo] = useState("cm");
  const result = useMemo(() => {
    const v = Number(value);
    if (!Number.isFinite(v)) return null;
    const f = CONV.find((c) => c.unit === from)!;
    const t = CONV.find((c) => c.unit === to)!;
    return (v * f.toM) / t.toM;
  }, [value, from, to]);
  return (
    <ToolShell audio={`Converting ${value} ${from} to ${to}. The answer is ${result === null ? "not a number" : result}. Old units cancel, new units stay!`}>
      <div className="grid gap-3 sm:grid-cols-3">
        <label className="block rounded-2xl bg-white/80 p-3 shadow-sm">
          <span className="text-sm font-extrabold">Value</span>
          <input value={value} onChange={(e) => setValue(e.target.value)} inputMode="decimal" className="mt-1 w-full rounded-xl border-2 border-[#CDB8F5] px-3 py-2 font-display text-xl font-extrabold" aria-label="Value to convert" />
        </label>
        <label className="block rounded-2xl bg-white/80 p-3 shadow-sm">
          <span className="text-sm font-extrabold">From</span>
          <select value={from} onChange={(e) => setFrom(e.target.value)} className="mt-1 w-full rounded-xl border-2 border-[#CDB8F5] px-3 py-2 font-bold" aria-label="From unit">
            {CONV.map((c) => <option key={c.unit} value={c.unit}>{c.label} ({c.unit})</option>)}
          </select>
        </label>
        <label className="block rounded-2xl bg-white/80 p-3 shadow-sm">
          <span className="text-sm font-extrabold">To</span>
          <select value={to} onChange={(e) => setTo(e.target.value)} className="mt-1 w-full rounded-xl border-2 border-[#CDB8F5] px-3 py-2 font-bold" aria-label="To unit">
            {CONV.map((c) => <option key={c.unit} value={c.unit}>{c.label} ({c.unit})</option>)}
          </select>
        </label>
      </div>
      <div className="formula-box mt-3 rounded-2xl px-4 py-3 text-center text-xl font-extrabold">
        {value} {from} = {result === null ? "❓" : `${fmt(result, 4)} ${to}`}
      </div>
      <Diagram kind="scale-factor" data={{ from: `${value} ${from}`, to: result === null ? "?" : `${fmt(result, 4)} ${to}` }} className="mt-3" />
    </ToolShell>
  );
}

/* 3 — prism lab */
export function PrismLabTool() {
  const [l, setL] = useState(4);
  const [w, setW] = useState(3);
  const [h, setH] = useState(2);
  const sa = 2 * (l * w + l * h + w * h);
  return (
    <ToolShell audio={`Box ${l} by ${w} by ${h}. Front and back faces are ${l * w} each. Left and right are ${l * h} each. Top and bottom are ${w * h} each. Total surface area ${sa} square units.`}>
      <div className="grid gap-3 sm:grid-cols-3">
        <Slider label="Length" value={l} min={1} max={10} step={0.5} onChange={setL} color="#db2777" />
        <Slider label="Width" value={w} min={1} max={10} step={0.5} onChange={setW} color="#2563eb" />
        <Slider label="Height" value={h} min={1} max={10} step={0.5} onChange={setH} color="#0d9488" />
      </div>
      <div className="mt-3 grid gap-2 sm:grid-cols-3">
        <div className="rounded-2xl bg-[#FFC5DD]/60 p-3 text-center font-extrabold">Front+Back<br />2 × {fmt(l * w)} = {fmt(2 * l * w)}</div>
        <div className="rounded-2xl bg-[#B9E3FA]/60 p-3 text-center font-extrabold">Left+Right<br />2 × {fmt(l * h)} = {fmt(2 * l * h)}</div>
        <div className="rounded-2xl bg-[#FFE89A]/70 p-3 text-center font-extrabold">Top+Bottom<br />2 × {fmt(w * h)} = {fmt(2 * w * h)}</div>
      </div>
      <p className="formula-box mt-3 rounded-2xl p-3 text-center text-xl">SA = 2({fmt(l * w)} + {fmt(l * h)} + {fmt(w * h)}) = <strong>{fmt(sa)}</strong></p>
      <Diagram kind="prism-net" className="mt-3" />
    </ToolShell>
  );
}

/* 4 — volume lab */
export function VolumeLabTool() {
  const [r, setR] = useState(3);
  const [h, setH] = useState(6);
  const cyl = Math.PI * r * r * h;
  const cone = cyl / 3;
  const sph = (4 / 3) * Math.PI * r * r * r;
  return (
    <ToolShell audio={`Radius ${r}, height ${h}. Cylinder volume ${cyl.toFixed(1)}. Cone is one third: ${cone.toFixed(1)}. Sphere with the same radius: ${sph.toFixed(1)}.`}>
      <div className="grid gap-3 sm:grid-cols-2">
        <Slider label="Radius r" value={r} min={1} max={8} step={0.5} onChange={setR} color="#7c3aed" />
        <Slider label="Height h" value={h} min={1} max={12} step={0.5} onChange={setH} color="#0d9488" />
      </div>
      <div className="mt-3 grid gap-2 sm:grid-cols-3">
        <div className="rounded-2xl bg-[#CDB8F5]/50 p-3 text-center"><p className="font-extrabold">🛢️ Cylinder</p><p className="font-display text-xl font-extrabold">{fmt(cyl, 1)}</p><p className="text-xs font-bold">πr²h</p></div>
        <div className="rounded-2xl bg-[#FFC5DD]/50 p-3 text-center"><p className="font-extrabold">🍦 Cone (⅓)</p><p className="font-display text-xl font-extrabold">{fmt(cone, 1)}</p><p className="text-xs font-bold">⅓πr²h</p></div>
        <div className="rounded-2xl bg-[#B9E3FA]/50 p-3 text-center"><p className="font-extrabold">⚽ Sphere</p><p className="font-display text-xl font-extrabold">{fmt(sph, 1)}</p><p className="text-xs font-bold">⁴⁄₃πr³</p></div>
      </div>
      <Diagram kind="cylinder" data={{ r, h }} className="mt-3" />
      <p className="mt-2 text-center text-sm font-bold text-[#6d5a86]">Watch: double the radius and the cylinder volume ×4! (r is squared 🌀)</p>
    </ToolShell>
  );
}

/* 5 — map lab */
export function MapLabTool() {
  const [scale, setScale] = useState(5);
  const [draw, setDraw] = useState(4);
  return (
    <ToolShell audio={`Scale one centimeter equals ${scale} kilometers. Drawing shows ${draw} centimeters. Actual distance is ${draw * scale} kilometers.`}>
      <div className="grid gap-3 sm:grid-cols-2">
        <Slider label="Scale (km per cm)" value={scale} min={1} max={20} step={0.5} onChange={setScale} unit=" km" color="#b45309" />
        <Slider label="Drawing distance" value={draw} min={0.5} max={12} step={0.5} onChange={setDraw} unit=" cm" color="#2563eb" />
      </div>
      <p className="formula-box mt-3 rounded-2xl p-3 text-center text-xl">{draw} cm × {scale} = <strong>{fmt(draw * scale, 1)} km</strong></p>
      <Diagram kind="map" data={{ dist: `${draw} cm`, scale: `1 cm = ${scale} km`, actual: `${fmt(draw * scale, 1)} km` }} className="mt-3" />
    </ToolShell>
  );
}

/* 6 — currency lab */
const RATES: Record<string, number> = { USD: 58.5, JPY: 0.39, EUR: 63.2, GBP: 74.1, KRW: 0.042, SGD: 43.4 };
export function CurrencyLabTool() {
  const [amount, setAmount] = useState("100");
  const [cur, setCur] = useState("USD");
  const [dir, setDir] = useState<"toPHP" | "fromPHP">("toPHP");
  const v = Number(amount);
  const rate = RATES[cur];
  const result = Number.isFinite(v) ? (dir === "toPHP" ? v * rate : v / rate) : null;
  return (
    <ToolShell audio={`Sample rate one ${cur} equals ${rate} pesos. ${amount} converts to ${result === null ? "unknown" : result.toFixed(2)}.`}>
      <div className="grid gap-3 sm:grid-cols-3">
        <label className="block rounded-2xl bg-white/80 p-3 shadow-sm">
          <span className="text-sm font-extrabold">Amount</span>
          <input value={amount} onChange={(e) => setAmount(e.target.value)} inputMode="decimal" className="mt-1 w-full rounded-xl border-2 border-[#B8E6D0] px-3 py-2 font-display text-xl font-extrabold" aria-label="Amount" />
        </label>
        <label className="block rounded-2xl bg-white/80 p-3 shadow-sm">
          <span className="text-sm font-extrabold">Currency</span>
          <select value={cur} onChange={(e) => setCur(e.target.value)} className="mt-1 w-full rounded-xl border-2 border-[#B8E6D0] px-3 py-2 font-bold" aria-label="Currency">
            {Object.keys(RATES).map((c) => <option key={c} value={c}>{c} (₱{RATES[c]})</option>)}
          </select>
        </label>
        <div className="rounded-2xl bg-white/80 p-3 shadow-sm">
          <span className="text-sm font-extrabold">Direction</span>
          <div className="mt-1 grid grid-cols-2 gap-1">
            <button type="button" onClick={() => setDir("toPHP")} className={`rounded-xl px-2 py-2 text-xs font-extrabold ${dir === "toPHP" ? "bg-[#0d9488] text-white" : "bg-slate-100"}`}>→ ₱ (×)</button>
            <button type="button" onClick={() => setDir("fromPHP")} className={`rounded-xl px-2 py-2 text-xs font-extrabold ${dir === "fromPHP" ? "bg-[#0d9488] text-white" : "bg-slate-100"}`}>₱ → (÷)</button>
          </div>
        </div>
      </div>
      <div className="formula-box mt-3 rounded-2xl p-3 text-center text-xl">
        {dir === "toPHP" ? `${amount} ${cur} = ${result === null ? "❓" : `₱${fmt(result, 2)}`}` : `₱${amount} = ${result === null ? "❓" : `${fmt(result, 2)} ${cur}`}`}
      </div>
      <p className="mt-2 text-center text-xs font-bold text-rose-600">⚠️ Sample classroom rates — real bank rates change daily!</p>
      <Diagram kind="coins" data={{ rate: `1 ${cur} = ₱${rate}`, usd: dir === "toPHP" ? `${amount} ${cur}` : `${result === null ? "?" : fmt(result, 2)} ${cur}`, php: dir === "toPHP" ? (result === null ? "?" : `₱${fmt(result, 2)}`) : `₱${amount}` }} className="mt-3" />
    </ToolShell>
  );
}

/* 7 — time lab */
function toMin(t: string) {
  const [h, m] = t.split(":").map(Number);
  return h * 60 + m;
}
export function TimeLabTool() {
  const [start, setStart] = useState("14:15");
  const [end, setEnd] = useState("16:00");
  let mins = toMin(end) - toMin(start);
  if (mins < 0) mins += 24 * 60;
  const h = Math.floor(mins / 60), m = mins % 60;
  const pretty = (t: string) => {
    let [H, M] = t.split(":").map(Number);
    const ap = H >= 12 ? "PM" : "AM";
    const h12 = H % 12 === 0 ? 12 : H % 12;
    return `${h12}:${String(M).padStart(2, "0")} ${ap}`;
  };
  return (
    <ToolShell audio={`From ${pretty(start)} to ${pretty(end)}. Elapsed time is ${h} hours and ${m} minutes, which is ${mins} minutes total.`}>
      <div className="grid gap-3 sm:grid-cols-2">
        <label className="block rounded-2xl bg-white/80 p-3 shadow-sm">
          <span className="text-sm font-extrabold">Start time</span>
          <input type="time" value={start} onChange={(e) => setStart(e.target.value)} className="mt-1 w-full rounded-xl border-2 border-[#B9E3FA] px-3 py-2 font-bold" aria-label="Start time" />
        </label>
        <label className="block rounded-2xl bg-white/80 p-3 shadow-sm">
          <span className="text-sm font-extrabold">End time</span>
          <input type="time" value={end} onChange={(e) => setEnd(e.target.value)} className="mt-1 w-full rounded-xl border-2 border-[#B9E3FA] px-3 py-2 font-bold" aria-label="End time" />
        </label>
      </div>
      <p className="formula-box mt-3 rounded-2xl p-3 text-center text-xl">{pretty(start)} → {pretty(end)} = <strong>{h} h {m} min</strong> ({mins} min)</p>
      <Diagram kind="clock" data={{ start: `Start ${pretty(start)}`, end: `End ${pretty(end)}`, elapsed: `${h} h ${m} min` }} className="mt-3" />
      <p className="mt-2 text-center text-sm font-bold text-[#6d5a86]">Tip: end before start? We wrapped past midnight! 🌙</p>
    </ToolShell>
  );
}

/* 8 — temp lab */
export function TempLabTool() {
  const [c, setC] = useState(25);
  const f = (c * 9) / 5 + 32;
  const k = c + 273.15;
  const mood = c >= 35 ? "🥵 scorching!" : c >= 28 ? "☀️ hot" : c >= 20 ? "😊 comfy" : c >= 10 ? "🧥 cool" : c >= 0 ? "❄️ cold" : "🧊 freezing!";
  return (
    <ToolShell audio={`${c} degrees Celsius equals ${f.toFixed(1)} Fahrenheit and ${k.toFixed(2)} kelvin. That feels ${mood}.`}>
      <Slider label="Celsius" value={c} min={-20} max={45} step={0.5} onChange={setC} unit="°C" color="#ef4444" />
      <div className="mt-3 grid grid-cols-3 gap-2">
        <div className="rounded-2xl bg-[#B9E3FA]/60 p-3 text-center"><p className="text-xs font-extrabold">Celsius</p><p className="font-display text-lg font-extrabold">{fmt(c, 1)}°C</p></div>
        <div className="rounded-2xl bg-[#FFC5DD]/60 p-3 text-center"><p className="text-xs font-extrabold">Fahrenheit</p><p className="font-display text-lg font-extrabold">{fmt(f, 1)}°F</p></div>
        <div className="rounded-2xl bg-[#CDB8F5]/60 p-3 text-center"><p className="text-xs font-extrabold">Kelvin</p><p className="font-display text-lg font-extrabold">{fmt(k, 2)} K</p></div>
      </div>
      <p className="mt-2 text-center text-lg font-extrabold">{mood}</p>
      <Diagram kind="thermometer" data={{ c }} className="mt-2" />
    </ToolShell>
  );
}

/* 9 — triangle lab */
export function TriangleLabTool() {
  const [a, setA] = useState(13);
  const [b, setB] = useState(14);
  const [cc, setC] = useState(15);
  const [base, setBase] = useState(10);
  const [hh, setHh] = useState(6);
  const valid = triangleValid(a, b, cc);
  const s = (a + b + cc) / 2;
  const area = heronArea(a, b, cc);
  return (
    <ToolShell audio={valid ? `Sides ${a}, ${b}, ${cc}. Perimeter ${a + b + cc}. Semiperimeter ${s}. Heron area ${area?.toFixed(1)}. Base ${base} height ${hh} gives base height area ${0.5 * base * hh}.` : `Sides ${a}, ${b}, ${cc} cannot form a triangle because they fail the triangle inequality.`}>
      <p className="mb-2 font-display font-extrabold">🔺 Heron explorer (3 sides)</p>
      <div className="grid gap-3 sm:grid-cols-3">
        <Slider label="Side a" value={a} min={1} max={20} step={0.5} onChange={setA} color="#db2777" />
        <Slider label="Side b" value={b} min={1} max={20} step={0.5} onChange={setB} color="#2563eb" />
        <Slider label="Side c" value={cc} min={1} max={20} step={0.5} onChange={setC} color="#0d9488" />
      </div>
      {valid ? (
        <div className="mt-3 rounded-2xl bg-emerald-50 p-3 text-center text-sm font-extrabold text-emerald-800">
          ✅ Valid triangle! P = {fmt(a + b + cc, 1)} · s = {fmt(s, 2)} · Heron A = {area === null ? "?" : fmt(area, 2)}
        </div>
      ) : (
        <div className="incorrect-shake mt-3 rounded-2xl bg-rose-50 p-3 text-center text-sm font-extrabold text-rose-700">
          🚫 Not a triangle! Two sides must add past the third. Try longer sides.
        </div>
      )}
      <Diagram kind="heron" data={{ a, b, c: cc }} className="mt-3" />
      <p className="mb-2 mt-4 font-display font-extrabold">📐 Base × height explorer</p>
      <div className="grid gap-3 sm:grid-cols-2">
        <Slider label="Base" value={base} min={1} max={20} step={0.5} onChange={setBase} color="#7c3aed" />
        <Slider label="Height (⊥)" value={hh} min={1} max={15} step={0.5} onChange={setHh} color="#db2777" />
      </div>
      <p className="formula-box mt-3 rounded-2xl p-3 text-center text-xl">A = ½ × {base} × {hh} = <strong>{fmt(0.5 * base * hh, 2)}</strong></p>
      <Diagram kind="triangle" data={{ b: base, h: hh }} className="mt-3" />
    </ToolShell>
  );
}

/* 10 — trig lab */
export function TrigLabTool() {
  const [mode, setMode] = useState<"angle" | "pythag" | "cosine">("angle");
  const [angle, setAngle] = useState(40);
  const [hyp, setHyp] = useState(10);
  const [a, setA] = useState(6);
  const [b, setB] = useState(8);
  const [sb, setSb] = useState(7);
  const [sc, setSc] = useState(10);
  const [A, setAang] = useState(60);

  const r = rad(angle);
  const opp = hyp * Math.sin(r);
  const adj = hyp * Math.cos(r);
  const c = Math.sqrt(a * a + b * b);
  const cosa = Math.cos(rad(A));
  const sideA = Math.sqrt(sb * sb + sc * sc - 2 * sb * sc * cosa);

  return (
    <ToolShell audio={mode === "angle" ? `Angle ${angle} degrees, hypotenuse ${hyp}. Opposite ${opp.toFixed(2)}, adjacent ${adj.toFixed(2)}. Sine ${Math.sin(r).toFixed(3)}, cosine ${Math.cos(r).toFixed(3)}, tangent ${(opp / adj).toFixed(3)}.` : mode === "pythag" ? `Legs ${a} and ${b}. Hypotenuse ${c.toFixed(2)}.` : `Sides ${sb} and ${sc} with included angle ${A} degrees. Third side ${sideA.toFixed(2)}.`}>
      <div className="mb-3 grid grid-cols-3 gap-1 rounded-2xl bg-white p-1 shadow">
        {(["angle", "pythag", "cosine"] as const).map((m) => (
          <button key={m} type="button" onClick={() => setMode(m)} className={`rounded-xl px-2 py-2 text-xs font-extrabold sm:text-sm ${mode === m ? "bg-[#49385C] text-white" : "text-[#49385C]"}`}>
            {m === "angle" ? "📐 SOH-CAH-TOA" : m === "pythag" ? "🔺 Pythagoras" : "📏 Law of Cosines"}
          </button>
        ))}
      </div>
      {mode === "angle" && (
        <>
          <div className="grid gap-3 sm:grid-cols-2">
            <Slider label="Angle θ" value={angle} min={5} max={85} step={1} onChange={setAngle} unit="°" color="#db2777" />
            <Slider label="Hypotenuse" value={hyp} min={2} max={20} step={0.5} onChange={setHyp} color="#7c3aed" />
          </div>
          <div className="mt-3 grid grid-cols-3 gap-2 text-center">
            <div className="rounded-2xl bg-[#B8E6D0]/70 p-2 font-extrabold">Opp<br /><span className="font-display text-lg">{fmt(opp, 2)}</span></div>
            <div className="rounded-2xl bg-[#B9E3FA]/70 p-2 font-extrabold">Adj<br /><span className="font-display text-lg">{fmt(adj, 2)}</span></div>
            <div className="rounded-2xl bg-[#E9DEFF] p-2 font-extrabold">Hyp<br /><span className="font-display text-lg">{hyp}</span></div>
          </div>
          <p className="formula-box mt-3 rounded-2xl p-3 text-center">sin {angle}° = {fmt(Math.sin(r), 3)} · cos = {fmt(Math.cos(r), 3)} · tan = {fmt(opp / adj, 3)}</p>
          <Diagram kind="trig-ratio" data={{ angle: `${angle}°` }} className="mt-3" />
        </>
      )}
      {mode === "pythag" && (
        <>
          <div className="grid gap-3 sm:grid-cols-2">
            <Slider label="Leg a" value={a} min={1} max={15} step={0.5} onChange={setA} color="#2563eb" />
            <Slider label="Leg b" value={b} min={1} max={15} step={0.5} onChange={setB} color="#0d9488" />
          </div>
          <p className="formula-box mt-3 rounded-2xl p-3 text-center text-xl">c = √({fmt(a * a, 1)} + {fmt(b * b, 1)}) = <strong>{fmt(c, 2)}</strong></p>
          <Diagram kind="right-triangle" data={{ a, b }} className="mt-3" />
        </>
      )}
      {mode === "cosine" && (
        <>
          <div className="grid gap-3 sm:grid-cols-3">
            <Slider label="Side b" value={sb} min={2} max={15} step={0.5} onChange={setSb} color="#2563eb" />
            <Slider label="Side c" value={sc} min={2} max={15} step={0.5} onChange={setSc} color="#0d9488" />
            <Slider label="Angle A" value={A} min={10} max={170} step={1} onChange={setAang} unit="°" color="#db2777" />
          </div>
          <p className="formula-box mt-3 rounded-2xl p-3 text-center">a² = {fmt(sb * sb, 1)} + {fmt(sc * sc, 1)} − 2({sb})({sc})cos{A}° → a = <strong>{fmt(sideA, 2)}</strong></p>
          <Diagram kind="law-cosines" className="mt-3" />
        </>
      )}
    </ToolShell>
  );
}

export function LessonTool({ kind }: { kind: string }) {
  switch (kind) {
    case "unit-compare": return <UnitCompareTool />;
    case "converter": return <ConverterTool />;
    case "prism-lab": return <PrismLabTool />;
    case "volume-lab": return <VolumeLabTool />;
    case "map-lab": return <MapLabTool />;
    case "currency-lab": return <CurrencyLabTool />;
    case "time-lab": return <TimeLabTool />;
    case "temp-lab": return <TempLabTool />;
    case "triangle-lab": return <TriangleLabTool />;
    case "trig-lab": return <TrigLabTool />;
    default: return null;
  }
}
