"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState } from "react";
import { Star, Menu, X, Home, LayoutGrid, BookOpen, GraduationCap, Gamepad2, ClipboardCheck, Trophy } from "lucide-react";
import { useProgress } from "@/lib/progress";

const LINKS = [
  { href: "/dashboard", label: "Dashboard", icon: LayoutGrid },
  { href: "/definitions", label: "Definitions", icon: BookOpen },
  { href: "/lessons", label: "Lessons", icon: GraduationCap },
  { href: "/games", label: "Games", icon: Gamepad2 },
  { href: "/practice", label: "Practices", icon: ClipboardCheck },
  { href: "/progress", label: "Stars", icon: Trophy },
];

export default function Navbar() {
  const pathname = usePathname();
  const { state } = useProgress();
  const [open, setOpen] = useState(false);
  if (pathname === "/") return null;

  return (
    <header className="sticky top-0 z-40 border-b-4 border-white/70 bg-[#FFF9F2]/90 backdrop-blur-md shadow-sm">
      <div className="mx-auto flex max-w-6xl items-center gap-2 px-3 py-2.5 sm:px-4">
        <Link href="/" className="flex items-center gap-2 rounded-2xl px-1 py-1" aria-label="Geo Measure home">
          <span className="font-display grid h-10 w-10 place-items-center rounded-2xl bg-gradient-to-br from-[#CDB8F5] via-[#FFC5DD] to-[#B9E3FA] text-xl shadow" aria-hidden>📐</span>
          <span className="font-display hidden text-lg font-extrabold leading-none text-[#49385C] min-[400px]:block">
            GEO MEASURE
            <span className="block text-[10px] font-bold tracking-wide text-[#6d5a86]">See It, Hear It, Solve It!</span>
          </span>
        </Link>
        <nav className="ml-auto hidden items-center gap-1 lg:flex" aria-label="Main navigation">
          {LINKS.map((l) => {
            const active = pathname.startsWith(l.href);
            return (
              <Link
                key={l.href}
                href={l.href}
                className={`inline-flex items-center gap-1.5 rounded-full px-3 py-2 text-sm font-extrabold transition ${
                  active ? "bg-[#49385C] text-white shadow" : "text-[#49385C] hover:bg-white"
                }`}
                aria-current={active ? "page" : undefined}
              >
                <l.icon size={15} /> {l.label}
              </Link>
            );
          })}
        </nav>
        <Link href="/progress" className="ml-auto lg:ml-2 inline-flex items-center gap-1.5 rounded-full bg-gradient-to-r from-[#FFE89A] to-[#FFC5DD] px-3.5 py-2 font-display text-sm font-extrabold text-[#49385C] shadow-md" title="Your stars">
          <Star size={15} className="fill-[#49385C]" /> {state.stars}
        </Link>
        <button
          type="button" className="btn-chunky bg-white p-2.5 text-[#49385C] shadow lg:hidden"
          onClick={() => setOpen(!open)} aria-expanded={open} aria-label={open ? "Close menu" : "Open menu"}
        >
          {open ? <X size={20} /> : <Menu size={20} />}
        </button>
      </div>
      {open && (
        <nav className="pop-in grid gap-1.5 border-t-2 border-white/70 bg-[#FFF9F2] p-3 lg:hidden" aria-label="Mobile navigation">
          <Link href="/" onClick={() => setOpen(false)} className="inline-flex items-center gap-2 rounded-2xl bg-white px-4 py-2.5 text-sm font-extrabold text-[#49385C] shadow-sm">
            <Home size={16} /> Welcome Page
          </Link>
          {LINKS.map((l) => {
            const active = pathname.startsWith(l.href);
            return (
              <Link
                key={l.href} href={l.href} onClick={() => setOpen(false)}
                className={`inline-flex items-center gap-2 rounded-2xl px-4 py-2.5 text-sm font-extrabold shadow-sm ${active ? "bg-[#49385C] text-white" : "bg-white text-[#49385C]"}`}
                aria-current={active ? "page" : undefined}
              >
                <l.icon size={16} /> {l.label}
              </Link>
            );
          })}
        </nav>
      )}
    </header>
  );
}
