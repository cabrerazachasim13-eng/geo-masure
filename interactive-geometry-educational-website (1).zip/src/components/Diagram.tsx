"use client";

import React from "react";
import type { DiagramKind } from "@/data/definitions";

/**
 * Original SVG diagrams for every concept. Mathematically labeled.
 * Pure SVG + CSS — no external assets needed.
 */
export default function Diagram({
  kind,
  data,
  className = "",
}: {
  kind: DiagramKind;
  data?: Record<string, number | string>;
  className?: string;
}) {
  const d = data ?? {};
  const num = (k: string, fb: number) => (typeof d[k] === "number" ? (d[k] as number) : fb);
  const str = (k: string, fb: string) => (typeof d[k] === "string" ? (d[k] as string) : fb);

  const wrap = (inner: React.ReactNode, label: string) => (
    <svg viewBox="0 0 320 200" className={`h-auto w-full ${className}`} role="img" aria-label={label}>
      <rect x="4" y="4" width="312" height="192" rx="18" fill="#FFF9F2" stroke="#CDB8F5" strokeWidth="2.5" />
      {inner}
    </svg>
  );

  switch (kind) {
    case "ruler": {
      return wrap(
        <>
          <rect x="30" y="70" width="260" height="54" rx="10" fill="#FFE89A" stroke="#49385C" strokeWidth="3" />
          {Array.from({ length: 21 }).map((_, i) => (
            <line key={i} x1={40 + i * 12} y1={70} x2={40 + i * 12} y2={i % 5 === 0 ? 100 : 90} stroke="#49385C" strokeWidth={i % 5 === 0 ? 2.5 : 1.5} />
          ))}
          {[0, 5, 10, 15, 20].map((v) => (
            <text key={v} x={40 + v * 12} y={118} textAnchor="middle" fontSize="11" fontWeight="800" fill="#49385C">{v} cm</text>
          ))}
          <text x="160" y="45" textAnchor="middle" fontSize="14" fontWeight="800" fill="#49385C">📏 Measure twice, smile once!</text>
          <text x="160" y="155" textAnchor="middle" fontSize="12" fontWeight="700" fill="#6d5a86">mm → cm → m → km (×10 steps)</text>
        </>, "Ruler showing centimeters and metric ladder");
    }
    case "scale-weight":
      return wrap(
        <>
          <rect x="70" y="60" width="180" height="90" rx="14" fill="#B8E6D0" stroke="#49385C" strokeWidth="3" />
          <rect x="110" y="80" width="100" height="34" rx="8" fill="#fff" stroke="#49385C" strokeWidth="2.5" />
          <text x="160" y="103" textAnchor="middle" fontSize="18" fontWeight="800" fill="#49385C">{str("weight", "2.5 kg")}</text>
          <circle cx="95" cy="132" r="7" fill="#CDB8F5" stroke="#49385C" strokeWidth="2" />
          <circle cx="225" cy="132" r="7" fill="#FFC5DD" stroke="#49385C" strokeWidth="2" />
          <text x="160" y="40" textAnchor="middle" fontSize="14" fontWeight="800" fill="#49385C">⚖️ Mass: mg → g → kg → t</text>
          <text x="160" y="172" textAnchor="middle" fontSize="12" fontWeight="700" fill="#6d5a86">1 kg = 1,000 g · 1 g = 1,000 mg</text>
        </>, "Weighing scale showing mass");
    case "beaker":
      return wrap(
        <>
          <path d="M110 50 L130 150 L190 150 L210 50 Z" fill="#B9E3FA" opacity=".5" stroke="#49385C" strokeWidth="3" strokeLinejoin="round" />
          <path d="M121 100 L133 150 L187 150 L199 100 Z" fill="#38bdf8" opacity=".7" />
          {[60, 80, 100, 120, 140].map((y) => (
            <line key={y} x1="112" y1={y} x2="126" y2={y} stroke="#49385C" strokeWidth="2" />
          ))}
          <text x="248" y="105" fontSize="13" fontWeight="800" fill="#49385C">500 mL</text>
          <text x="160" y="178" textAnchor="middle" fontSize="12" fontWeight="700" fill="#6d5a86">1 L = 1,000 mL = 1,000 cm³</text>
        </>, "Beaker showing capacity in milliliters");
    case "ladder": {
      const units = ["km", "m", "cm", "mm"];
      return wrap(
        <>
          <text x="160" y="30" textAnchor="middle" fontSize="14" fontWeight="800" fill="#49385C">🪜 Metric Ladder (×10 per step)</text>
          {units.map((u, i) => (
            <g key={u}>
              <rect x={60 + i * 55} y="70" width="48" height="40" rx="12" fill={["#B8E6D0", "#B9E3FA", "#FFE89A", "#FFC5DD"][i]} stroke="#49385C" strokeWidth="2.5" />
              <text x={84 + i * 55} y="96" textAnchor="middle" fontSize="15" fontWeight="800" fill="#49385C">{u}</text>
              {i < 3 && <text x={112 + i * 55} y="95" fontSize="16" fontWeight="800" fill="#6d5a86">→</text>}
            </g>
          ))}
          <text x="160" y="140" textAnchor="middle" fontSize="12" fontWeight="700" fill="#6d5a86">down: ×10 each step · up: ÷10 each step</text>
          <text x="160" y="162" textAnchor="middle" fontSize="12" fontWeight="800" fill="#49385C">3.2 km = 3,200 m = 320,000 cm</text>
        </>, "Metric prefix ladder");
    }
    case "scale-factor":
      return wrap(
        <>
          <text x="160" y="32" textAnchor="middle" fontSize="14" fontWeight="800" fill="#49385C">🔄 Conversion Factor Magic</text>
          <rect x="40" y="55" width="110" height="60" rx="12" fill="#B9E3FA" stroke="#49385C" strokeWidth="2.5" />
          <text x="95" y="80" textAnchor="middle" fontSize="13" fontWeight="800" fill="#49385C">{str("from", "2.5 m")}</text>
          <text x="95" y="100" textAnchor="middle" fontSize="11" fontWeight="700" fill="#6d5a86">start</text>
          <text x="160" y="95" fontSize="22">×</text>
          <rect x="180" y="55" width="100" height="60" rx="12" fill="#FFE89A" stroke="#49385C" strokeWidth="2.5" />
          <text x="230" y="80" textAnchor="middle" fontSize="12" fontWeight="800" fill="#49385C">100 cm / 1 m</text>
          <text x="230" y="100" textAnchor="middle" fontSize="11" fontWeight="700" fill="#6d5a86">factor = 1</text>
          <text x="160" y="140" textAnchor="middle" fontSize="13" fontWeight="800" fill="#0d9488">= {str("to", "250 cm")} ✓</text>
          <text x="160" y="162" textAnchor="middle" fontSize="11" fontWeight="700" fill="#6d5a86">old unit cancels, new unit stays!</text>
        </>, "Conversion factor diagram");
    case "prism-net": {
      return wrap(
        <>
          <text x="160" y="28" textAnchor="middle" fontSize="13" fontWeight="800" fill="#49385C">📦 Prism Net — 6 faces (3 pairs)</text>
          <g stroke="#49385C" strokeWidth="2">
            <rect x="120" y="60" width="60" height="40" fill="#FFC5DD" />
            <rect x="120" y="100" width="60" height="40" fill="#FFC5DD" opacity=".6" />
            <rect x="120" y="140" width="60" height="36" fill="#CDB8F5" />
            <rect x="120" y="40" width="60" height="20" fill="#CDB8F5" opacity=".6" visibility="hidden" />
            <rect x="60" y="100" width="60" height="40" fill="#B9E3FA" />
            <rect x="180" y="100" width="60" height="40" fill="#B9E3FA" opacity=".6" />
            <rect x="120" y="140" width="60" height="36" fill="#FFE89A" />
          </g>
          <text x="150" y="84" textAnchor="middle" fontSize="11" fontWeight="800" fill="#49385C">lw</text>
          <text x="150" y="124" textAnchor="middle" fontSize="11" fontWeight="800" fill="#49385C">lw</text>
          <text x="90" y="124" textAnchor="middle" fontSize="11" fontWeight="800" fill="#49385C">lh</text>
          <text x="210" y="124" textAnchor="middle" fontSize="11" fontWeight="800" fill="#49385C">lh</text>
          <text x="150" y="160" textAnchor="middle" fontSize="11" fontWeight="800" fill="#49385C">wh</text>
          <text x="262" y="90" fontSize="11" fontWeight="800" fill="#49385C">SA =</text>
          <text x="262" y="106" fontSize="11" fontWeight="800" fill="#49385C">2(lw+lh+wh)</text>
        </>, "Unfolded net of a rectangular prism");
    }
    case "cylinder": {
      const r = num("r", 3), h = num("h", 6);
      return wrap(
        <>
          <text x="110" y="30" textAnchor="middle" fontSize="13" fontWeight="800" fill="#49385C">Cylinder r={r}, h={h}</text>
          <ellipse cx="110" cy="60" rx="55" ry="16" fill="#CDB8F5" stroke="#49385C" strokeWidth="2.5" />
          <rect x="55" y="60" width="110" height="90" fill="#CDB8F5" opacity=".45" />
          <line x1="55" y1="60" x2="55" y2="150" stroke="#49385C" strokeWidth="2.5" />
          <line x1="165" y1="60" x2="165" y2="150" stroke="#49385C" strokeWidth="2.5" />
          <ellipse cx="110" cy="150" rx="55" ry="16" fill="#B9E3FA" stroke="#49385C" strokeWidth="2.5" />
          <line x1="110" y1="60" x2="165" y2="60" stroke="#db2777" strokeWidth="2.5" strokeDasharray="4 3" />
          <text x="140" y="54" fontSize="12" fontWeight="800" fill="#db2777">r</text>
          <line x1="178" y1="65" x2="178" y2="145" stroke="#0d9488" strokeWidth="2.5" />
          <text x="188" y="110" fontSize="12" fontWeight="800" fill="#0d9488">h</text>
          <text x="240" y="80" textAnchor="middle" fontSize="11" fontWeight="800" fill="#49385C">SA = 2πr²</text>
          <text x="240" y="96" textAnchor="middle" fontSize="11" fontWeight="800" fill="#49385C">+ 2πrh</text>
          <text x="240" y="122" textAnchor="middle" fontSize="11" fontWeight="800" fill="#49385C">V = πr²h</text>
          <text x="240" y="150" textAnchor="middle" fontSize="10" fontWeight="700" fill="#6d5a86">unroll side →</text>
          <text x="240" y="164" textAnchor="middle" fontSize="10" fontWeight="700" fill="#6d5a86">rectangle 2πr × h</text>
        </>, "Labeled cylinder with radius and height");
    }
    case "cone":
      return wrap(
        <>
          <text x="140" y="30" textAnchor="middle" fontSize="13" fontWeight="800" fill="#49385C">Cone: r, h, slant ℓ</text>
          <path d="M140 45 L75 145 L205 145 Z" fill="#FFC5DD" opacity=".55" stroke="#49385C" strokeWidth="2.5" strokeLinejoin="round" />
          <ellipse cx="140" cy="145" rx="65" ry="15" fill="#B9E3FA" stroke="#49385C" strokeWidth="2.5" />
          <line x1="140" y1="45" x2="140" y2="145" stroke="#0d9488" strokeWidth="2.5" strokeDasharray="5 3" />
          <text x="130" y="100" fontSize="12" fontWeight="800" fill="#0d9488">h</text>
          <line x1="140" y1="45" x2="200" y2="140" stroke="#db2777" strokeWidth="2.5" />
          <text x="182" y="92" fontSize="12" fontWeight="800" fill="#db2777">ℓ</text>
          <line x1="140" y1="145" x2="205" y2="145" stroke="#7c3aed" strokeWidth="2.5" />
          <text x="172" y="162" fontSize="12" fontWeight="800" fill="#7c3aed">r</text>
          <text x="262" y="70" textAnchor="middle" fontSize="10" fontWeight="800" fill="#49385C">SA=πr²+πrℓ</text>
          <text x="262" y="90" textAnchor="middle" fontSize="10" fontWeight="800" fill="#49385C">V=⅓πr²h</text>
        </>, "Labeled cone with radius, height, slant height");
    case "sphere": {
      const r = num("r", 5);
      return wrap(
        <>
          <text x="120" y="30" textAnchor="middle" fontSize="13" fontWeight="800" fill="#49385C">Sphere r = {r}</text>
          <circle cx="120" cy="110" r="60" fill="#B9E3FA" opacity=".6" stroke="#49385C" strokeWidth="2.5" />
          <ellipse cx="120" cy="110" rx="60" ry="20" fill="none" stroke="#49385C" strokeWidth="1.5" opacity=".5" />
          <line x1="120" y1="110" x2="170" y2="78" stroke="#db2777" strokeWidth="2.5" />
          <text x="158" y="72" fontSize="12" fontWeight="800" fill="#db2777">r</text>
          <text x="230" y="85" textAnchor="middle" fontSize="11" fontWeight="800" fill="#49385C">SA = 4πr²</text>
          <text x="230" y="105" textAnchor="middle" fontSize="11" fontWeight="800" fill="#49385C">V = ⁴⁄₃πr³</text>
          <text x="230" y="130" textAnchor="middle" fontSize="10" fontWeight="700" fill="#6d5a86">great circle = πr²</text>
          <text x="230" y="145" textAnchor="middle" fontSize="10" fontWeight="700" fill="#6d5a86">sphere = 4 × that!</text>
        </>, "Sphere with radius");
    }
    case "pyramid":
      return wrap(
        <>
          <text x="140" y="30" textAnchor="middle" fontSize="13" fontWeight="800" fill="#49385C">Square Pyramid</text>
          <path d="M140 45 L70 145 L210 145 Z" fill="#CDB8F5" opacity=".6" stroke="#49385C" strokeWidth="2.5" strokeLinejoin="round" />
          <path d="M140 45 L210 145 L140 145 Z" fill="#FFC5DD" opacity=".5" stroke="#49385C" strokeWidth="2" />
          <line x1="140" y1="45" x2="140" y2="145" stroke="#0d9488" strokeWidth="2.5" strokeDasharray="5 3" />
          <text x="130" y="100" fontSize="12" fontWeight="800" fill="#0d9488">h</text>
          <text x="140" y="165" textAnchor="middle" fontSize="12" fontWeight="800" fill="#49385C">base s × s</text>
          <text x="258" y="80" textAnchor="middle" fontSize="10" fontWeight="800" fill="#49385C">SA=s²+2sℓ</text>
          <text x="258" y="100" textAnchor="middle" fontSize="10" fontWeight="800" fill="#49385C">V=⅓Bh</text>
        </>, "Square pyramid with height and base");
    case "cube-fill":
      return wrap(
        <>
          <text x="160" y="30" textAnchor="middle" fontSize="13" fontWeight="800" fill="#49385C">🧊 Volume = unit cubes inside!</text>
          {[
            { x: 60, y: 100, c: "#FFC5DD" }, { x: 100, y: 100, c: "#FFC5DD" }, { x: 140, y: 100, c: "#FFC5DD" },
            { x: 60, y: 60, c: "#CDB8F5" }, { x: 100, y: 60, c: "#CDB8F5" }, { x: 140, y: 60, c: "#CDB8F5" },
            { x: 180, y: 100, c: "#B9E3FA" }, { x: 220, y: 100, c: "#B9E3FA" },
          ].map((b, i) => (
            <g key={i}>
              <rect x={b.x} y={b.y} width="38" height="38" rx="6" fill={b.c} stroke="#49385C" strokeWidth="2.5" />
              <text x={b.x + 19} y={b.y + 25} textAnchor="middle" fontSize="14">🧊</text>
            </g>
          ))}
          <text x="160" y="165" textAnchor="middle" fontSize="12" fontWeight="800" fill="#49385C">3 × 2 box = 6 cubes · V = lwh</text>
        </>, "Unit cubes filling a box to show volume");
    case "map":
      return wrap(
        <>
          <text x="160" y="28" textAnchor="middle" fontSize="13" fontWeight="800" fill="#49385C">🗺️ {str("title", "Sunnyville Map")}</text>
          <path d="M40 50 Q80 42 110 60 T180 58 T280 66 L280 150 Q200 162 140 150 T40 152 Z" fill="#B8E6D0" opacity=".7" stroke="#49385C" strokeWidth="2.5" />
          <circle cx="90" cy="105" r="7" fill="#db2777" stroke="#fff" strokeWidth="2" />
          <text x="90" y="92" textAnchor="middle" fontSize="10" fontWeight="800" fill="#49385C">{str("a", "Home")}</text>
          <circle cx="230" cy="100" r="7" fill="#2563eb" stroke="#fff" strokeWidth="2" />
          <text x="230" y="87" textAnchor="middle" fontSize="10" fontWeight="800" fill="#49385C">{str("b", "School")}</text>
          <line x1="97" y1="105" x2="223" y2="100" stroke="#49385C" strokeWidth="2" strokeDasharray="6 4" />
          <text x="160" y="95" textAnchor="middle" fontSize="10" fontWeight="800" fill="#49385C">{str("dist", "4 cm")}</text>
          <rect x="60" y="160" width="200" height="22" rx="11" fill="#49385C" />
          <text x="160" y="175" textAnchor="middle" fontSize="11" fontWeight="800" fill="#FFE89A">Scale: {str("scale", "1 cm = 5 km")} → {str("actual", "20 km")}</text>
        </>, "Map with scale, two places and measured distance");
    case "coins":
      return wrap(
        <>
          <text x="160" y="30" textAnchor="middle" fontSize="13" fontWeight="800" fill="#49385C">💱 Sample rate: {str("rate", "1 USD = ₱58.50")}</text>
          <circle cx="95" cy="95" r="38" fill="#FFE89A" stroke="#49385C" strokeWidth="3" />
          <text x="95" y="90" textAnchor="middle" fontSize="20" fontWeight="800" fill="#49385C">$</text>
          <text x="95" y="108" textAnchor="middle" fontSize="11" fontWeight="800" fill="#49385C">{str("usd", "10 USD")}</text>
          <text x="160" y="100" fontSize="24">→</text>
          <circle cx="225" cy="95" r="38" fill="#B8E6D0" stroke="#49385C" strokeWidth="3" />
          <text x="225" y="90" textAnchor="middle" fontSize="20" fontWeight="800" fill="#49385C">₱</text>
          <text x="225" y="108" textAnchor="middle" fontSize="11" fontWeight="800" fill="#49385C">{str("php", "₱585")}</text>
          <text x="160" y="160" textAnchor="middle" fontSize="11" fontWeight="700" fill="#6d5a86">foreign → ₱: multiply · ₱ → foreign: divide</text>
          <text x="160" y="178" textAnchor="middle" fontSize="10" fontWeight="700" fill="#be123c">⚠️ sample rate for class only!</text>
        </>, "Currency conversion between dollars and pesos");
    case "clock":
      return wrap(
        <>
          <text x="100" y="30" textAnchor="middle" fontSize="13" fontWeight="800" fill="#49385C">⏰ {str("label", "Elapsed time")}</text>
          <circle cx="100" cy="110" r="58" fill="#fff" stroke="#49385C" strokeWidth="3" />
          {Array.from({ length: 12 }).map((_, i) => {
            const a = (i * 30 * Math.PI) / 180;
            return <circle key={i} cx={100 + 48 * Math.sin(a)} cy={110 - 48 * Math.cos(a)} r="2.5" fill="#49385C" />;
          })}
          <line x1="100" y1="110" x2={100 + 30 * Math.sin(num("hourA", 2.2))} y2={110 - 30 * Math.cos(num("hourA", 2.2))} stroke="#49385C" strokeWidth="4" strokeLinecap="round" />
          <line x1="100" y1="110" x2={100 + 44 * Math.sin(num("minA", 0.5))} y2={110 - 44 * Math.cos(num("minA", 0.5))} stroke="#db2777" strokeWidth="3" strokeLinecap="round" />
          <circle cx="100" cy="110" r="5" fill="#FFE89A" stroke="#49385C" strokeWidth="2" />
          <text x="220" y="80" textAnchor="middle" fontSize="12" fontWeight="800" fill="#49385C">{str("start", "Start 2:15")}</text>
          <text x="220" y="102" textAnchor="middle" fontSize="12" fontWeight="800" fill="#49385C">{str("end", "End 4:00")}</text>
          <text x="220" y="130" textAnchor="middle" fontSize="13" fontWeight="800" fill="#0d9488">= {str("elapsed", "1 h 45 min")}</text>
          <text x="220" y="150" textAnchor="middle" fontSize="10" fontWeight="700" fill="#6d5a86">end − start</text>
        </>, "Clock showing elapsed time");
    case "thermometer": {
      const c = num("c", 25);
      const pct = Math.max(0, Math.min(100, ((c + 20) / 60) * 100));
      const h = (pct / 100) * 110;
      return wrap(
        <>
          <text x="160" y="28" textAnchor="middle" fontSize="13" fontWeight="800" fill="#49385C">🌡️ {c}°C = {Math.round((c * 9) / 5 + 32)}°F = {(c + 273.15).toFixed(2)} K</text>
          <rect x="80" y="45" width="34" height="120" rx="17" fill="#fff" stroke="#49385C" strokeWidth="3" />
          <rect x="87" y={158 - h} width="20" height={Math.max(4, h)} rx="10" fill={c >= 30 ? "#ef4444" : c >= 15 ? "#f59e0b" : "#38bdf8"} />
          <circle cx="97" cy="160" r="16" fill={c >= 30 ? "#ef4444" : c >= 15 ? "#f59e0b" : "#38bdf8"} stroke="#49385C" strokeWidth="3" />
          <text x="140" y="70" fontSize="11" fontWeight="800" fill="#49385C">100°C boiling 💧</text>
          <text x="140" y="100" fontSize="11" fontWeight="800" fill="#49385C">37°C body 🧍</text>
          <text x="140" y="130" fontSize="11" fontWeight="800" fill="#49385C">0°C freezing ❄️</text>
          <text x="140" y="160" fontSize="11" fontWeight="700" fill="#6d5a86">−18°C freezer 🧊</text>
        </>, "Thermometer with temperature benchmarks");
    }
    case "triangle": {
      const b = num("b", 10), hgt = num("h", 6);
      return wrap(
        <>
          <text x="160" y="28" textAnchor="middle" fontSize="13" fontWeight="800" fill="#49385C">🔺 A = ½ × {b} × {hgt} = {(0.5 * b * hgt).toFixed(1)}</text>
          <path d="M70 150 L250 150 L150 55 Z" fill="#CDB8F5" opacity=".55" stroke="#49385C" strokeWidth="2.5" strokeLinejoin="round" />
          <line x1="150" y1="55" x2="150" y2="150" stroke="#db2777" strokeWidth="2.5" strokeDasharray="5 3" />
          <rect x="150" y="140" width="10" height="10" fill="none" stroke="#db2777" strokeWidth="2" />
          <text x="162" y="108" fontSize="12" fontWeight="800" fill="#db2777">h={hgt} ⊥</text>
          <text x="160" y="170" textAnchor="middle" fontSize="12" fontWeight="800" fill="#49385C">base b = {b}</text>
        </>, "Triangle with base and perpendicular height");
    }
    case "rectangle": {
      const l = num("l", 8), w = num("w", 5);
      return wrap(
        <>
          <text x="160" y="28" textAnchor="middle" fontSize="13" fontWeight="800" fill="#49385C">▭ {l} × {w}: P = {2 * (l + w)}, A = {l * w}</text>
          <rect x="70" y="55" width="180" height="95" rx="8" fill="#B8E6D0" opacity=".7" stroke="#49385C" strokeWidth="2.5" />
          <line x1="70" y1="55" x2="250" y2="55" stroke="#db2777" strokeWidth="4" />
          <line x1="70" y1="150" x2="250" y2="150" stroke="#db2777" strokeWidth="4" />
          <line x1="70" y1="55" x2="70" y2="150" stroke="#2563eb" strokeWidth="4" />
          <line x1="250" y1="55" x2="250" y2="150" stroke="#2563eb" strokeWidth="4" />
          <text x="160" y="108" textAnchor="middle" fontSize="12" fontWeight="800" fill="#49385C">A = l × w</text>
          <text x="160" y="170" textAnchor="middle" fontSize="12" fontWeight="800" fill="#49385C">length {l} · width {w}</text>
        </>, "Rectangle with perimeter and area");
    }
    case "circle": {
      const r = num("r", 7);
      return wrap(
        <>
          <text x="130" y="28" textAnchor="middle" fontSize="13" fontWeight="800" fill="#49385C">○ r = {r}: C ≈ {(2 * Math.PI * r).toFixed(1)}</text>
          <circle cx="130" cy="110" r="62" fill="#B9E3FA" opacity=".55" stroke="#49385C" strokeWidth="2.5" />
          <line x1="130" y1="110" x2="185" y2="110" stroke="#db2777" strokeWidth="3" />
          <text x="160" y="102" fontSize="12" fontWeight="800" fill="#db2777">r</text>
          <line x1="75" y1="140" x2="185" y2="140" stroke="#7c3aed" strokeWidth="2.5" strokeDasharray="5 3" />
          <text x="130" y="155" textAnchor="middle" fontSize="11" fontWeight="800" fill="#7c3aed">d = 2r</text>
          <text x="248" y="95" textAnchor="middle" fontSize="11" fontWeight="800" fill="#49385C">C = 2πr</text>
          <text x="248" y="115" textAnchor="middle" fontSize="11" fontWeight="800" fill="#49385C">A = πr²</text>
          <text x="248" y="140" textAnchor="middle" fontSize="10" fontWeight="700" fill="#6d5a86">A ≈ {(Math.PI * r * r).toFixed(1)}</text>
        </>, "Circle with radius and diameter");
    }
    case "heron": {
      const a = num("a", 13), b = num("b", 14), c = num("c", 15);
      const s = (a + b + c) / 2;
      const inside = s * (s - a) * (s - b) * (s - c);
      const area = inside >= 0 ? Math.sqrt(inside) : 0;
      return wrap(
        <>
          <text x="160" y="26" textAnchor="middle" fontSize="13" fontWeight="800" fill="#49385C">Heron: s = {s}, A = {area.toFixed(1)}</text>
          <path d="M60 150 L250 150 L160 55 Z" fill="#FFE89A" opacity=".6" stroke="#49385C" strokeWidth="2.5" strokeLinejoin="round" />
          <text x="155" y="170" textAnchor="middle" fontSize="12" fontWeight="800" fill="#49385C">a = {a}</text>
          <text x="98" y="100" fontSize="12" fontWeight="800" fill="#db2777">c = {c}</text>
          <text x="212" y="105" fontSize="12" fontWeight="800" fill="#2563eb">b = {b}</text>
          <text x="160" y="125" textAnchor="middle" fontSize="10" fontWeight="700" fill="#6d5a86">s = (a+b+c)/2</text>
          <text x="160" y="45" textAnchor="middle" fontSize="11" fontWeight="800" fill="#0d9488">√[s(s−a)(s−b)(s−c)]</text>
        </>, "Triangle labeled for Heron's formula");
    }
    case "right-triangle": {
      const a = num("a", 6), b = num("b", 8);
      const c = Math.sqrt(a * a + b * b);
      return wrap(
        <>
          <text x="160" y="28" textAnchor="middle" fontSize="13" fontWeight="800" fill="#49385C">a={a}, b={b} → c={c.toFixed(1)}</text>
          <path d="M80 150 L240 150 L80 55 Z" fill="#B8E6D0" opacity=".6" stroke="#49385C" strokeWidth="2.5" strokeLinejoin="round" />
          <rect x="80" y="135" width="15" height="15" fill="none" stroke="#db2777" strokeWidth="2.5" />
          <text x="160" y="170" textAnchor="middle" fontSize="12" fontWeight="800" fill="#49385C">b = {b}</text>
          <text x="62" y="108" textAnchor="middle" fontSize="12" fontWeight="800" fill="#2563eb">a={a}</text>
          <text x="170" y="95" fontSize="12" fontWeight="800" fill="#7c3aed" transform="rotate(-32 170 95)">c = {c.toFixed(1)}</text>
          <text x="240" y="60" textAnchor="middle" fontSize="11" fontWeight="800" fill="#49385C">a²+b²=c²</text>
        </>, "Right triangle with legs and hypotenuse");
    }
    case "pythag-squares":
      return wrap(
        <>
          <text x="160" y="26" textAnchor="middle" fontSize="13" fontWeight="800" fill="#49385C">a² + b² = c² (squares on sides!)</text>
          <path d="M130 120 L200 120 L130 60 Z" fill="#FFE89A" stroke="#49385C" strokeWidth="2.5" strokeLinejoin="round" />
          <rect x="130" y="120" width="70" height="40" fill="#B8E6D0" opacity=".7" stroke="#49385C" strokeWidth="2" />
          <text x="165" y="145" textAnchor="middle" fontSize="11" fontWeight="800" fill="#49385C">b²</text>
          <rect x="88" y="60" width="42" height="60" fill="#B9E3FA" opacity=".7" stroke="#49385C" strokeWidth="2" />
          <text x="109" y="95" textAnchor="middle" fontSize="11" fontWeight="800" fill="#49385C">a²</text>
          <path d="M200 120 L240 90 L180 40 L130 60 Z" fill="#FFC5DD" opacity=".6" stroke="#49385C" strokeWidth="2" />
          <text x="205" y="82" fontSize="11" fontWeight="800" fill="#49385C">c²</text>
          <text x="160" y="178" textAnchor="middle" fontSize="11" fontWeight="700" fill="#6d5a86">3-4-5: 9 + 16 = 25 ✓</text>
        </>, "Pythagorean theorem shown with squares on each side");
    case "trig-ratio": {
      const ang = str("angle", "θ");
      return wrap(
        <>
          <text x="160" y="26" textAnchor="middle" fontSize="13" fontWeight="800" fill="#49385C">SOH-CAH-TOA at angle {ang}</text>
          <path d="M70 150 L250 150 L250 60 Z" fill="#E9DEFF" stroke="#49385C" strokeWidth="2.5" strokeLinejoin="round" />
          <rect x="235" y="135" width="15" height="15" fill="none" stroke="#49385C" strokeWidth="2" />
          <path d="M95 150 A25 25 0 0 0 90 132" fill="none" stroke="#db2777" strokeWidth="3" />
          <text x="105" y="140" fontSize="13" fontWeight="800" fill="#db2777">{ang}</text>
          <line x1="70" y1="150" x2="250" y2="150" stroke="#2563eb" strokeWidth="4" />
          <text x="160" y="170" textAnchor="middle" fontSize="11" fontWeight="800" fill="#2563eb">adjacent</text>
          <line x1="250" y1="60" x2="250" y2="150" stroke="#0d9488" strokeWidth="4" />
          <text x="272" y="110" textAnchor="middle" fontSize="11" fontWeight="800" fill="#0d9488">opp</text>
          <text x="150" y="95" fontSize="11" fontWeight="800" fill="#7c3aed" transform="rotate(32 150 95)">hypotenuse</text>
        </>, "Right triangle labeling opposite adjacent hypotenuse");
    }
    case "law-sines":
      return wrap(
        <>
          <text x="160" y="26" textAnchor="middle" fontSize="13" fontWeight="800" fill="#49385C">a/sin A = b/sin B = c/sin C</text>
          <path d="M60 150 L250 150 L180 55 Z" fill="#B9E3FA" opacity=".5" stroke="#49385C" strokeWidth="2.5" strokeLinejoin="round" />
          <text x="60" y="170" textAnchor="middle" fontSize="13" fontWeight="800" fill="#db2777">A</text>
          <text x="252" y="170" textAnchor="middle" fontSize="13" fontWeight="800" fill="#2563eb">B</text>
          <text x="180" y="45" textAnchor="middle" fontSize="13" fontWeight="800" fill="#0d9488">C</text>
          <text x="218" y="112" fontSize="12" fontWeight="800" fill="#db2777">a</text>
          <text x="112" y="108" fontSize="12" fontWeight="800" fill="#2563eb">c</text>
          <text x="155" y="168" fontSize="12" fontWeight="800" fill="#0d9488">b</text>
          <text x="160" y="45" textAnchor="middle" fontSize="10" fontWeight="700" fill="#6d5a86" dx="42">side ↔ opposite angle!</text>
        </>, "Triangle labeled for Law of Sines");
    case "law-cosines":
      return wrap(
        <>
          <text x="160" y="26" textAnchor="middle" fontSize="12" fontWeight="800" fill="#49385C">a² = b² + c² − 2bc·cos A</text>
          <path d="M60 150 L250 150 L170 60 Z" fill="#FFE89A" opacity=".55" stroke="#49385C" strokeWidth="2.5" strokeLinejoin="round" />
          <path d="M84 150 A24 24 0 0 0 80 128" fill="none" stroke="#db2777" strokeWidth="3" />
          <text x="66" y="170" textAnchor="middle" fontSize="13" fontWeight="800" fill="#db2777">A</text>
          <text x="215" y="112" fontSize="12" fontWeight="800" fill="#db2777">a = ?</text>
          <text x="112" y="105" fontSize="12" fontWeight="800" fill="#49385C">c</text>
          <text x="155" y="168" fontSize="12" fontWeight="800" fill="#49385C">b</text>
          <text x="248" y="55" textAnchor="middle" fontSize="10" fontWeight="700" fill="#6d5a86">SAS →</text>
          <text x="248" y="68" textAnchor="middle" fontSize="10" fontWeight="700" fill="#6d5a86">find a</text>
        </>, "Triangle labeled for Law of Cosines");
    case "angle-types":
      return wrap(
        <>
          <text x="160" y="26" textAnchor="middle" fontSize="13" fontWeight="800" fill="#49385C">Angles & Lines</text>
          <line x1="30" y1="70" x2="110" y2="70" stroke="#2563eb" strokeWidth="3" />
          <line x1="30" y1="90" x2="110" y2="90" stroke="#2563eb" strokeWidth="3" />
          <line x1="45" y1="66" x2="45" y2="74" stroke="#2563eb" strokeWidth="2" />
          <line x1="45" y1="86" x2="45" y2="94" stroke="#2563eb" strokeWidth="2" />
          <text x="70" y="110" textAnchor="middle" fontSize="10" fontWeight="800" fill="#49385C">parallel ∥</text>
          <line x1="140" y1="60" x2="140" y2="100" stroke="#0d9488" strokeWidth="3" />
          <line x1="120" y1="80" x2="160" y2="80" stroke="#0d9488" strokeWidth="3" />
          <rect x="140" y="80" width="8" height="8" fill="none" stroke="#0d9488" strokeWidth="2" />
          <text x="140" y="110" textAnchor="middle" fontSize="10" fontWeight="800" fill="#49385C">⊥ right</text>
          <path d="M200 100 L260 100 M200 100 L245 65" stroke="#db2777" strokeWidth="3" strokeLinecap="round" />
          <path d="M220 100 A20 20 0 0 0 214 86" fill="none" stroke="#db2777" strokeWidth="2" />
          <text x="230" y="118" textAnchor="middle" fontSize="10" fontWeight="800" fill="#49385C">acute</text>
          <text x="160" y="150" textAnchor="middle" fontSize="11" fontWeight="700" fill="#6d5a86">point · segment · ray · vertex</text>
          <text x="160" y="170" textAnchor="middle" fontSize="11" fontWeight="800" fill="#49385C">acute &lt; 90° · right = 90° · obtuse &gt; 90°</text>
        </>, "Parallel lines, perpendicular lines and acute angle");
    case "trapezoid": {
      const a = num("a", 6), b = num("b", 10), h = num("h", 4);
      return wrap(
        <>
          <text x="160" y="28" textAnchor="middle" fontSize="13" fontWeight="800" fill="#49385C">⏢ A = ½({a}+{b})×{h} = {(0.5 * (a + b) * h).toFixed(1)}</text>
          <path d="M90 150 L230 150 L195 70 L125 70 Z" fill="#FFC5DD" opacity=".55" stroke="#49385C" strokeWidth="2.5" strokeLinejoin="round" />
          <line x1="160" y1="70" x2="160" y2="150" stroke="#db2777" strokeWidth="2.5" strokeDasharray="5 3" />
          <text x="170" y="115" fontSize="12" fontWeight="800" fill="#db2777">h={h}</text>
          <text x="160" y="60" textAnchor="middle" fontSize="12" fontWeight="800" fill="#49385C">a={a}</text>
          <text x="160" y="170" textAnchor="middle" fontSize="12" fontWeight="800" fill="#49385C">b={b}</text>
        </>, "Trapezoid with two bases and height");
    }
    case "parallelogram": {
      const b = num("b", 9), h = num("h", 5);
      return wrap(
        <>
          <text x="160" y="28" textAnchor="middle" fontSize="13" fontWeight="800" fill="#49385C">▱ A = {b} × {h} = {b * h}</text>
          <path d="M100 150 L250 150 L210 65 L60 65 Z" fill="#B8E6D0" opacity=".6" stroke="#49385C" strokeWidth="2.5" strokeLinejoin="round" />
          <line x1="150" y1="65" x2="150" y2="150" stroke="#db2777" strokeWidth="2.5" strokeDasharray="5 3" />
          <text x="160" y="112" fontSize="12" fontWeight="800" fill="#db2777">h={h}</text>
          <text x="175" y="170" textAnchor="middle" fontSize="12" fontWeight="800" fill="#49385C">base = {b}</text>
        </>, "Parallelogram with base and height");
    }
    default:
      return wrap(
        <>
          <circle cx="90" cy="100" r="34" fill="#FFC5DD" opacity=".7" stroke="#49385C" strokeWidth="2.5" />
          <rect x="140" y="70" width="60" height="60" rx="10" fill="#B8E6D0" opacity=".8" stroke="#49385C" strokeWidth="2.5" />
          <path d="M220 130 L255 70 L290 130 Z" fill="#B9E3FA" opacity=".8" stroke="#49385C" strokeWidth="2.5" strokeLinejoin="round" />
          <text x="160" y="165" textAnchor="middle" fontSize="12" fontWeight="800" fill="#49385C">Shapes are everywhere! ✨</text>
        </>, "Circle, square and triangle");
  }
}
