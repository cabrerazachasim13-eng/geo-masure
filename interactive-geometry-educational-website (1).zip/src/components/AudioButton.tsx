"use client";

import { useEffect, useState } from "react";
import { Volume2, Pause, Play, Square, Loader2, VolumeX } from "lucide-react";
import {
  speakText, pauseSpeech, resumeSpeech, stopSpeech,
  subscribeSpeech, isSpeechSupported, getActiveId, type SpeechState,
} from "@/lib/audio";

export default function AudioButton({
  text,
  label = "Listen",
  size = "md",
  id,
}: {
  text: string;
  label?: string;
  size?: "sm" | "md" | "lg";
  id?: string;
}) {
  const [state, setState] = useState<SpeechState>("idle");
  const [supported] = useState(() => isSpeechSupported());
  const [busy, setBusy] = useState(false);
  const myId = id ?? `audio-${Math.random().toString(36).slice(2)}`;

  useEffect(() => subscribeSpeech((s) => {
    // only reflect global state if this button triggered it, else idle
    const active = getActiveId();
    if (active === null) setState(s === "playing" || s === "paused" ? "idle" : s);
    else if (active === myId) setState(s);
    else setState("idle");
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }), [myId]);

  useEffect(() => () => {
    if (getActiveId() === myId) stopSpeech();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [myId]);

  const cls = size === "sm"
    ? "text-xs px-3 py-1.5 gap-1.5"
    : size === "lg" ? "text-base px-5 py-2.5 gap-2" : "text-sm px-4 py-2 gap-2";

  if (!supported) {
    return (
      <span title="Audio narration is not available in this browser" className={`inline-flex items-center rounded-full bg-slate-100 text-slate-500 font-bold ${cls}`}>
        <VolumeX size={16} /> Audio unavailable
      </span>
    );
  }

  const playing = state === "playing";
  const paused = state === "paused";

  return (
    <span className="inline-flex items-center gap-1.5">
      {!playing && !paused && (
        <button
          type="button"
          aria-label={`${label}: play narration`}
          disabled={busy}
          onClick={async () => {
            setBusy(true);
            try { await speakText(text, myId); } finally { setBusy(false); }
          }}
          className={`btn-chunky inline-flex items-center bg-[#CDB8F5] text-[#49385C] shadow-md ${cls}`}
        >
          {busy ? <Loader2 size={16} className="animate-spin" /> : <Volume2 size={16} />}
          {label}
        </button>
      )}
      {playing && (
        <>
          <button type="button" aria-label="Pause narration" onClick={pauseSpeech} className={`btn-chunky inline-flex items-center bg-[#FFE89A] text-[#49385C] shadow-md ${cls}`}>
            <Pause size={16} /> Pause
          </button>
          <button type="button" aria-label="Stop narration" onClick={stopSpeech} className={`btn-chunky inline-flex items-center bg-white text-[#49385C] shadow-md ${cls}`}>
            <Square size={16} /> Stop
          </button>
          <span className="twinkle text-lg" aria-hidden>🎵</span>
        </>
      )}
      {paused && (
        <>
          <button type="button" aria-label="Resume narration" onClick={resumeSpeech} className={`btn-chunky inline-flex items-center bg-[#B8E6D0] text-[#49385C] shadow-md ${cls}`}>
            <Play size={16} /> Resume
          </button>
          <button type="button" aria-label="Stop narration" onClick={stopSpeech} className={`btn-chunky inline-flex items-center bg-white text-[#49385C] shadow-md ${cls}`}>
            <Square size={16} /> Stop
          </button>
        </>
      )}
      {state === "finished" && <span className="text-xs font-bold text-emerald-600">✓ Done</span>}
    </span>
  );
}
