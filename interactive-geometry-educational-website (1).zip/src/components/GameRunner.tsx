"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import Link from "next/link";
import { RotateCcw, ArrowRight, Timer, Trophy } from "lucide-react";
import type { GameMeta } from "@/data/games";
import { MATCH_PAIRS, MATCH_COUNT, RACE_TIME, quizQuestionsFor, raceQuestions } from "@/data/games";
import type { Difficulty, Question } from "@/data/questions";
import { checkNumeric, shuffle } from "@/lib/math";
import { useProgress } from "@/lib/progress";
import { ProgressBar, FeedbackBanner, Celebrate, DifficultyBadge } from "@/components/ui";
import Diagram from "@/components/Diagram";
import AudioButton from "@/components/AudioButton";

/* ================= QUIZ MODE (also used for race) ================= */

function QuizRunner({ game, diff, timed, onRestart }: { game: GameMeta; diff: Difficulty; timed: boolean; onRestart: () => void }) {
  const { recordGame } = useProgress();
  const questions = useMemo(
    () => (timed ? raceQuestions(diff) : quizQuestionsFor(game.id, diff)),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [game.id, diff, timed]
  );
  const [idx, setIdx] = useState(0);
  const [picked, setPicked] = useState<number | null>(null);
  const [input, setInput] = useState("");
  const [answered, setAnswered] = useState(false);
  const [ok, setOk] = useState(false);
  const [score, setScore] = useState(0);
  const [done, setDone] = useState(false);
  const [timeLeft, setTimeLeft] = useState(RACE_TIME[diff]);
  const [reward, setReward] = useState<{ stars: number; perfect: boolean } | null>(null);
  const awarded = useRef(false);
  const total = timed ? questions.length : Math.min(questions.length, 8);
  const qs = questions.slice(0, total);
  const q: Question | undefined = qs[idx];

  useEffect(() => {
    if (!timed || done) return;
    if (timeLeft <= 0) { finish(); return; }
    const t = setTimeout(() => setTimeLeft(timeLeft - 1), 1000);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [timeLeft, timed, done]);

  const finish = () => {
    if (awarded.current) return;
    awarded.current = true;
    const answeredCount = timed ? idx + (answered ? 1 : 0) : total;
    const finalTotal = timed ? Math.max(1, answeredCount) : total;
    const r = recordGame(`${game.id}-${diff}`, game.primaryCompetency, score, finalTotal);
    setReward({ stars: r.stars, perfect: r.perfect });
    setDone(true);
  };

  if (done || (!timed && idx >= total)) {
    if (!done) finish();
    return (
      <div className="space-y-4">
        <div className="card-pastel p-6 text-center">
          <Trophy size={48} className="mx-auto text-amber-500" />
          <h3 className="font-display mt-2 text-2xl font-extrabold">
            {game.emoji} {game.title} Complete!
          </h3>
          <p className="mt-1 font-bold text-[#6d5a86]">
            Difficulty: <DifficultyBadge level={diff} /> · Score: {score}/{timed ? Math.max(1, idx + (answered ? 1 : 0)) : total}
          </p>
          <div className="mx-auto mt-3 max-w-xs">
            <ProgressBar value={(score / Math.max(1, timed ? idx + (answered ? 1 : 0) : total)) * 100} />
          </div>
          <p className="mt-2 text-sm font-semibold text-[#6d5a86]">
            {reward?.perfect ? "🏆 PERFECT SCORE! You are a true Superstar!" : score >= Math.ceil(total / 2) ? "🌟 Great effort! Practice makes superstars!" : "💖 Good try! Every mistake is a step forward!"}
          </p>
        </div>
        {reward && <Celebrate stars={reward.stars} message="Stars added to your collection!" />}
        <div className="flex flex-wrap justify-center gap-2">
          <button type="button" onClick={onRestart} className="btn-chunky inline-flex items-center gap-2 bg-[#8b5cf6] px-6 py-2.5 text-white">
            <RotateCcw size={16} /> Play Again
          </button>
          <Link href="/games" className="btn-chunky inline-flex items-center gap-2 bg-white px-6 py-2.5 text-[#49385C] shadow">
            Back to Starland 🎮
          </Link>
        </div>
      </div>
    );
  }

  if (!q) return null;

  const submitMC = (oi: number) => {
    if (answered) return;
    const correct = oi === q.correctIndex;
    setPicked(oi);
    setOk(correct);
    setAnswered(true);
    if (correct) setScore(score + 1);
  };

  const submitNumeric = () => {
    if (answered || input.trim() === "") return;
    const res = checkNumeric(input, q.correctNumeric ?? 0, { tolerance: q.tolerance ?? 0.05 });
    setOk(res.ok);
    setAnswered(true);
    if (res.ok) setScore(score + 1);
  };

  const nextQ = () => {
    if (idx + 1 >= total) { finish(); return; }
    setIdx(idx + 1);
    setPicked(null);
    setInput("");
    setAnswered(false);
    setOk(false);
  };

  const maxShow = timed ? Math.max(5, idx + 1) : total;

  return (
    <div className="space-y-4">
      <div className="card-pastel flex flex-wrap items-center gap-3 p-4">
        <span className="font-display text-sm font-extrabold">Q{idx + 1}{timed ? "" : `/${total}`}</span>
        <div className="min-w-[120px] flex-1"><ProgressBar value={((idx + (answered ? 1 : 0)) / maxShow) * 100} /></div>
        <span className="rounded-full bg-[#FFE89A] px-3 py-1 text-xs font-extrabold">⭐ Score: {score}</span>
        {timed && (
          <span className={`inline-flex items-center gap-1 rounded-full px-3 py-1 text-xs font-extrabold ${timeLeft <= 15 ? "animate-pulse bg-rose-400 text-white" : "bg-[#49385C] text-white"}`}>
            <Timer size={13} /> {timeLeft}s
          </span>
        )}
      </div>

      <article className="card-pastel space-y-3 p-5">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <DifficultyBadge level={q.difficulty} />
          <AudioButton text={`${q.speak}. ${q.type === "mc" && q.options ? "Choices: " + q.options.join(", ") : ""}`} label="Hear question" size="sm" id={`gq-${idx}`} />
        </div>
        <h3 className="font-display text-lg font-extrabold sm:text-xl">{q.prompt}</h3>
        {q.formula && <p className="formula-box rounded-2xl p-2 text-center font-extrabold">{q.formula}</p>}
        <div className="mx-auto max-w-md"><Diagram kind={q.diagram} data={q.diagramData} /></div>

        {q.type === "mc" && q.options ? (
          <div className="grid gap-2 sm:grid-cols-2">
            {q.options.map((op, oi) => {
              const isPicked = picked === oi;
              const showRight = answered && oi === q.correctIndex;
              const showWrong = answered && isPicked && oi !== q.correctIndex;
              return (
                <button
                  key={oi} type="button" onClick={() => submitMC(oi)} disabled={answered}
                  className={`rounded-2xl p-3 text-left text-sm font-bold transition ${showRight ? "correct-glow bg-emerald-50" : showWrong ? "incorrect-shake bg-rose-50" : isPicked ? "bg-[#E9DEFF]" : "bg-slate-50 hover:bg-white"}`}
                  style={{ borderWidth: 3, borderColor: showRight ? "#34d399" : showWrong ? "#fb7185" : isPicked ? "#8b5cf6" : "#e2e8f0" }}
                >
                  {showRight ? "✅ " : showWrong ? "❌ " : ""}{op}
                </button>
              );
            })}
          </div>
        ) : (
          <div className="flex flex-col gap-2 sm:flex-row">
            <input
              value={input} onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && submitNumeric()}
              disabled={answered} inputMode="decimal" placeholder="Type your answer…"
              className="flex-1 rounded-2xl border-4 border-[#CDB8F5] px-4 py-3 font-display text-lg font-extrabold outline-none focus:border-[#8b5cf6]"
              aria-label="Your answer"
            />
            {!answered && (
              <button type="button" onClick={submitNumeric} className="btn-chunky bg-[#8b5cf6] px-8 py-3 text-white">
                Answer ✨
              </button>
            )}
          </div>
        )}

        {answered && (
          <div className="pop-in space-y-2">
            <FeedbackBanner
              kind={ok ? "correct" : "incorrect"}
              title={ok ? "Correct! Amazing work! 🎉" : q.type === "mc" ? `Not quite — the answer is "${q.options?.[q.correctIndex ?? 0]}".` : `Not quite — the answer is ${q.correctNumeric}${q.unit ? " " + q.unit : ""}.`}
              message={q.explanation}
            />
            <div className="flex justify-end">
              <AudioButton text={`${ok ? "Correct! " : "Not quite. "}${q.explanation}`} label="Hear why" size="sm" id={`gqe-${idx}`} />
            </div>
            <button type="button" onClick={nextQ} className="btn-chunky inline-flex w-full items-center justify-center gap-2 bg-[#49385C] py-3 text-white sm:w-auto sm:px-10">
              {idx + 1 >= total ? "Finish! 🏁" : "Next ➜"} <ArrowRight size={16} />
            </button>
          </div>
        )}
      </article>
    </div>
  );
}

/* ================= MATCH MODE ================= */

interface CardT { key: string; text: string; side: "L" | "R"; pair: number }

function MatchRunner({ game, diff, onRestart }: { game: GameMeta; diff: Difficulty; onRestart: () => void }) {
  const { recordGame } = useProgress();
  const pairs = useMemo(() => shuffle(MATCH_PAIRS).slice(0, MATCH_COUNT[diff]), [diff]);
  const [left, setLeft] = useState<CardT[]>(() => shuffle(pairs.map((p, i) => ({ key: `L${i}`, text: p[0], side: "L" as const, pair: i }))));
  const [right, setRight] = useState<CardT[]>(() => shuffle(pairs.map((p, i) => ({ key: `R${i}`, text: p[1], side: "R" as const, pair: i }))));
  const [selL, setSelL] = useState<number | null>(null);
  const [selR, setSelR] = useState<number | null>(null);
  const [matched, setMatched] = useState<number[]>([]);
  const [mistakes, setMistakes] = useState(0);
  const [flash, setFlash] = useState<"good" | "bad" | null>(null);
  const [reward, setReward] = useState<{ stars: number; perfect: boolean } | null>(null);
  const awarded = useRef(false);

  // re-shuffle when difficulty changes
  useEffect(() => {
    setLeft(shuffle(pairs.map((p, i) => ({ key: `L${i}`, text: p[0], side: "L" as const, pair: i }))));
    setRight(shuffle(pairs.map((p, i) => ({ key: `R${i}`, text: p[1], side: "R" as const, pair: i }))));
    setMatched([]);
    setMistakes(0);
    setSelL(null);
    setSelR(null);
    awarded.current = false;
    setReward(null);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [diff]);

  useEffect(() => {
    if (selL !== null && selR !== null) {
      if (selL === selR) {
        setMatched((m) => [...m, selL]);
        setFlash("good");
        setTimeout(() => { setSelL(null); setSelR(null); setFlash(null); }, 450);
      } else {
        setMistakes((m) => m + 1);
        setFlash("bad");
        setTimeout(() => { setSelL(null); setSelR(null); setFlash(null); }, 600);
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selL, selR]);

  useEffect(() => {
    if (matched.length === pairs.length && !awarded.current && pairs.length > 0) {
      awarded.current = true;
      const perfect = mistakes === 0;
      const r = recordGame(`${game.id}-${diff}`, game.primaryCompetency, pairs.length, pairs.length);
      setReward({ stars: r.stars, perfect });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [matched]);

  const finished = matched.length === pairs.length;

  if (finished && reward) {
    return (
      <div className="space-y-4">
        <div className="card-pastel p-6 text-center">
          <p className="text-5xl">🧩🎉</p>
          <h3 className="font-display mt-2 text-2xl font-extrabold">All pairs matched!</h3>
          <p className="mt-1 font-bold text-[#6d5a86]">
            {pairs.length}/{pairs.length} pairs · {mistakes} mistake{mistakes === 1 ? "" : "s"}
            {reward.perfect ? " · 🏆 FLAWLESS!" : ""}
          </p>
          <div className="mx-auto mt-3 grid max-w-md grid-cols-2 gap-1.5">
            {pairs.map((p, i) => (
              <div key={i} className="rounded-xl bg-emerald-50 px-2 py-1 text-xs font-extrabold text-emerald-800">✅ {p[0]} = {p[1]}</div>
            ))}
          </div>
        </div>
        <Celebrate stars={reward.stars} message="Matching master!" />
        <div className="flex flex-wrap justify-center gap-2">
          <button type="button" onClick={onRestart} className="btn-chunky inline-flex items-center gap-2 bg-[#8b5cf6] px-6 py-2.5 text-white">
            <RotateCcw size={16} /> Play Again
          </button>
          <Link href="/games" className="btn-chunky inline-flex items-center gap-2 bg-white px-6 py-2.5 text-[#49385C] shadow">
            Back to Starland 🎮
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="card-pastel flex flex-wrap items-center gap-3 p-4">
        <span className="font-display text-sm font-extrabold">🧩 {matched.length}/{pairs.length} matched</span>
        <div className="min-w-[120px] flex-1"><ProgressBar value={(matched.length / pairs.length) * 100} color="mint" /></div>
        <span className="rounded-full bg-[#FFE89A] px-3 py-1 text-xs font-extrabold">💡 Mistakes: {mistakes}</span>
      </div>
      {flash === "good" && <FeedbackBanner kind="correct" title="Perfect match! 🎉" />}
      {flash === "bad" && <FeedbackBanner kind="incorrect" title="Oops, not a pair —" message="look carefully and try again!" />}
      <div className="grid grid-cols-2 gap-3 sm:gap-4">
        <div className="space-y-2">
          <p className="text-center text-xs font-extrabold uppercase tracking-wider text-[#6d5a86]">Quantity</p>
          {left.map((c) => {
            const isMatched = matched.includes(c.pair);
            const isSel = selL === c.pair;
            return (
              <button
                key={c.key} type="button" disabled={isMatched}
                onClick={() => setSelL(c.pair)}
                className={`w-full rounded-2xl p-3 font-display text-base font-extrabold shadow transition sm:text-lg ${isMatched ? "bg-emerald-100 text-emerald-700 opacity-70" : isSel ? "correct-glow bg-[#CDB8F5]" : "bg-white hover:bg-[#E9DEFF]"} ${flash === "bad" && isSel ? "incorrect-shake" : ""}`}
              >
                {isMatched ? "✅ " : ""}{c.text}
              </button>
            );
          })}
        </div>
        <div className="space-y-2">
          <p className="text-center text-xs font-extrabold uppercase tracking-wider text-[#6d5a86]">Match</p>
          {right.map((c) => {
            const isMatched = matched.includes(c.pair);
            const isSel = selR === c.pair;
            return (
              <button
                key={c.key} type="button" disabled={isMatched}
                onClick={() => setSelR(c.pair)}
                className={`w-full rounded-2xl p-3 font-display text-base font-extrabold shadow transition sm:text-lg ${isMatched ? "bg-emerald-100 text-emerald-700 opacity-70" : isSel ? "correct-glow bg-[#FFC5DD]" : "bg-white hover:bg-[#FFE9F3]"} ${flash === "bad" && isSel ? "incorrect-shake" : ""}`}
              >
                {isMatched ? "✅ " : ""}{c.text}
              </button>
            );
          })}
        </div>
      </div>
      <p className="text-center text-sm font-bold text-[#6d5a86]">Tap one card from each side to make a pair! 💖</p>
    </div>
  );
}

/* ================= SHELL ================= */

export default function GameRunner({ game }: { game: GameMeta }) {
  const [diff, setDiff] = useState<Difficulty | null>(null);
  const [round, setRound] = useState(0);

  if (!diff) {
    return (
      <div className="card-pastel mx-auto max-w-xl space-y-4 p-6 text-center">
        <p className="text-6xl">{game.emoji}</p>
        <h3 className="font-display text-2xl font-extrabold">{game.title}</h3>
        <p className="text-sm font-semibold text-[#6d5a86]">{game.instructions}</p>
        <div className="flex justify-center"><AudioButton text={`${game.title}. ${game.instructions} Choose Easy, Intermediate, or Challenge to begin!`} label="Hear how to play" size="sm" /></div>
        <p className="font-display font-extrabold">Pick your challenge level:</p>
        <div className="grid gap-2">
          {(["Easy", "Intermediate", "Challenge"] as Difficulty[]).map((d) => (
            <button
              key={d} type="button" onClick={() => setDiff(d)}
              className={`btn-chunky py-3 text-lg shadow ${d === "Easy" ? "bg-[#B8E6D0] text-[#49385C]" : d === "Intermediate" ? "bg-[#FFE89A] text-[#49385C]" : "bg-[#FFC5DD] text-[#49385C]"}`}
            >
              {d === "Easy" ? "🌱" : d === "Intermediate" ? "🌟" : "🔥"} {d}
              <span className="ml-2 text-xs font-bold opacity-70">
                {game.kind === "match" ? `${MATCH_COUNT[d]} pairs` : game.kind === "race" ? `${RACE_TIME[d]}s race` : `${d === "Easy" ? 5 : d === "Intermediate" ? 7 : 8} questions`}
              </span>
            </button>
          ))}
        </div>
        <div className="rounded-2xl bg-[#E9DEFF]/60 p-3 text-left text-xs font-semibold text-[#6d5a86]">
          ⭐ <strong>Star rewards:</strong> +2 for finishing, +1 per correct answer, +3 perfect bonus! Replays always count — beat your best!
        </div>
      </div>
    );
  }

  return (
    <div key={`${diff}-${round}`} className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <button type="button" onClick={() => setDiff(null)} className="btn-chunky bg-white px-4 py-2 text-xs text-[#49385C] shadow">
          ← Change level
        </button>
        <span className="text-sm font-extrabold"><DifficultyBadge level={diff} /></span>
      </div>
      {game.kind === "match" ? (
        <MatchRunner game={game} diff={diff} onRestart={() => setRound(round + 1)} />
      ) : (
        <QuizRunner game={game} diff={diff} timed={game.kind === "race"} onRestart={() => setRound(round + 1)} />
      )}
    </div>
  );
}
