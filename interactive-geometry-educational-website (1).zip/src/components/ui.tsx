"use client";

import React from "react";
import Link from "next/link";
import { Star, ArrowLeft, Home, Sparkles } from "lucide-react";

/* ---------- Mascots (original bear-inspired SVG friends) ---------- */

export type MascotName = "sunny" | "berry" | "minty" | "skye" | "plummy" | "rainbow";

const MASCOT_COLORS: Record<MascotName, { fur: string; belly: string; accent: string; name: string; trait: string }> = {
  sunny: { fur: "#FFE89A", belly: "#FFF6DA", accent: "#FF9EBB", name: "Sunny", trait: "Cheerleader of Trying Again" },
  berry: { fur: "#FFC5DD", belly: "#FFE9F3", accent: "#8b5cf6", name: "Berry", trait: "Word Explorer" },
  minty: { fur: "#B8E6D0", belly: "#E9FFF5", accent: "#0d9488", name: "Minty", trait: "Measurement Master" },
  skye: { fur: "#B9E3FA", belly: "#EAF7FF", accent: "#2563eb", name: "Skye", trait: "Shape Detective" },
  plummy: { fur: "#CDB8F5", belly: "#F1E9FF", accent: "#7c3aed", name: "Plummy", trait: "Problem Solver" },
  rainbow: { fur: "#FFD9C7", belly: "#FFF1E6", accent: "#f472b6", name: "Rainbee", trait: "Confidence Coach" },
};

export function Mascot({ name = "sunny", size = 96, mood = "happy" }: { name?: MascotName; size?: number; mood?: "happy" | "party" | "thinking" }) {
  const c = MASCOT_COLORS[name];
  const id = React.useId().replace(/:/g, "");
  return (
    <svg width={size} height={size} viewBox="0 0 120 120" role="img" aria-label={`${c.name} the bear, ${c.trait}`}>
      <defs>
        <radialGradient id={`belly-${id}`} cx="50%" cy="40%" r="70%">
          <stop offset="0%" stopColor="#ffffff" stopOpacity=".8" />
          <stop offset="100%" stopColor={c.belly} />
        </radialGradient>
      </defs>
      {/* ears */}
      <circle cx="30" cy="30" r="16" fill={c.fur} stroke="#fff" strokeWidth="4" />
      <circle cx="30" cy="30" r="7" fill={c.accent} opacity=".55" />
      <circle cx="90" cy="30" r="16" fill={c.fur} stroke="#fff" strokeWidth="4" />
      <circle cx="90" cy="30" r="7" fill={c.accent} opacity=".55" />
      {/* head */}
      <ellipse cx="60" cy="60" rx="42" ry="40" fill={c.fur} stroke="#fff" strokeWidth="4" />
      {/* belly patch */}
      <ellipse cx="60" cy="82" rx="20" ry="16" fill={`url(#belly-${id})`} />
      {name === "sunny" && <text x="60" y="89" textAnchor="middle" fontSize="16">⭐</text>}
      {name === "berry" && <text x="60" y="89" textAnchor="middle" fontSize="16">📖</text>}
      {name === "minty" && <text x="60" y="89" textAnchor="middle" fontSize="16">📏</text>}
      {name === "skye" && <text x="60" y="89" textAnchor="middle" fontSize="16">🔺</text>}
      {name === "plummy" && <text x="60" y="89" textAnchor="middle" fontSize="16">💡</text>}
      {name === "rainbow" && <text x="60" y="89" textAnchor="middle" fontSize="16">🌈</text>}
      {/* eyes */}
      {mood === "thinking" ? (
        <>
          <circle cx="45" cy="55" r="4.5" fill="#49385C" />
          <circle cx="75" cy="48" r="4.5" fill="#49385C" />
        </>
      ) : (
        <>
          <ellipse cx="45" cy="54" rx="5" ry="6.5" fill="#49385C" />
          <ellipse cx="75" cy="54" rx="5" ry="6.5" fill="#49385C" />
          <circle cx="46.5" cy="52" r="1.8" fill="#fff" />
          <circle cx="76.5" cy="52" r="1.8" fill="#fff" />
        </>
      )}
      {/* blush */}
      <ellipse cx="36" cy="63" rx="6" ry="3.5" fill={c.accent} opacity=".35" />
      <ellipse cx="84" cy="63" rx="6" ry="3.5" fill={c.accent} opacity=".35" />
      {/* snout */}
      <ellipse cx="60" cy="64" rx="10" ry="7.5" fill="#fff" opacity=".9" />
      <ellipse cx="60" cy="62" rx="3.6" ry="2.8" fill="#49385C" />
      {mood === "happy" || mood === "party" ? (
        <path d="M53 67 Q60 72 67 67" stroke="#49385C" strokeWidth="2.2" fill="none" strokeLinecap="round" />
      ) : (
        <path d="M54 69 Q60 67 66 69" stroke="#49385C" strokeWidth="2.2" fill="none" strokeLinecap="round" />
      )}
      {mood === "party" && (
        <>
          <path d="M60 6 L70 24 L50 24 Z" fill={c.accent} />
          <circle cx="60" cy="6" r="3" fill="#FFE89A" stroke="#fff" strokeWidth="1.5" />
        </>
      )}
    </svg>
  );
}

export function MascotBadge({ name, size = 56 }: { name: MascotName; size?: number }) {
  const c = MASCOT_COLORS[name];
  return (
    <span className="inline-flex items-center gap-2 rounded-full bg-white/90 px-2 py-1 shadow" title={`${c.name} — ${c.trait}`}>
      <Mascot name={name} size={size} />
      <span className="pr-2 text-left leading-tight">
        <span className="font-display block text-sm font-extrabold text-[#49385C]">{c.name}</span>
        <span className="block text-[11px] font-semibold text-[#6d5a86]">{c.trait}</span>
      </span>
    </span>
  );
}

/* ---------- Decorations ---------- */

export function StarField({ count = 14 }: { count?: number }) {
  const stars = React.useMemo(() => {
    // deterministic pseudo-random so SSR matches
    const arr = [];
    let seed = 42;
    const rnd = () => { seed = (seed * 9301 + 49297) % 233280; return seed / 233280; };
    for (let i = 0; i < count; i++) {
      arr.push({ left: rnd() * 100, top: rnd() * 100, size: 10 + rnd() * 16, delay: rnd() * 2, emoji: ["⭐", "✨", "💖", "🌟"][Math.floor(rnd() * 4)] });
    }
    return arr;
  }, [count]);
  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden" aria-hidden>
      {stars.map((s, i) => (
        <span key={i} className="twinkle absolute" style={{ left: `${s.left}%`, top: `${s.top}%`, fontSize: s.size, animationDelay: `${s.delay}s` }}>{s.emoji}</span>
      ))}
    </div>
  );
}

export function Cloud({ className = "", style }: { className?: string; style?: React.CSSProperties }) {
  return (
    <svg viewBox="0 0 200 80" className={className} style={style} aria-hidden>
      <ellipse cx="60" cy="55" rx="40" ry="22" fill="white" opacity=".95" />
      <ellipse cx="100" cy="42" rx="42" ry="26" fill="white" opacity=".95" />
      <ellipse cx="140" cy="55" rx="36" ry="20" fill="white" opacity=".95" />
    </svg>
  );
}

export function Rainbow({ className = "w-40" }: { className?: string }) {
  return (
    <svg viewBox="0 0 200 100" className={className} aria-hidden>
      {["#FF9EBB", "#FFB26B", "#FFE89A", "#B8E6D0", "#B9E3FA", "#CDB8F5"].map((c, i) => (
        <path key={c} d={`M ${20 + i * 9} 95 A ${80 - i * 9} ${80 - i * 9} 0 0 1 ${180 - i * 9} 95`} fill="none" stroke={c} strokeWidth="9" strokeLinecap="round" />
      ))}
      <ellipse cx="25" cy="90" rx="18" ry="10" fill="#fff" />
      <ellipse cx="175" cy="90" rx="18" ry="10" fill="#fff" />
    </svg>
  );
}

/* ---------- UI atoms ---------- */

export function StarsPill({ stars }: { stars: number }) {
  return (
    <span className="inline-flex items-center gap-1.5 rounded-full bg-gradient-to-r from-[#FFE89A] to-[#FFC5DD] px-4 py-1.5 font-display text-sm font-extrabold text-[#49385C] shadow-md">
      <Star size={16} className="fill-[#49385C] text-[#49385C]" /> {stars} stars
    </span>
  );
}

export function ProgressBar({ value, color = "rainbow", height = "h-3.5" }: { value: number; color?: "rainbow" | "mint" | "grape" | "pink" | "sky"; height?: string }) {
  const bg = color === "rainbow" ? "rainbow-bar" : color === "mint" ? "bg-[#34d399]" : color === "grape" ? "bg-[#8b5cf6]" : color === "pink" ? "bg-[#f472b6]" : "bg-[#38bdf8]";
  return (
    <div className={`w-full overflow-hidden rounded-full bg-white shadow-inner ${height}`} role="progressbar" aria-valuenow={Math.round(value)} aria-valuemin={0} aria-valuemax={100}>
      <div className={`${bg} h-full rounded-full transition-all duration-700`} style={{ width: `${Math.max(0, Math.min(100, value))}%` }} />
    </div>
  );
}

export function FeedbackBanner({ kind, title, message }: { kind: "correct" | "incorrect" | "info"; title: string; message?: string }) {
  const styles = kind === "correct"
    ? "bg-emerald-50 border-emerald-300 text-emerald-800"
    : kind === "incorrect" ? "bg-rose-50 border-rose-300 text-rose-800" : "bg-sky-50 border-sky-300 text-sky-800";
  const icon = kind === "correct" ? "✅" : kind === "incorrect" ? "💡" : "✨";
  return (
    <div role="status" className={`pop-in rounded-2xl border-2 p-3 text-sm font-semibold ${styles}`}>
      <span aria-hidden className="mr-2">{icon}</span>
      <strong>{title}</strong>
      {message && <span className="ml-1 font-medium">{message}</span>}
    </div>
  );
}

export function PageHeader({ eyebrow, title, subtitle, mascot = "sunny", right }: {
  eyebrow: string; title: string; subtitle?: string; mascot?: MascotName; right?: React.ReactNode;
}) {
  return (
    <div className="relative overflow-hidden rounded-[2rem] bg-gradient-to-br from-[#CDB8F5] via-[#FFC5DD] to-[#B9E3FA] p-6 sm:p-8 shadow-xl">
      <StarField count={10} />
      <div className="relative flex flex-wrap items-center gap-4">
        <div className="float-slow shrink-0 rounded-full bg-white/80 p-1 shadow-lg">
          <Mascot name={mascot} size={84} />
        </div>
        <div className="min-w-[200px] flex-1">
          <p className="font-display text-xs font-extrabold uppercase tracking-[.2em] text-[#49385C]/80">{eyebrow}</p>
          <h1 className="font-display text-2xl sm:text-4xl font-extrabold text-[#49385C] drop-shadow-sm">{title}</h1>
          {subtitle && <p className="mt-1 max-w-2xl text-sm sm:text-base font-semibold text-[#49385C]/85">{subtitle}</p>}
        </div>
        {right && <div className="flex items-center gap-2">{right}</div>}
      </div>
    </div>
  );
}

export function BackLinks({ showHome = true }: { showHome?: boolean }) {
  return (
    <div className="flex flex-wrap items-center gap-2">
      <Link href="/dashboard" className="btn-chunky inline-flex items-center gap-2 bg-white px-4 py-2 text-sm text-[#49385C] shadow">
        <ArrowLeft size={16} /> Dashboard
      </Link>
      {showHome && (
        <Link href="/" className="btn-chunky inline-flex items-center gap-2 bg-white/70 px-4 py-2 text-sm text-[#49385C] shadow">
          <Home size={16} /> Home
        </Link>
      )}
    </div>
  );
}

export function Formula({ children, speak }: { children: React.ReactNode; speak?: string }) {
  return (
    <div className="formula-box rounded-2xl px-4 py-3 text-center text-lg sm:text-xl font-extrabold text-[#49385C]" aria-label={speak ?? undefined}>
      {children}
    </div>
  );
}

export function Celebrate({ stars, message }: { stars: number; message?: string }) {
  return (
    <div className="pop-in rounded-3xl bg-gradient-to-br from-[#FFE89A] via-[#FFC5DD] to-[#CDB8F5] p-6 text-center shadow-xl">
      <div className="flex justify-center gap-1 text-4xl" aria-hidden>
        {Array.from({ length: Math.min(5, Math.max(1, Math.ceil(stars / 2))) }).map((_, i) => (
          <span key={i} className="star-burst" style={{ animationDelay: `${i * 0.12}s` }}>⭐</span>
        ))}
      </div>
      <p className="font-display mt-2 text-2xl font-extrabold text-[#49385C]">
        Yay! You did it! You earned {stars} star{stars === 1 ? "" : "s"}!
      </p>
      {message && <p className="mt-1 font-semibold text-[#49385C]/80">{message}</p>}
      <p className="mt-2 inline-flex items-center gap-1 text-sm font-bold text-[#49385C]/70"><Sparkles size={14} /> Keep shining, Superstar!</p>
    </div>
  );
}

export function DifficultyBadge({ level }: { level: string }) {
  const color = level === "Easy" ? "bg-[#B8E6D0]" : level === "Challenge" ? "bg-[#FFC5DD]" : "bg-[#FFE89A]";
  return <span className={`rounded-full px-3 py-1 text-xs font-extrabold text-[#49385C] ${color}`}>{level}</span>;
}
