"use client";

import React, { createContext, useContext, useEffect, useMemo, useRef, useState } from "react";

export interface ActivityRecord {
  id: string;
  label: string;
  stars: number;
  competency: number;
  date: string;
}

export interface ProgressState {
  nickname: string;
  stars: number;
  completedLessons: string[];
  gameBest: Record<string, { best: number; plays: number; perfects: number }>;
  practiceSessions: number;
  practiceCorrectFirst: number;
  practiceAnswered: number;
  competencyStars: number[];
  competencyProgress: number[]; // 0-100
  activities: ActivityRecord[];
  badges: string[];
}

const DEFAULT_STATE: ProgressState = {
  nickname: "",
  stars: 0,
  completedLessons: [],
  gameBest: {},
  practiceSessions: 0,
  practiceCorrectFirst: 0,
  practiceAnswered: 0,
  competencyStars: Array(10).fill(0),
  competencyProgress: Array(10).fill(0),
  activities: [],
  badges: [],
};

const KEY = "geo-measure-progress-v1";

function loadState(): ProgressState {
  if (typeof window === "undefined") return DEFAULT_STATE;
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return DEFAULT_STATE;
    const parsed = JSON.parse(raw);
    return {
      ...DEFAULT_STATE,
      ...parsed,
      competencyStars: Array.isArray(parsed.competencyStars) && parsed.competencyStars.length === 10 ? parsed.competencyStars : Array(10).fill(0),
      competencyProgress: Array.isArray(parsed.competencyProgress) && parsed.competencyProgress.length === 10 ? parsed.competencyProgress : Array(10).fill(0),
    };
  } catch {
    return DEFAULT_STATE;
  }
}

interface ProgressCtx {
  state: ProgressState;
  setNickname: (n: string) => void;
  awardStars: (stars: number, activity: Omit<ActivityRecord, "date"> & { date?: string }) => void;
  completeLesson: (lessonId: string, competencyIndex: number) => boolean;
  recordGame: (gameId: string, competencyIndex: number, score: number, total: number) => { stars: number; isNewBest: boolean; perfect: boolean };
  recordPractice: (correctFirst: number, total: number, competencies: number[]) => number;
  resetAll: () => void;
  totalActivities: number;
  overallProgress: number;
}

const Ctx = createContext<ProgressCtx | null>(null);

export const BADGE_DEFS: { id: string; name: string; desc: string; emoji: string; check: (s: ProgressState) => boolean }[] = [
  { id: "first-steps", name: "First Steps", desc: "Finish your first lesson", emoji: "🐾", check: (s) => s.completedLessons.length >= 1 },
  { id: "bookworm", name: "Book Cub", desc: "Finish 5 lessons", emoji: "📚", check: (s) => s.completedLessons.length >= 5 },
  { id: "scholar", name: "Rainbow Scholar", desc: "Finish all 10 lessons", emoji: "🌈", check: (s) => s.completedLessons.length >= 10 },
  { id: "star-10", name: "Sparkle Star", desc: "Earn 10 stars", emoji: "⭐", check: (s) => s.stars >= 10 },
  { id: "star-50", name: "Shining Star", desc: "Earn 50 stars", emoji: "🌟", check: (s) => s.stars >= 50 },
  { id: "star-150", name: "Superstar", desc: "Earn 150 stars", emoji: "💫", check: (s) => s.stars >= 150 },
  { id: "gamer", name: "Game Cub", desc: "Play 5 different games", emoji: "🎮", check: (s) => Object.keys(s.gameBest).length >= 5 },
  { id: "perfect", name: "Perfect Treasure", desc: "Get a perfect game score", emoji: "🏆", check: (s) => Object.values(s.gameBest).some((g) => g.perfects > 0) },
  { id: "practicer", name: "Practice Pal", desc: "Complete 3 practice sessions", emoji: "✏️", check: (s) => s.practiceSessions >= 3 },
  { id: "explorer", name: "World Explorer", desc: "Earn stars in all 10 competencies", emoji: "🌍", check: (s) => s.competencyStars.every((c) => c > 0) },
];

export function ProgressProvider({ children }: { children: React.ReactNode }) {
  const [state, setState] = useState<ProgressState>(DEFAULT_STATE);
  const hydrated = useRef(false);

  useEffect(() => {
    setState(loadState());
    hydrated.current = true;
  }, []);

  useEffect(() => {
    if (!hydrated.current) return;
    try {
      localStorage.setItem(KEY, JSON.stringify(state));
    } catch { /* noop */ }
    // sync to backend leaderboard (fire and forget)
    if (state.nickname && state.stars >= 0) {
      fetch("/api/leaderboard", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          nickname: state.nickname,
          stars: state.stars,
          activities: state.activities.length,
        }),
      }).catch(() => {});
    }
  }, [state]);

  const value = useMemo<ProgressCtx>(() => {
    const applyBadges = (s: ProgressState): ProgressState => {
      const earned = new Set(s.badges);
      for (const b of BADGE_DEFS) {
        if (!earned.has(b.id) && b.check(s)) earned.add(b.id);
      }
      return { ...s, badges: Array.from(earned) };
    };

    return {
      state,
      setNickname: (n: string) => setState((s) => applyBadges({ ...s, nickname: n.slice(0, 24) })),
      awardStars: (stars, activity) => {
        if (stars <= 0) return;
        setState((s) => {
          // duplicate-click guard: ignore identical award within 1.5s
          const now = Date.now();
          const last = s.activities[s.activities.length - 1];
          if (last && last.id === activity.id && now - new Date(last.date).getTime() < 1500) return s;
          const comp = Math.max(0, Math.min(9, activity.competency));
          const cs = [...s.competencyStars];
          cs[comp] += stars;
          const cp = [...s.competencyProgress];
          cp[comp] = Math.min(100, cp[comp] + Math.min(14, 3 + stars));
          const next: ProgressState = {
            ...s,
            stars: s.stars + stars,
            competencyStars: cs,
            competencyProgress: cp,
            activities: [...s.activities.slice(-49), { ...activity, date: new Date(now).toISOString() }],
          };
          return applyBadges(next);
        });
      },
      completeLesson: (lessonId, competencyIndex) => {
        let awarded = false;
        setState((s) => {
          if (s.completedLessons.includes(lessonId)) return s;
          awarded = true;
          const comp = Math.max(0, Math.min(9, competencyIndex));
          const cp = [...s.competencyProgress];
          cp[comp] = Math.min(100, cp[comp] + 34);
          const cs = [...s.competencyStars];
          cs[comp] += 5;
          const next: ProgressState = {
            ...s,
            stars: s.stars + 5,
            completedLessons: [...s.completedLessons, lessonId],
            competencyStars: cs,
            competencyProgress: cp,
            activities: [...s.activities.slice(-49), { id: `lesson-${lessonId}-${Date.now()}`, label: `Completed lesson ${lessonId}`, stars: 5, competency: comp, date: new Date().toISOString() }],
          };
          return applyBadges(next);
        });
        return awarded;
      },
      recordGame: (gameId, competencyIndex, score, total) => {
        const perfect = total > 0 && score === total;
        const stars = 2 + score + (perfect ? 3 : 0);
        const comp = Math.max(0, Math.min(9, competencyIndex));
        let isNewBest = false;
        setState((s) => {
          const prev = s.gameBest[gameId];
          isNewBest = !prev || score > prev.best;
          const cs = [...s.competencyStars];
          cs[comp] += stars;
          const cp = [...s.competencyProgress];
          cp[comp] = Math.min(100, cp[comp] + Math.min(20, 5 + score * 2));
          const next: ProgressState = {
            ...s,
            stars: s.stars + stars,
            competencyStars: cs,
            competencyProgress: cp,
            gameBest: {
              ...s.gameBest,
              [gameId]: {
                best: Math.max(prev?.best ?? 0, score),
                plays: (prev?.plays ?? 0) + 1,
                perfects: (prev?.perfects ?? 0) + (perfect ? 1 : 0),
              },
            },
            activities: [...s.activities.slice(-49), { id: `game-${gameId}-${Date.now()}`, label: `Played ${gameId} (${score}/${total})`, stars, competency: comp, date: new Date().toISOString() }],
          };
          return applyBadges(next);
        });
        return { stars, isNewBest, perfect };
      },
      recordPractice: (correctFirst, total, competencies) => {
        const stars = correctFirst + (correctFirst === total && total > 0 ? 4 : 2);
        setState((s) => {
          const cs = [...s.competencyStars];
          const cp = [...s.competencyProgress];
          const share = total > 0 ? stars / Math.max(1, competencies.length) : 0;
          competencies.forEach((c) => {
            const idx = Math.max(0, Math.min(9, c));
            cs[idx] += Math.max(1, Math.round(share));
            cp[idx] = Math.min(100, cp[idx] + Math.min(16, 4 + correctFirst));
          });
          const next: ProgressState = {
            ...s,
            stars: s.stars + stars,
            practiceSessions: s.practiceSessions + 1,
            practiceCorrectFirst: s.practiceCorrectFirst + correctFirst,
            practiceAnswered: s.practiceAnswered + total,
            competencyStars: cs,
            competencyProgress: cp,
            activities: [...s.activities.slice(-49), { id: `practice-${Date.now()}`, label: `Practice session (${correctFirst}/${total} first-try)`, stars, competency: competencies[0] ?? 0, date: new Date().toISOString() }],
          };
          return applyBadges(next);
        });
        return stars;
      },
      resetAll: () => {
        setState(DEFAULT_STATE);
        try { localStorage.removeItem(KEY); } catch { /* noop */ }
      },
      totalActivities: state.activities.length + state.completedLessons.length,
      overallProgress: Math.round(state.competencyProgress.reduce((a, b) => a + b, 0) / 10),
    };
  }, [state]);

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useProgress() {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useProgress must be used within ProgressProvider");
  return ctx;
}
