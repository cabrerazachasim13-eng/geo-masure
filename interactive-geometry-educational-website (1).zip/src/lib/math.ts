// Math checking utilities with tolerance + rounding support.

export function parseNumeric(input: string): number | null {
  if (typeof input !== "string") return null;
  let t = input.trim().toLowerCase();
  // strip units and degree symbols
  t = t.replace(/(degrees|degree|cm²|cm2|m²|m2|km²|km2|cm³|cm3|m³|m3|mm|cm|km|ml|liters|litres|litre|liter|l\b|kg|grams|gram|mg|pesos|php|₱|usd|\$|°c|°f|celsius|fahrenheit|kelvin|\bcm\b|\bm\b|\bkm\b|\bin\b|\bft\b|\bmin\b|\bmins\b|\bhrs\b|\bhr\b|\bh\b|\bs\b|seconds?|minutes?|hours?|days?|weeks?)/g, "");
  t = t.replace(/[°%$,₱\s]/g, "");
  t = t.replace(/,/g, "");
  if (t === "") return null;
  // support fractions like 3/4
  if (/^-?\d+(\.\d+)?\/-?\d+(\.\d+)?$/.test(t)) {
    const [a, b] = t.split("/").map(Number);
    if (b === 0) return null;
    return a / b;
  }
  const n = Number(t);
  return Number.isFinite(n) ? n : null;
}

export function checkNumeric(
  userInput: string,
  correct: number,
  opts: { tolerance?: number; relTolerance?: number } = {}
): { ok: boolean; value: number | null; diff: number | null } {
  const v = parseNumeric(userInput);
  if (v === null) return { ok: false, value: null, diff: null };
  const tol = opts.tolerance ?? Math.max(0.01, Math.abs(correct) * (opts.relTolerance ?? 0.02));
  const diff = Math.abs(v - correct);
  return { ok: diff <= tol, value: v, diff };
}

export function fmt(n: number, decimals = 2): string {
  if (!Number.isFinite(n)) return "—";
  const r = Number(n.toFixed(decimals));
  return Number.isInteger(r) ? String(r) : String(r);
}

export function triangleValid(a: number, b: number, c: number): boolean {
  return a > 0 && b > 0 && c > 0 && a + b > c && a + c > b && b + c > a;
}

export function heronArea(a: number, b: number, c: number): number | null {
  if (!triangleValid(a, b, c)) return null;
  const s = (a + b + c) / 2;
  const inside = s * (s - a) * (s - b) * (s - c);
  if (inside < 0) return null;
  return Math.sqrt(inside);
}

export function deg(rad: number) { return (rad * 180) / Math.PI; }
export function rad(degv: number) { return (degv * Math.PI) / 180; }

export function shuffle<T>(arr: T[]): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

export function pickN<T>(arr: T[], n: number): T[] {
  return shuffle(arr).slice(0, Math.min(n, arr.length));
}
