// Centralized professional female text-to-speech manager using Web Speech API.
// No researcher recordings, no paid APIs. Works with graceful fallback.

export type SpeechState = "idle" | "playing" | "paused" | "finished" | "unavailable";

type Listener = (state: SpeechState) => void;

let currentUtterance: SpeechSynthesisUtterance | null = null;
let currentState: SpeechState = "idle";
let activeId: string | null = null;
const listeners = new Set<Listener>();
let cachedVoice: SpeechSynthesisVoice | null = null;
let voicesLoaded = false;

function notify(state: SpeechState) {
  currentState = state;
  listeners.forEach((l) => {
    try { l(state); } catch { /* noop */ }
  });
}

export function subscribeSpeech(fn: Listener) {
  listeners.add(fn);
  return () => { listeners.delete(fn); };
}

export function getSpeechState(): SpeechState {
  return currentState;
}

export function isSpeechSupported(): boolean {
  return typeof window !== "undefined" && "speechSynthesis" in window && "SpeechSynthesisUtterance" in window;
}

function loadVoices(): Promise<SpeechSynthesisVoice[]> {
  return new Promise((resolve) => {
    if (!isSpeechSupported()) return resolve([]);
    const synth = window.speechSynthesis;
    const existing = synth.getVoices();
    if (existing.length > 0) return resolve(existing);
    let settled = false;
    const done = (v: SpeechSynthesisVoice[]) => {
      if (settled) return;
      settled = true;
      resolve(v);
    };
    synth.onvoiceschanged = () => done(synth.getVoices());
    setTimeout(() => done(synth.getVoices()), 1200);
  });
}

const FEMALE_HINTS = [
  "samantha", "zira", "aria", "jenny", "michelle", "victoria", "karen", "moira",
  "tessa", "serena", "female", "woman", "girl", "google us english female",
  "google uk english female", "susan", "kate", "allison", "ava", "joanna",
  "kendra", "kimberly", "salli", "ivy", "ravan", "neural", "natural",
];

function scoreVoice(v: SpeechSynthesisVoice): number {
  const name = v.name.toLowerCase();
  const lang = v.lang.toLowerCase();
  let score = 0;
  if (lang === "en-us") score += 50;
  else if (lang.startsWith("en-us")) score += 45;
  else if (lang === "en-gb") score += 30;
  else if (lang.startsWith("en")) score += 20;
  else return -100;
  for (const hint of FEMALE_HINTS) {
    if (name.includes(hint)) { score += 25; break; }
  }
  if (name.includes("google")) score += 8;
  if (name.includes("microsoft")) score += 6;
  if (name.includes("natural") || name.includes("neural")) score += 6;
  // deprioritize known male-ish names
  if (/\b(david|daniel|alex|fred|jorge|diego|thomas|james|john)\b/.test(name)) score -= 20;
  return score;
}

export async function pickFemaleVoice(): Promise<SpeechSynthesisVoice | null> {
  if (!isSpeechSupported()) return null;
  if (cachedVoice && voicesLoaded) return cachedVoice;
  const voices = await loadVoices();
  voicesLoaded = true;
  if (voices.length === 0) return null;
  let best: SpeechSynthesisVoice | null = null;
  let bestScore = -Infinity;
  for (const v of voices) {
    const s = scoreVoice(v);
    if (s > bestScore) { bestScore = s; best = v; }
  }
  // fallback: first english voice
  if (!best) best = voices.find((v) => v.lang.toLowerCase().startsWith("en")) ?? voices[0] ?? null;
  cachedVoice = best;
  return best;
}

/** Convert math notation into speakable English. */
export function speakableMath(text: string): string {
  let t = text;
  const reps: [RegExp, string][] = [
    [/SA\s*=/g, "Surface area equals"],
    [/V\s*=/g, "Volume equals"],
    [/A\s*=\s*√\[s\(s − a\)\(s − b\)\(s − c\)\]/g, "Area equals the square root of s times s minus a, times s minus b, times s minus c"],
    [/θ/g, " theta "],
    [/π/g, " pi "],
    [/√/g, " square root of "],
    [/∞/g, " infinity "],
    [/×/g, " times "],
    [/÷/g, " divided by "],
    [/−/g, " minus "],
    [/°C/g, " degrees Celsius "],
    [/°F/g, " degrees Fahrenheit "],
    [/°/g, " degrees "],
    [/²/g, " squared "],
    [/³/g, " cubed "],
    [/\^2/g, " squared "],
    [/\^3/g, " cubed "],
    [/m³/g, " cubic meters "],
    [/m²/g, " square meters "],
    [/cm³/g, " cubic centimeters "],
    [/cm²/g, " square centimeters "],
    [/km\/h/g, " kilometers per hour "],
    [/sin⁻¹|arcsin/gi, " inverse sine "],
    [/cos⁻¹|arccos/gi, " inverse cosine "],
    [/tan⁻¹|arctan/gi, " inverse tangent "],
    [/\bsin\b/gi, " sine "],
    [/\bcos\b/gi, " cosine "],
    [/\btan\b/gi, " tangent "],
    [/ℓ/g, " slant height l "],
    [/⅓/g, " one third "],
    [/½/g, " one half "],
    [/⁴⁄₃/g, " four thirds "],
    [/≈/g, " is approximately "],
    [/≠/g, " is not equal to "],
    [/≤/g, " is less than or equal to "],
    [/≥/g, " is greater than or equal to "],
    [/±/g, " plus or minus "],
    [/→/g, " becomes "],
    [/Δ/gi, " triangle "],
    [/∠/g, " angle "],
    [/⊥/g, " perpendicular to "],
    [/∥/g, " parallel to "],
  ];
  for (const [re, rep] of reps) t = t.replace(re, rep);
  // collapse
  t = t.replace(/\s+/g, " ").trim();
  return t;
}

export async function speakText(rawText: string, id = "global"): Promise<void> {
  if (!isSpeechSupported()) {
    notify("unavailable");
    return;
  }
  stopSpeech();
  const voice = await pickFemaleVoice();
  const synth = window.speechSynthesis;
  const utter = new SpeechSynthesisUtterance(speakableMath(rawText));
  if (voice) utter.voice = voice;
  utter.rate = 0.95;
  utter.pitch = 1.05;
  utter.volume = 1;
  currentUtterance = utter;
  activeId = id;
  notify("playing");
  utter.onend = () => {
    if (activeId === id) { activeId = null; currentUtterance = null; notify("finished"); }
  };
  utter.onerror = () => {
    if (activeId === id) { activeId = null; currentUtterance = null; notify("finished"); }
  };
  // Chrome long-utterance workaround: resume periodically
  const resumeTimer = setInterval(() => {
    if (!synth.speaking || activeId !== id) { clearInterval(resumeTimer); return; }
    synth.resume();
  }, 8000);
  utter.onend = ((orig) => () => {
    clearInterval(resumeTimer);
    (orig as () => void)?.();
    if (activeId === id) { activeId = null; currentUtterance = null; notify("finished"); }
  })(utter.onend as unknown as () => void);
  synth.speak(utter);
}

export function pauseSpeech() {
  if (!isSpeechSupported()) return;
  try {
    window.speechSynthesis.pause();
    notify("paused");
  } catch { /* noop */ }
}

export function resumeSpeech() {
  if (!isSpeechSupported()) return;
  try {
    window.speechSynthesis.resume();
    notify("playing");
  } catch { /* noop */ }
}

export function stopSpeech() {
  if (!isSpeechSupported()) return;
  try {
    window.speechSynthesis.cancel();
  } catch { /* noop */ }
  currentUtterance = null;
  activeId = null;
  notify("idle");
}

export function getActiveId() {
  return activeId;
}
